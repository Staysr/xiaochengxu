# WeChat-ColorUI-shop-templet
微信小程序的 ColorUI扩展的商城模板

下载后，使用小程序开发工具导入后即可预览效果。

图片效果查看：https://www.yuque.com/itianc/ui/artboards/61558

ColorUI框架的GIT：https://github.com/weilanwl/ColorUI
（此项目使用的2.0.7版本的UI框架）

此项目不再进行更新，因为ColorUI作者已经在开始做ColorShop完整模板。
-
下面是ColorUI作者放的Shop效果图
-

![](https://cdn.nlark.com/yuque/0/2019/jpeg/285274/1554369274314-assets/web-upload/2af6103f-4100-404e-8a6f-3ecc0040bdae.jpeg)

如有问题，请在ColorUI官方QQ交流群里，@仔仔 - 专业打杂

