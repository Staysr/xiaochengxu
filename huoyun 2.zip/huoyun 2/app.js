//app.js
App({
  onLaunch: function () {
    var that = this
    //调用API从本地缓存中获取数据
    //获取司机缓存
    wx.getStorage({
      key: 'car',
      success: function (res) {
        console.log(res.data);
        if (res.data) {
          that.globalData.car = res.data
        }
      }
    })
    // 获取砍价设置
    //获取用户缓存
    wx.getStorage({
      key: 'user',
      success: function (res) {
        if (res.data) {
          that.globalData.user = res.data
        }
      }
    })
    //var user = wx.getStorageSync('user') || {};
    //var userInfo = wx.getStorageSync('userInfo') || {};
    //console.log(res)
    //if ((!user.openid || (user.expires_in || Date.now()) < (Date.now() + 600)) && (!userInfo.nickName)) {
      var that = this;
      wx.login({
        success: function (res) {
           var code = res.code;
          wx.setStorageSync('code',code)
        }
      })
   // }
    var code = wx.getStorageSync('code')
        //console.log(code)  
var d = that.globalData;
var l = 'https://api.weixin.qq.com/sns/jscode2session?appid=' + d.appid + '&secret=' + d.secret + '&js_code=' + code + '&grant_type=authorization_code';
    wx.request({
      url: l,
      data: {},
      method: 'GET',
      success: function (res) {
        console.log(res.data)
        //openid:res.data.openid //返回openid
       // console.log(res.data.openid)
        wx.setStorageSync('openid', res.data.openid)
      }
    })
    // var openid = wx.getStorageSync('openid')
    // var code = wx.getStorageSync('code')
    // if (openid == ""){
    //   console.log(openid)
    //     var d = that.globalData;
    //     var l = 'https://api.weixin.qq.com/sns/jscode2session?appid=' + d.appid + '&secret=' + d.secret + '&js_code=' + code + '&grant_type=authorization_code';
    //     wx.request({
    //       url: l,
    //       data: {},
    //       method: 'GET',
    //       success: function (res) {
    //         console.log(res.data)
    //         //openid:res.data.openid //返回openid
    //         // console.log(res.data.openid)
    //         wx.setStorageSync('openid', res.data.openid)
    //       },
    //       fail: function (res) {
    //         that.getOpenid();
    //         return;
    //       },
    //       complete: function (res) {
    //         that.getOpenid();
    //         return
    //       }
    //     })
    // }
  },
  getUserInfo: function (cb) {
    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },
  // getOpenid: function () {
  //   console.log("我被调用")
  //   var that = this;
  //   wx.login({
  //     success: function (res) {
  //       var code = res.code;
  //       wx.setStorageSync('code', code)
  //     }
  //   })
  //   // }
  //var d = "wx3e74ca1a57a58ed8";
  //var l ="d73fa38f74dee1c430143fbc3441151f";
   //var code = wx.getStorageSync('code')
   //console.log(code)
   //var d = that.globalData;
    //var l = 'https://api.weixin.qq.com/sns/jscode2session?appid=' + d.appid + '&secret=' + d.secret + '&js_code=' + code + '&grant_type=authorization_code';
  //   wx.request({
  //     url: l,
  //     data: {},
  //     method: 'GET',
  //     success: function (res) {
  //       console.log(res.data)
  //       //openid:res.data.openid //返回openid
  //       // console.log(res.data.openid)
  //       wx.setStorageSync('openid', res.data.openid)
  //     }
  //   })
  // },
  globalData: {
    userInfo: null,
    url: 'https://g.hbyingluo.com/api/',
    img_url: 'https://g.hbyingluo.com',
    appid: 'wx3e74ca1a57a58ed8',
    secret: 'd73fa38f74dee1c430143fbc3441151f',    
    header: { 'Session': '' },
    version: "4.0.0",
    shareProfile: '百款精品商品，总有一款适合您'
  }
})



