// pages/car/index.js
var util = require("../../utils/util.js");
var QQMapWX = require("../../utils/qqmap-wx-jssdk.js");
var qqmapsdk;
const app = getApp()
const URL = app.globalData.url
Page({

  /**
   * 页面的初始数据
   */
  data: {
    switchChange(e) {
      //console.log('switchChange 事件，值:', e.detail.value)
      wx.showToast({

        title: '这里面可以写很多的文字，比其他的弹窗都要多！',

        icon: 'none',

        duration: 2000, //持续的时间

        province: '',

        city: '',

        latitude: '',

        longitude: ''
      })
    }
  },
  shezhi:function(){
    wx.navigateTo({
      url: '../shezi/index',
    })
  },
  kefu: function () {
    wx.navigateTo({
      url: '../kefu/index',
    })
  },
   xiaoxi: function () {
    wx.navigateTo({
      url: '../xiaoxi/index',
    })
  },
  cardingdan: function () {
    wx.navigateTo({
      url: '../cardingdan/index',
    })
  },
  xiaoxi: function () {
    wx.navigateTo({
      url: '../xiaoxi/index',
    })
  },
  guanli: function () {
    wx.navigateTo({
      url: '../guanli/index',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    qqmapsdk = new QQMapWX({
      key: 'U4BBZ-LZZKU-VTEVR-4EUNO-QC2QS-WNBGF' //腾讯地图key秘钥进行填充
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },
  dx:function(){
    wx.showToast({
      title: '请求中',
      icon: 'loading',
    });
    try {
      var car_id = wx.getStorageSync('car')
      if (car_id) {
        var that = this
        wx.request({
          url: URL + 'User/dx',
          data: {
            did: car_id.id
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            console.log(res.data)
              
          }
        })
      }
    } catch (e) {
      // Do something when catch error
    }
    // var that = this
    // var car_id = app.globalData.car.id
    // wx.request({
    //   url: URL + 'Desired/dingdan',
    //   data: {
    //     did: car_id
    //   },
    //   header: {
    //     'content-type': 'application/x-www-form-urlencoded'
    //   },
    //   success: function (res) {
    //     //console.log(res.data);
    //     console.log(res.data);
    //     if (res.data.status == 200) {
    //       wx.showToast({
    //         title: '完成订单成功',
    //         duration: 2000,
    //         icon: "none"
    //       })
    //       that.setData({
    //         jieshou: res.data.data
    //       })
    //     }
    //     if (res.data.status == 105) {
    //       wx.showToast({
    //         title: '完成订单接收失败',
    //         duration: 2000,
    //         icon: "none"
    //       })
    //     }
    //   }
    // })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
     //地图显示
    let vm = this;
    vm.getUserLocation();
    vm.getUsernumber();
  },
  getUsernumber:function(){
    let that= this;
    wx.request({
      url: URL + 'Desired/push',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },

      success: function (res) {
        console.log(res)
        that.setData({
          quanbu: res.data,
        })
      }
    })
  },
  getUserLocation: function () {
    let vm = this;
    wx.getSetting({
      success: (res) => {
        console.log(JSON.stringify(res))
        // res.authSetting['scope.userLocation'] == undefined    表示 初始化进入该页面
        // res.authSetting['scope.userLocation'] == false    表示 非初始化进入该页面,且未授权
        // res.authSetting['scope.userLocation'] == true    表示 地理位置授权
        if (res.authSetting['scope.userLocation'] != undefined && res.authSetting['scope.userLocation'] != true) {
          wx.showModal({
            title: '请求授权当前位置',
            content: '需要获取您的地理位置，请确认授权',
            success: function (res) {
              if (res.cancel) {
                wx.showToast({
                  title: '拒绝授权',
                  icon: 'none',
                  duration: 1000
                })
              } else if (res.confirm) {
                wx.openSetting({
                  success: function (dataAu) {
                    if (dataAu.authSetting["scope.userLocation"] == true) {
                      wx.showToast({
                        title: '授权成功',
                        icon: 'success',
                        duration: 1000
                      })
                      //再次授权，调用wx.getLocation的API
                      vm.getLocation();
                    } else {
                      wx.showToast({
                        title: '授权失败',
                        icon: 'none',
                        duration: 1000
                      })
                    }
                  }
                })
              }
            }
          })
        } else if (res.authSetting['scope.userLocation'] == undefined) {
          //调用wx.getLocation的API
          vm.getLocation();
        }
        else {
          //调用wx.getLocation的API
          vm.getLocation();
        }
      }
    })
  },
  // 微信获得经纬度
  getLocation: function () {
    let vm = this;
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
       // console.log(JSON.stringify(res))
        var latitude = res.latitude
        var longitude = res.longitude
        var speed = res.speed
        var accuracy = res.accuracy;
        vm.getLocal(latitude, longitude)
      },
      fail: function (res) {
        console.log('fail' + JSON.stringify(res))
      }
    })
  },
  // 获取当前地理位置
  getLocal: function (latitude, longitude) {
    let vm = this;
    qqmapsdk.reverseGeocoder({
      location: {
        latitude: latitude,
        longitude: longitude
      },
      success: function (res) {
        console.log(JSON.stringify(res.result.address_component.street_number))
        //console.log(JSON.stringify(res));
        let province = res.result.address_component.province
        let city = res.result.address_component.city
        let nation = res.result.address_component.nation
        let district = res.result.address_component.district
        let street = res.result.address_component.street
        let street_number = res.result.address_component.street_number
        vm.setData({
          province: province,
          city: city,
          nation: nation,
          district: district,
          street: street,
          street_number: street_number,
          latitude: latitude,
          longitude: longitude
        })
        var car = wx.getStorageSync('car')//获取司机的id
        var userInfo = wx.getStorageSync('userInfo')//获取司机的id
        wx.request({
          url: URL + 'User/particulars',
          data: {
            //比如 province==河北省 city == 石家庄市 
            nation: nation,//国
            province: province,//省
            city: city,//市
            district: district,//区
            street: street,//路
            street_number: street_number,//号
            car: car['id'],//司机的id
            userInfo: userInfo['nickName']//司机的名字
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            console.log(res.data)

          }
        })
      },
      fail: function (res) {
        console.log(res);
      },
      complete: function (res) {
        // console.log(res);
      }
    });
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})