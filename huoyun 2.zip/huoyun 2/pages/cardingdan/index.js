// pages/cardingdan/index.js
var util = require("../../utils/util.js");
const app = getApp()
const URL = app.globalData.url
Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab:0
  },
  sus_book: function (e) {
    wx.showToast({
      title: '请求中',
      icon: 'loading',
    });
    try {
      var car_id = wx.getStorageSync('car')
      if (car_id) {
        var that = this
        var id = e.currentTarget.dataset.id
        var uid = e.currentTarget.dataset.uid
        wx.request({
          url: URL + 'Desired/achieve',
          data: {
            id: id,
            uid:uid,
            did: car_id.id

          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            console.log(res.data);
            if (res.data.status == 200) {
              wx.showToast({
                title: '完成订单成功',
                duration: 2000,
                icon: "none"
              })
            }
            if (res.data.status == 105) {
              wx.showToast({
                title: '完成订单接收失败',
                duration: 2000,
                icon: "none"
              })
            }
          }
        })
      }
    }catch(e) {
    // Do something when catch error
    }  
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showToast({
      title: '请求中',
      icon: 'loading',
    });
    // wx.getStorageSync({
    //   // key: 'car',
    //   // success: function (res) {
    //   //   console.log(res.data)
    //   // }
      
    // })
    try {
      var car_id = wx.getStorageSync('car')
      if (car_id) {
        var that = this
        //var car_id = app.globalData.car.id
    wx.request({
      url: URL + 'Desired/dingdan',
      data: {
        did: car_id.id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        //console.log(res.data);
        console.log(res.data);
        if (res.data.status == 200) {
          wx.showToast({
            title: '完成订单成功',
            duration: 2000,
            icon: "none"
          })
          that.setData({
            jieshou: res.data.data
          })
        }
        if (res.data.status == 105) {
          wx.showToast({
            title: '完成订单接收失败',
            duration: 2000,
            icon: "none"
          })
        }
      }
    })
      }
    } catch (e) {
      // Do something when catch error
    }
  },
  onShow: function () {
    wx.getStorage({
      key: 'car',
      success: function (res) {
        console.log(res.data)
      }
    })
  },
  onReady: function () {
    wx.getStorage({
      key: 'car',
      success: function (res) {
        console.log(res.data)
      }
    })
  },
  selected:function(e){
    var cur = e.target.dataset.current;
    if (this.data.currentTaB == cur) { return false; }
    else {
      this.setData({
        currentTab: cur
      })
    }

  },
  // 滚动切换标签样式
    switchTab: function (e) {
    this.setData({
      currentTab: e.detail.current
    });
  },
})