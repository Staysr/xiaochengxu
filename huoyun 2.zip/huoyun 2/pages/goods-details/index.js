//index.js
//获取应用实例
var WxParse = require('../../wxParse/wxParse.js');
var util = require("../../utils/util.js");
const app = getApp()
const URL = app.globalData.url
Page({
  data: {
    autoplay: true,
    interval: 3000,
    duration: 1000,
    goodsDetail: {},
    swiperCurrent: 0,
    hasMoreSelect: false,
    selectSize: "选择：",
    selectSizePrice: 0,
    totalScoreToPay: 0,
    shopNum: 0,
    hideShopPopup: true,
    buyNumber: 0,
    buyNumMin: 1,
    buyNumMax: 0,
    goods:"请选择尺码",
    propertyChildIds: "",
    propertyChildNames: "",
    canSubmit: false, //  选中规格尺寸时候是否允许加入购物车
    shopCarInfo: {},
    shopType: "addShopCar", //购物类型，加入购物车或立即购买，默认为加入购物车
  },
  //尺寸
  selected: function(e) {
    var that = this
    var selected = e.currentTarget.dataset.selected
    var measure = e.currentTarget.dataset.good
    var money_sizeid = wx.getStorageSync('money_sizeid')
    wx.request({
      url: URL + 'Banner/money_size',
      method: 'post',
        data: {
          money_sizeid: money_sizeid
        },
        header: {
        'content-type': 'application/x-www-form-urlencoded'
        },
        success: function (res) {
          wx.setStorage({
            key: "price",
            data: res.data.money_size,
          })
          //console.log(res.data.money_size)
          that.setData({
              goods: res.data.money_size
          });
        }
      })
    //写入本地 尺寸
    wx.setStorage({
      key: "measure",
      data: measure,
    })
    that.setData({
      selected: selected
    })
  },
  selected1: function(e) {
    var that = this
    var selected = e.currentTarget.dataset.selected
    var measure = e.currentTarget.dataset.good
    var money_sizeid = wx.getStorageSync('money_sizeid')
    wx.request({
      url: URL + 'Banner/money_size1',
      method: 'post',
      data: {
        money_sizeid: money_sizeid
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.setStorage({
          key: "price",
          data: res.data.money_size1,
        })
        //console.log(res.data.money_size1)
        that.setData({
          goods: res.data.money_size1
        });
      }
    })
    wx.setStorage({
      key: "measure",
      data: measure,
    })
    that.setData({
      selected: selected
    })
  },
  selected2: function(e) {
    var that = this
    var selected = e.currentTarget.dataset.selected
    var measure = e.currentTarget.dataset.good
    var money_sizeid = wx.getStorageSync('money_sizeid')
    wx.request({
      url: URL + 'Banner/money_size2',
      method: 'post',
      data: {
        money_sizeid: money_sizeid
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.setStorage({
          key: "price",
          data: res.data.money_size2,
        })
       // console.log(res.data.money_size2)
        that.setData({
          goods: res.data.money_size2
        });
      }
    })
    wx.setStorage({
      key: "measure",
      data: measure,
    })
    that.setData({
      selected: selected
    })
  },
  //颜色
  color: function(e) {
    var that = this
    var color = e.currentTarget.dataset.color
    var style = e.currentTarget.dataset.style
    //写入本地数据 颜色
    wx.setStorage({
      key: "style",
      data: style,
    })
    that.setData({
      color: color
    })
  },
  color1: function(e) {
    var that = this
    var color = e.currentTarget.dataset.color
    var style = e.currentTarget.dataset.style
    wx.setStorage({
      key: "style",
      data: style,
    })
    that.setData({
      color: color
    })
  },
  color2: function(e) {
    var that = this
    var color = e.currentTarget.dataset.color
    var style = e.currentTarget.dataset.style
    wx.setStorage({
      key: "style",
      data: style,
    })
    that.setData({
      color: color
    })
  },
  //事件处理函数
  swiperchange: function(e) {
    //console.log(e.detail.current)
    this.setData({
      swiperCurrent: e.detail.current
    })
  },
  onLoad: function(e) {
    wx.setStorageSync('commercial', e.commercial)
    wx.showToast({
      title: '请求中',
      icon: 'loading',
    });
    if (e.inviter_id) {
      wx.setStorage({
        key: 'inviter_id_' + e.id,
        data: e.inviter_id
      })
    }
    var that = this;
    that.data.kjId = e.kjId;
    wx.request({
      url: URL + 'Banner/detail',
      data: {
        id: e.id
      },
      success: function(res) {
        console.log(res.data)
        wx.setStorage({
          key: "money_sizeid",
          data: res.data.id,
        })
        that.setData({
          goodsDetail: res.data,
          selectSizePrice: res.data.price,
          // totalScoreToPay: res.data.data.basicInfo.minScore,
          buyNumMax: res.data.m_num, //返回库存值
          buyNumber: (res.data.m_num > 0) ? 1 : 0 //库存

        });
        WxParse.wxParse('article', 'html', res.data.memo, that, 5);
      }
    })
    this.reputation(e.id);
    this.getKanjiaInfo(e.id);
  },
  goShopCar: function() {
    wx.reLaunch({
      url: "/pages/shop-cart/index"
    });
  },
  toAddShopCar: function() {
    // this.setData({
    //   shopType: "addShopCar"
    // })
    // this.bindGuiGeTap();
    wx.showToast({
      title: '敬请期待',
      image: '../../images/timg.png',
    });
  },
  tobuy: function() {
    this.setData({
      shopType: "tobuy",
      selectSizePrice: this.data.goodsDetail.price
    });
    this.bindGuiGeTap();
  },
  toPingtuan: function() {
    this.setData({
      shopType: "toPingtuan",
      selectSizePrice: this.data.goodsDetail.basicInfo.pingtuanPrice
    });
    this.bindGuiGeTap();
  },
  /**
   * 规格选择弹出框
   */
  bindGuiGeTap: function() {
    this.setData({
      hideShopPopup: false
    })
  },
  /**
   * 规格选择弹出框隐藏
   */
  closePopupTap: function() {
    this.setData({
      hideShopPopup: true
    })
  },
  numJianTap: function() {
    if (this.data.buyNumber > this.data.buyNumMin) {
      var currentNum = this.data.buyNumber;
      currentNum--;
      this.setData({
        buyNumber: currentNum
      })
    }
  },
  numJiaTap: function() {
    if (this.data.buyNumber < this.data.buyNumMax) {
      var currentNum = this.data.buyNumber;
      currentNum++;
      this.setData({
        buyNumber: currentNum
      })
    }
  },
  /**
   * 选择商品规格
   * @param {Object} e
   */
  labelItemTap: function(e) {
    var that = this;
    // 取消该分类下的子栏目所有的选中状态
    var childs = that.data.goodsDetail.properties[e.currentTarget.dataset.propertyindex].childsCurGoods;
    for (var i = 0; i < childs.length; i++) {
      that.data.goodsDetail.properties[e.currentTarget.dataset.propertyindex].childsCurGoods[i].active = false;
    }
    // 设置当前选中状态
    that.data.goodsDetail.properties[e.currentTarget.dataset.propertyindex].childsCurGoods[e.currentTarget.dataset.propertychildindex].active = true;
    // 获取所有的选中规格尺寸数据
    var needSelectNum = that.data.goodsDetail.properties.length;
    var curSelectNum = 0;
    var propertyChildIds = "";
    var propertyChildNames = "";
    for (var i = 0; i < that.data.goodsDetail.properties.length; i++) {
      childs = that.data.goodsDetail.properties[i].childsCurGoods;
      for (var j = 0; j < childs.length; j++) {
        if (childs[j].active) {
          curSelectNum++;
          propertyChildIds = propertyChildIds + that.data.goodsDetail.properties[i].id + ":" + childs[j].id + ",";
          propertyChildNames = propertyChildNames + that.data.goodsDetail.properties[i].name + ":" + childs[j].name + "  ";
        }
      }
    }
    var canSubmit = false;
    if (needSelectNum == curSelectNum) {
      canSubmit = true;
    }
    // 计算当前价格
    if (canSubmit) {
      // wx.request({
      //   url: 'https://api.it120.cc/' + app.globalData.subDomain + '/shop/goods/price',
      //   data: {
      //     goodsId: that.data.goodsDetail.basicInfo.id,
      //     propertyChildIds: propertyChildIds
      //   },
      //   success: function (res) {
      //     that.setData({
      //       selectSizePrice: res.data.data.price,
      //       totalScoreToPay: res.data.data.score,
      //       propertyChildIds: propertyChildIds,
      //       propertyChildNames: propertyChildNames,
      //       buyNumMax: res.data.data.stores,
      //       buyNumber: (res.data.data.stores > 0) ? 1 : 0
      //     });
      //   }
      // })
    }


    this.setData({
      goodsDetail: that.data.goodsDetail,
      canSubmit: canSubmit
    })
  },
  /**
   * 立即购买
   */
  buyNow: function(e) {
    var that = this;
    
    var val = e.currentTarget.dataset.id
    var jifen = e.currentTarget.dataset.integral_max
   // var price = e.currentTarget.dataset.price
    var shulaing = that.data.buyNumber
    var measure = wx.getStorageSync('measure') //商品尺码

    if (measure == ""){
      wx.showToast({
        title: '尺寸颜色不能为空',
        duration: 2000,
        icon: "none"
      })
      return;
    }
    // 写入本地存储
    //订单id
    wx.setStorage({
      key: "buyNowid",
      data: val,
    })
    //积分
    wx.setStorage({
      key: "jifen",
      data: jifen
    })
    //金钱
    // wx.setStorage({
    //   key: "price",
    //   data: price
    // })
    //数量
    wx.setStorage({
      key: "shulaing",
      data: shulaing
    })
     //判断当前的积分 如果大于商品的积分直接使用积分购买,小于商品的积分1积分等入5毛钱来换算成钱
    that.commercialjifen1();
     return;
  },
 //验证当前的积分
  commercialjifen1:function(){
    
    var that = this;
    var user = wx.getStorageSync('user') //用户id
    var price = wx.getStorageSync('price') //商品价格
    var jifen = wx.getStorageSync('jifen') //商品积分
    wx.request({
      url: URL + 'Banner/commercialjifen',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      data: {
        user: user['id'],
        jifen: jifen,
        price: price,
      },
      success: function (res) {
        console.log(res)
        if(res.data.status == 200){
        //光是积分支付的
        wx.setStorage({
          key: "commercialjifen",
          data: res.data.data,
        })
          wx.setStorage({
            key: "commercialmoenystatus",
            data: 3,
          })
          that.commeorder1();
          return;
      }  
        if (res.data.status == 107){
          //积分加钱 
          wx.setStorage({
            key: "commercialmoenystatus",
            data: 4,
          }) 
          that.commeorder1();
          return;
       }
         
      }
    })
  },
  commeorder1:function(e){
    //生成订单
    //var val = e.currentTarget.dataset.id
   //var shulaing = that.data.buyNumber
    var user = wx.getStorageSync('user') //用户id
    var shulaing = wx.getStorageSync('shulaing') //数量
    var buyNowid = wx.getStorageSync('buyNowid') //商品id
    var jifen = wx.getStorageSync('jifen') //商品积分
    var shulaing = wx.getStorageSync('shulaing') //商品数量
    var price = wx.getStorageSync('price') //商品价格
    var measure = wx.getStorageSync('measure') //商品尺码
    var style = wx.getStorageSync('style') //商品颜色
    var commercial = wx.getStorageSync('commercial') //商户id
    var commercialjifen = wx.getStorageSync('commercialjifen') //用户的积分
    var jifenmoney = wx.getStorageSync('jifenmoney') //积分加钱
    var commercialmoenystatus = wx.getStorageSync('commercialmoenystatus') //积分加钱的状态
    wx.request({
      url: URL + 'Banner/order',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      data: {
        user: user['id'],
        buyNowid: buyNowid,
        jifen: jifen,
        shulaing: shulaing,
        price: price,
        measure: measure,
        style: style,
        commercial: commercial,
        commercialjifen: commercialjifen,
        jifenmoney: jifenmoney,
        commercialmoenystatus: commercialmoenystatus
      },
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 105) {
          wx.showToast({
            title: '尺寸颜色不能为空',
            duration: 2000,
            icon: "none"
          })
          return false
        } else {
          wx.showToast({
            title: '请稍后',
            icon: 'loading',
          });
        }
        wx.navigateTo({
          url: "/pages/to-pay-order/index"
        })
      }
    })
    if (measure == undefined && style == undefined) {
      wx.showToast({
        title: '尺寸颜色不能为空',
        duration: 2000,
        icon: "none"
      })
      return false
    }
  },
  bulidShopCarInfo: function() {
    // 加入购物车
    var shopCarMap = {};
    shopCarMap.goodsId = this.data.goodsDetail.basicInfo.id;
    shopCarMap.pic = this.data.goodsDetail.basicInfo.pic;
    shopCarMap.name = this.data.goodsDetail.basicInfo.name;
    // shopCarMap.label=this.data.goodsDetail.basicInfo.id; 规格尺寸 
    shopCarMap.propertyChildIds = this.data.propertyChildIds;
    shopCarMap.label = this.data.propertyChildNames;
    shopCarMap.price = this.data.selectSizePrice;
    shopCarMap.score = this.data.totalScoreToPay;
    shopCarMap.left = "";
    shopCarMap.active = true;
    shopCarMap.number = this.data.buyNumber;
    shopCarMap.logisticsType = this.data.goodsDetail.basicInfo.logisticsId;
    shopCarMap.logistics = this.data.goodsDetail.logistics;
    shopCarMap.weight = this.data.goodsDetail.basicInfo.weight;

    var shopCarInfo = this.data.shopCarInfo;
    if (!shopCarInfo.shopNum) {
      shopCarInfo.shopNum = 0;
    }
    if (!shopCarInfo.shopList) {
      shopCarInfo.shopList = [];
    }
    var hasSameGoodsIndex = -1;
    for (var i = 0; i < shopCarInfo.shopList.length; i++) {
      var tmpShopCarMap = shopCarInfo.shopList[i];
      if (tmpShopCarMap.goodsId == shopCarMap.goodsId && tmpShopCarMap.propertyChildIds == shopCarMap.propertyChildIds) {
        hasSameGoodsIndex = i;
        shopCarMap.number = shopCarMap.number + tmpShopCarMap.number;
        break;
      }
    }

    shopCarInfo.shopNum = shopCarInfo.shopNum + this.data.buyNumber;
    if (hasSameGoodsIndex > -1) {
      shopCarInfo.shopList.splice(hasSameGoodsIndex, 1, shopCarMap);
    } else {
      shopCarInfo.shopList.push(shopCarMap);
    }
    shopCarInfo.kjId = this.data.kjId;
    return shopCarInfo;
  },
  reputation: function(goodsId) {
    var that = this;
    // wx.request({
    //   url: 'https://api.it120.cc/' + app.globalData.subDomain + '/shop/goods/reputation',
    //   data: {
    //     goodsId: goodsId
    //   },
    //   success: function (res) {
    //     if (res.data.code == 0) {
    //       //console.log(res.data.data);
    //       that.setData({
    //         reputation: res.data.data
    //       });
    //     }
    //   }
    // })
  },
  pingtuanList: function(goodsId) {
    var that = this;
    // wx.request({
    //   url: 'https://api.it120.cc/' + app.globalData.subDomain + '/shop/goods/pingtuan/list',
    //   data: {
    //     goodsId: goodsId
    //   },
    //   success: function (res) {
    //     if (res.data.code == 0) {
    //       that.setData({
    //         pingtuanList: res.data.data
    //       });
    //     }
    //   }
    // })
  },
  getVideoSrc: function(videoId) {
    var that = this;
    // wx.request({
    //   url: 'https://api.it120.cc/' + app.globalData.subDomain + '/media/video/detail',
    //   data: {
    //     videoId: videoId
    //   },
    //   success: function (res) {
    //     if (res.data.code == 0) {
    //       that.setData({
    //         videoMp4Src: res.data.data.fdMp4
    //       });
    //     }
    //   }
    // })
  },
  getKanjiaInfo: function(gid) {
    var that = this;
    if (!app.globalData.kanjiaList || app.globalData.kanjiaList.length == 0) {
      that.setData({
        curGoodsKanjia: null
      });
      return;
    }
    let curGoodsKanjia = app.globalData.kanjiaList.find(ele => {
      return ele.goodsId == gid
    });
    if (curGoodsKanjia) {
      that.setData({
        curGoodsKanjia: curGoodsKanjia
      });
    } else {
      that.setData({
        curGoodsKanjia: null
      });
    }
  },
  goKanjia: function() {
    var that = this;
    if (!that.data.curGoodsKanjia) {
      return;
    }
    // wx.request({
    //   url: 'https://api.it120.cc/' + app.globalData.subDomain + '/shop/goods/kanjia/join',
    //   data: {
    //     kjid: that.data.curGoodsKanjia.id,
    //     token: wx.getStorageSync('token')
    //   },
    //   success: function (res) {
    //     if (res.data.code == 0) {
    //       console.log(res.data);
    //       wx.navigateTo({
    //         url: "/pages/kanjia/index?kjId=" + res.data.data.kjId + "&joiner=" + res.data.data.uid + "&id=" + res.data.data.goodsId
    //       })
    //     } else {
    //       wx.showModal({
    //         title: '错误',
    //         content: res.data.msg,
    //         showCancel: false
    //       })
    //     }
    //   }
    // })
  },
  joinPingtuan: function(e) {
    //console.log(e)
    let pingtuanopenid = e.currentTarget.dataset.pingtuanopenid
    wx.navigateTo({
      url: "/pages/to-pay-order/index?orderType=buyNow&pingtuanOpenId=" + pingtuanopenid
    })
  }
})