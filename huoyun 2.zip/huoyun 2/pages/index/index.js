var util = require("../../utils/util.js");
var QQMapWX = require("../../utils/qqmap-wx-jssdk.js");
var qqmapsdk;
const app = getApp()
const URL = app.globalData.url
Page({
  data: {
   departure: '出发地',
    destination: '目的地',
    jiner: '45',
    scale: 15,
    addtel: 60,
    hiddenLoading: false,
    imageWidth: wx.getSystemInfoSync().windowWidth,
    latitude: '',
    longitude: '',
    circles: [{
      latitude: '',
      longitude: '116.491081',
      color: '#FF0000DD',
      fillColor: '#7cb5ec88',
      radius: 400,
      strokeWidth: 2,


    }],
    markers: [{
      iconPath: "/images/location.png",//定位图标
      id: 0,
      latitude: 28.2174900000,//纬度
      longitude: 112.8977300000,//经度
      width: 50,//图标宽
      height: 50,//图标高
    }],
  },
  indexcar: function(e) {
    var val = e.currentTarget.dataset.index
    this.setData({
      indexcar: val,
    })
  },
  // mapclick: function () {
  //   wx.openLocation({
  //     latitude: latitude,//纬度
  //     longitude: longitude,//经度
  //     scale: 18,//缩放
  //     name: '湖南翱云网络科技有限公司',
  //     address: '湖南长沙岳麓区桐梓坡西路雅阁国际'
  //   })
  // },
  sexDeparture: function() {
    var that = this;
    wx.chooseLocation({
      success: function(res) {
        //that.getDistance();       
        var lat1 = res.latitude
        var lng1 = res.longitude
        console.log(lat1)
        console.log(lng1)
        that.getDistance(lat1,lng1,that.data.lat2,that.data.lng2);
        that.setData({
          departure: res.name,
          lat1: lat1,
          lng1: lng1,
        })
      }
    })
  },

  sexDestination: function() {
    var that = this;
    wx.chooseLocation({
      success: function(res) {
        var lat2 = res.latitude
        var lng2 = res.longitude
        that.getDistance(that.data.lat1, that.data.lng1, lat2, lng2);
        that.setData({
          destination: res.name,
          lat2: lat2,
          lng2: lng2
        })
      }
    })
  },
  getDistance: function(lat1, lng1, lat2, lng2) {
    var that = this
    lat1 = that.data.lat1
    lng1 = that.data.lng1
    lat2 = that.data.lat2
    lng2 = that.data.lng2
    if (that.data.lat1 == undefined && that.data.lat2 == undefined){
      // wx.showToast({
      //   title: '请选择目的地',
      //   duration: 2000,
      //   icon: "none"
      // })
      return;
    }
    lat1 = lat1 || 0;

    lng1 = lng1 || 0;

    lat2 = lat2 || 0;

    lng2 = lng2 || 0;

    var rad1 = lat1 * Math.PI / 180.0;

    var rad2 = lat2 * Math.PI / 180.0;

    var a = rad1 - rad2;

    var b = lng1 * Math.PI / 180.0 - lng2 * Math.PI / 180.0;

    var r = 6378137; //地球半径

    var distance = r * 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(rad1) * Math.cos(rad2) * Math.pow(Math.sin(b / 2), 2)));
    wx.request({
      url: URL + 'User/money',
      data: {
        distance: distance,
        motorcycleid:that.data.indexcar
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      success: function(res) {
        console.log(res.data)
        // if (res.data.status == 200) {
        //   that.setData({
        //     money: res.data.data.piace,
        //   })
        // } else {
        //   // that.setData({
        //   //   money: 1,
        //   // })
        //   console.log(res.data.info);
        //   wx.showToast({
        //     title: res.data.info,
        //     duration: 2000,
        //     icon: "none"
        //   })
        // }
        that.moneys();
      }
    })
  },
  moneys: function (lat1, lng1, lat2, lng2){
    var that = this
    lat1 = that.data.lat1
    lng1 = that.data.lng1
    lat2 = that.data.lat2
    lng2 = that.data.lng2
    lat1 = lat1 || 0;

    lng1 = lng1 || 0;

    lat2 = lat2 || 0;

    lng2 = lng2 || 0;

    var rad1 = lat1 * Math.PI / 180.0;

    var rad2 = lat2 * Math.PI / 180.0;

    var a = rad1 - rad2;

    var b = lng1 * Math.PI / 180.0 - lng2 * Math.PI / 180.0;

    var r = 6378137; //地球半径

    var distance = r * 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(rad1) * Math.cos(rad2) * Math.pow(Math.sin(b / 2), 2)));
    wx.request({
      url: URL + 'User/money',
      data: {
        distance: distance,
        motorcycleid: that.data.indexcar
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      success: function (res) {
        console.log(res.data)
        if (res.data.status == 200) {
          that.setData({
            money: res.data.data.piace,
          })
        } else {
          // that.setData({
          //   money: 1,
          // })
          console.log(res.data.info);
          wx.showToast({
            title: res.data.info,
            duration: 2000,
            icon: "none"
          })
        }
      }
    })
  },
  onLoad: function(options) {

    qqmapsdk = new QQMapWX({
      key: 'U4BBZ-LZZKU-VTEVR-4EUNO-QC2QS-WNBGF' //腾讯地图key秘钥进行填充
    });
    let vm = this;
   vm.getUserLocation();
    var that = this
    wx.request({
      url: URL + 'User/upload',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function(res) {
        console.log(res.data)
        that.setData({
          quanbu: res.data,
          indexcar: res.data[0].id,
        })
      }
    })
  },
  //登入控制器
  login: function() {
    var user_type = wx.getStorageSync('user_type')
    try {
      if (user_type) {
        console.log(user_type)
        if (user_type == 1) {
          console.log('用户')
          try {
            var car = wx.getStorageSync('car')
            if (car) {
              // Do something with return value
              console.log('car1')
              wx.navigateTo({
                url: "../car/index",
              })
              //return false;
            } else {
              console.log('car2')
              wx.navigateTo({
                url: "../login/index",
              })
              //return false;
            }
          } catch (e) {
            // Do something when catch error
          }
        }
        if (user_type == 2) {
          console.log('司机')
          try {
            var user = wx.getStorageSync('user')
            if (user) {
              // Do something with return value
              console.log('user1')
              wx.navigateTo({
                url: "../personal/index",
              })
              //return false;
            } else {
              console.log('user2')
              wx.navigateTo({
                url: "../login/index",
              })
              //return false;
            }
          } catch (e) {
            // Do something when catch error
          }
        }
      } else {
        console.log('用户类型不存在')
        wx.navigateTo({
          url: "../login/index",
        })
      }
    } catch (e) {
      /////
    }
  },
  //用户消息控制器
  nser: function() {
    wx.getStorage({
      key: 'car',
      success: function(res) {
        //console.log(res.data.account)
        if (res.data.account == "") {
          wx.navigateTo({
            url: '../login/index',
          })
        } else {
          wx.navigateTo({
            url: '../advices/advices',
          })

        }
      }
    })
    wx.getStorage({
      key: 'user',
      success: function(res) {
        //console.log(res.data.account)
        if (res.data.account == "") {
          wx.showToast({
            title: '请登入',
            duration: 2000,
            icon: "none"
          })
        } else {
          wx.navigateTo({
            url: '../advices/advices',
          })
        }
      },
    })
  },
  //底部用车控制器
  yongche: function(e) {
    var that = this
    var viewId = e.target.id;
    var viewDataSet = e.target.dataset;
    var viewText = viewDataSet.text;

    /**地址*/
    var departure = that.data.departure
    var destination = that.data.destination
    var money = that.data.money
    //console.log(money)
    wx.getStorage({
      key: 'car',
      success: function(res) {
        console.log(res.data.account)
        if (res.data.account == "") {
          wx.navigateTo({
            url: '../login/index',
          })
        } else {
          
          wx.navigateTo({
            url: '../xuqiou/index?departure=' + departure + '&destination=' + destination + '&typeid=' + that.data.indexcar,
          })
          // wx.showToast({
          //   title: '请登入',
          //   duration: 2000,
          //   icon: "none"
          // })
        }
      }
    })
    wx.getStorage({
      key: 'user',
      success: function(res) {
       // console.log(res.data.account)
        if (res.data.account == "") {
          wx.showToast({
            title: '请登入',
            duration: 2000,
            icon: "none"
          })
        } else {
          console.log(money)
          if (money != undefined) {
            wx.navigateTo({
              url: '../xuqiou/index?departure=' + departure + '&destination=' + destination + '&typeid=' + that.data.indexcar + '&money=' + money,
            })
          }else{
            wx.showToast({
              title: '预算价格不能为空',
              duration: 2000,
              icon: "none"
            })
          }

        }
      },
    })
  },
  requesDriver() {
    util.request({
      url: '',
      mock: false,
    }).then((res) => {

      const drivers = res.data.drivers
      const driver = drivers[Math.floor(Math.random() * drivers.length)];
      wx.setStorage({
        key: "driver",
        data: driver
      });
      this.setData({
        hiddenLoading: true,
        driver: driver
      })
    })

  },
  bindcontroltap: (e) => {
    console.log("hello")
    this.movetoPosition();
  },
  onReady() {

  },
  getUserLocation: function () {
    let departure = this;
    wx.getSetting({
      success: (res) => {
        console.log(JSON.stringify(res))
        // res.authSetting['scope.userLocation'] == undefined    表示 初始化进入该页面
        // res.authSetting['scope.userLocation'] == false    表示 非初始化进入该页面,且未授权
        // res.authSetting['scope.userLocation'] == true    表示 地理位置授权
        if (res.authSetting['scope.userLocation'] != undefined && res.authSetting['scope.userLocation'] != true) {
          wx.showModal({
            title: '请求授权当前位置',
            content: '需要获取您的地理位置，请确认授权',
            success: function (res) {
              if (res.cancel) {
                wx.showToast({
                  title: '拒绝授权',
                  icon: 'none',
                  duration: 1000
                })
              } else if (res.confirm) {
                wx.openSetting({
                  success: function (dataAu) {
                    if (dataAu.authSetting["scope.userLocation"] == true) {
                      wx.showToast({
                        title: '授权成功',
                        icon: 'success',
                        duration: 1000
                      })
                      //再次授权，调用wx.getLocation的API
                      departure.getLocation();
                    } else {
                      wx.showToast({
                        title: '授权失败',
                        icon: 'none',
                        duration: 1000
                      })
                    }
                  }
                })
              }
            }
          })
        } else if (res.authSetting['scope.userLocation'] == undefined) {
          //调用wx.getLocation的API
          departure.getLocation();
        }
        else {
          //调用wx.getLocation的API
          departure.getLocation();
        }
      }
    })
  },
  // 微信获得经纬度
  getLocation: function () {
    let departure = this;
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        // console.log(JSON.stringify(res))
        var latitude = res.latitude
        var longitude = res.longitude
        var speed = res.speed
        var accuracy = res.accuracy;
        departure.getLocal(latitude, longitude)
      },
      fail: function (res) {
        console.log('fail' + JSON.stringify(res))
      }
    })
  },
  // 获取当前地理位置
  getLocal: function (latitude, longitude) {
    let departure = this;
    qqmapsdk.reverseGeocoder({
      location: {
        latitude: latitude,
        longitude: longitude
      },
      
      success: function (res) { 
       //console.log(JSON.stringify(res))
        //console.log(JSON.stringify(res));
        var that = this;
        let district = res.result.address_component.district
        let street = res.result.address_component.street
        let street_number = res.result.address_component.street_number   
        let latitude = res.result.location.lat
        let longitude = res.result.location.lng
        //that.getDistance(latitude.latitude, longitude.longitude, latitude, longitude);
        //console.log(latitude)    
        departure.setData({
          departure: district + " " + street + " " + street_number
        })
      },
      fail: function (res) {
        that.getDistance(latitude.latitude, longitude.longitude, lat1, long1);
      },
      complete: function (res) {
        //that.getDistance(latitude.latitude, longitude.longitude, latitude, longitude);
      }
    });
  },
  //监听页面的除此加载
  //请求后台table的车辆选中
  onShow: function() {
    let that = this
    let userInfo = wx.getStorageSync('userInfo')
    if (!userInfo) {
      wx.navigateTo({
        url: "/pages/authorize/index"
      })
    } else {
      that.setData({
        userInfo: userInfo
      })
    }
  },
  movetoPosition: function() {
    this.mapCtx.moveToLocation();
  },

  bindregionchange: (e) => {

  },
  // toCancel() {
  //   wx.redirectTo({
  //     url: "/pages/cancel/cancel"
  //   })

  // },
  // toApp() {
  //   wx.showToast({
  //     title: '暂不支持',
  //     icon: 'success',
  //     duration: 1000
  //   })
  // },
  // toEvaluation() {
  //   wx.redirectTo({
  //     url: "/pages/evaluation/evaluation",
  //   })
  // },
  onReady: function() {
    wx.getLocation({
      type: "gcj02",
      success: (res) => {
        this.setData({
          longitude: res.longitude,
          latitude: res.latitude
        })
      }
    })

  },
})