//index.js
//获取应用实例
var app = getApp()
var util = require("../../utils/util.js");
const URL = app.globalData.url
Page({
  data: {
    addressList: []
  },

  selectTap: function (e) {
    var id = e.currentTarget.dataset.id;
    wx.request({
      url: URL + 'Banner/siteinte1',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      data: {
        id: id,
        isDefault: 'true'
        
      },
      success: (res) => {
        console.log(res.data)
        wx.navigateBack({})
      }
    })
  },

  addAddess: function () {
    wx.navigateTo({
      url: "/pages/address-add/index"
    })
  },

  editAddess: function (e) {
    wx.navigateTo({
      url: "/pages/address-add/index?id=" + e.currentTarget.dataset.id
    })
  },

  onLoad: function () {
    console.log('onLoad')


  },
  onShow: function () {
    this.initShippingAddress();
  },
  
  initShippingAddress: function () {
    var user = wx.getStorageSync("user");
    var that = this;
    wx.request({
      url: URL + 'Banner/siteinte',
      data: {
        uid: user['id'],
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      success: (res) => {
        console.log(res.data.data)
        if (res.data.status == 200) {
          that.setData({
            addressList: res.data.data
          });
        } else if (res.data.status == 105) {
          that.setData({
            addressList: null
          });
        }
      }
    })
  }

})
