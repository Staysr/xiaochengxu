var util = require("../../utils/util.js");
const app = getApp()
const URL = app.globalData.url
Page({

  data: {
    goods: [],

    classify: [],

    loadingMoreHidden: true,

    loadingData: false,

    swiperCurrent: 0,

    open: false,

    istoright: true,

    indicatorDots: true,

    autoplay: true,

    interval: 3000,

    duration: 800,

    circular: true,
    //轮播图
    // imgUrls: [

    //   'https://p3.pstatp.com/large/43700001e49d85d3ab52',

    //   'https://p3.pstatp.com/large/39f600038907bf3b9c96',

    //   'https://p3.pstatp.com/large/31fa0003ed7228adf421'

    // ],
    //控件
    links: [

      '../user/user',

      '../user/user',

      '../user/user'

    ]
  },



  //轮播图的切换事件

  swiperChange: function (e) {

    this.setData({

      swiperCurrent: e.detail.current

    })

  },
  //前台主页面的商品列表
  onLoad: function () {
    wx.showToast({
      title: '请求中',
      icon: 'loading',
    });
    var that = this
    wx.request({
      url: URL + 'Banner/listbs',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        wx.hideLoading()
        let newData = { loadingMoreHidden: false }
       // console.log(res.data)
        that.setData({
          loadingMoreHidden: true,
          goods: res.data,
        })
      }
    })
  },
  //点击进入订单详情
  toDetailsTap: function (e) {
    wx.navigateTo({
      url: "/pages/goods-details/index?id=" + e.currentTarget.dataset.id +  '&commercial='+ e.currentTarget.dataset.commercial
    })
  },


  //前台商品分类
  onShow: function (e) {
    var that = this
    wx.request({
      url: URL + 'Banner/classify',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res)
        // var categories = [{ id: 0, name: "全部" }];
        // if (res.data.status == 0) {
        //   for (var i = 0; i < res.data.id; i++) {
        //     categories.push(res.data[i]);
        //   }
        // }
        //console.log(res.data)
        that.setData({
         // categories: categories ,
          classify: res.data,
          //activeCategoryId: 0,
          //curPage: 1
        })
      }
    })
    //前台圖片
    wx.request({
      url: URL + 'Banner/Slideshow',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res.data)
        //console.log(res.data)
        that.setData({
          // categories: categories ,
          imgUrls: res.data.data,
          //activeCategoryId: 0,
          //curPage: 1
        })
      }
    })
  },

  //商城分类点击事件
  tabClick: function (e) {
    var that = this;
    var id = e.currentTarget.dataset.id
    wx.request({
      url: URL + 'Banner/classifys',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        id: id
      },
      success: function (res) {
        //console
        let newData = { loadingMoreHidden: false }
        id: id
        classifys: res.data

      }
    })
    this.setData({
      activeCategoryId: e.currentTarget.id,
      curPage: 1
    });
    this.getGoodsList(this.data.activeCategoryId);
  },
  indexcar: function (e) {
    var val = e.currentTarget.dataset.index
    console.log(val)
    this.setData({
      indexcar: val,
    })
  },
  //点击指示点切换

  chuangEvent: function (e) {

    this.setData({

      swiperCurrent: e.currentTarget.id

    })

  },

  //点击图片触发事件

  swipclick: function (e) {

    console.log(this.data.swiperCurrent);

    wx.switchTab({

      url: this.data.links[this.data.swiperCurrent]

    })

  },
  getGoodsList: function (categoryId, append) {
    if (categoryId == 0) {
      categoryId = "";
    }
    var that = this;
    wx.showLoading({
      "mask": true
    })
    wx.request({
      url: URL + 'Banner/listupload',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        categoryId: categoryId,
        nameLike: that.data.searchInput,
        page: this.data.curPage,
        pageSize: this.data.pageSize
      },
      success: function (res) {
        console.log(res.data)
        wx.hideLoading()
        if (res.data.code == 404 || res.data.code == 700) {
          let newData = { loadingMoreHidden: false }
          if (!append) {
            newData.goods = []
          }
          that.setData(newData);
          return
        }
        let goods = [];
        if (append) {
          goods = that.data.goods
        }
        for (var i = 0; i < res.data.id; i++) {
          goods.push(res.data[i]);
        }
        that.setData({
          loadingMoreHidden: true,
          goods: res.data,
        });
      }
    })
  },
  /** 
    * 加载数据 
    */
  loadData: function (tail, callback) {
    var that = this,
      urlIndex = that.data.currentUrlIndex;
    wx.request({
      url: URL + 'Banner/classify',
      success: function (r) {
        var oldArticles = that.data.articles,
          newArticles = tail ? oldArticles.concat(r.data.articles) : r.data.articles;
        that.setData({
          classify: newArticles,
          currentUrlIndex: (urlIndex + 1) >= that.data.urls.length ? 0 : urlIndex + 1
        });
        if (callback) {
          callback();
        }
      },
      error: function (r) {
        console.info('error', r);
      },
      complete: function () { }
    });
  },
  //下拉加载商品
  onPullDownRefresh: function () {
    this.setData({
      curPage: 1
    });
    this.getGoodsList(this.data.activeCategoryId)
  },
  toSearch: function () {
    this.setData({
      curPage: 1
    });
    this.getGoodsList(this.data.activeCategoryId);
  },
})