  //index.js
//获取应用实例
var util = require("../../utils/util.js");
const app = getApp()
const URL = app.globalData.url
const APPID = app.globalData.appid
const SECRET = app.globalData.secret
Page({
  data: {
    totalScoreToPay: 0,
    goodsList: [],
    // isNeedLogistics: 0, // 是否需要物流信息
    allGoodsPrice: 0,
    yunPrice: 0,
    allGoodsAndYunPrice: 0,
    goodsJsonStr: "",

    hasNoCoupons: true,
    coupons: [],
  },
  onShow: function() {
    var that = this;
    var price = wx.getStorageSync('price')
    var shulaing = wx.getStorageSync('shulaing')
    var commercialmoenystatus = wx.getStorageSync('commercialmoenystatus')
    if (commercialmoenystatus == 3){
      wx.showModal({
        title: '温馨提示',
        content: '默认给您积分抵消金钱',  
        // confirmColor: 'skyblue',//确定文字的颜色
        // cancelColor: 'black',//取消文字的颜色
        showCancel: false
      })
        //光是积分的处理
      var shopList = [];
      var shulaing = wx.getStorageSync('shulaing')
      var price = wx.getStorageSync('commercialjifen')
      var jifen = wx.getStorageSync('jifen')
      var measure = wx.getStorageSync('measure')
      var style = wx.getStorageSync('style')
      that.setData({
        shulaing: shulaing,
        jifen: jifen,
        measure: measure,
        style: style,
        commercialjifen: price 
      })
      return;
    }
    if (commercialmoenystatus == 4){
      //积分加钱的处理
      var shopList = [];
      var shulaing = wx.getStorageSync('shulaing')
      var jifen = wx.getStorageSync('jifen')
      var measure = wx.getStorageSync('measure')
      var price = wx.getStorageSync('price')
      var style = wx.getStorageSync('style')
      that.setData({
        shulaing: shulaing,
        jifen: jifen,
        measure: measure,
        style: style,
      })
    wx.request({
      url: URL + 'Banner/account',
      data: {
        price: price,
        shulaing: shulaing
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      success: function(res) {
        var lat2 = res.data
        that.moneylist(lat2);
        that.setData({
          commercialjifen: res.data,
          
        })

      }
    })
    }
    return;
  },
  moneylist: function (lat2){
    var that = this
    var jifencolor = lat2
    try {
    var user = wx.getStorageSync('user') //用户id
    //var price = wx.getStorageSync('jifenmoentygoos') //商品价格
     
    var jifen = wx.getStorageSync('jifen') //商品积分
    wx.request({
      url: URL + 'Banner/commercialjifen1',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      data: {
        user: user['id'],
        jifen: jifen,
        price: jifencolor,
      },
      success: function (res) {
         wx.setStorage({
          key: "jifenmoentygoos",
          data: res.data.data
        })
      }
    })
    } catch (e) {
      // Do something when catch error
    }
  },
  //用户待支付
  onLoad: function(e) {
    var that = this;
    var buyNowid = wx.getStorageSync('buyNowid')
    try {
      if (buyNowid) {
       // console.log(buyNowid)
        wx.request({
          url: URL + 'Banner/buyNow',
          data: {
            buyNowid: buyNowid
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          method: 'post',
          success: function(res) {
            //.log(res.data)
            that.setData({
              buyNow: res.data,
            })

          }
        })

      }
    } catch (e) {
      /////
    }
    var user = wx.getStorageSync("user");
    wx.request({
      url: URL + 'Banner/siteinte2',
      data: {
        uid: user['id'],
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      success: function(res) {
        //console.log(res.data)
        that.setData({
          site: res.data,
        })
      }
    })
    this.setData({
      isNeedLogistics: 1,
    });
  },
  getDistrictId: function(obj, aaa) {
    if (!obj) {
      return "";
    }
    if (!aaa) {
      return "";
    }
    return aaa;
  },

  //提交订单
  createOrder: function(e) {
    var commercialmoenystatus = wx.getStorageSync('commercialmoenystatus')
    //如果支付状态未4的情况
    if (commercialmoenystatus == 4){
    let that = this;
    var remark = ""; // 备注信息
    if (e) {
      remark = e.detail.value.remark; // 备注信息
    }
    var postData = wx.getStorageSync("jifenmoentygoos");
    var jifen = wx.getStorageSync("jifen");
    var user = wx.getStorageSync("user");
    var openid = wx.getStorageSync("openid");
    var buyNowid = wx.getStorageSync("buyNowid");
    var code = wx.getStorageSync("code");
    wx.request({
      url: URL + 'Orders/createOrder',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        postData: postData,
        remark: remark,
        jifen: jifen,
        user: user['id'],
        openid: openid,
        buyNowid: buyNowid,
        code: code,
      }, // 设置请求的 参数

      success: (res) => {
        console.log(res.data)
        wx.requestPayment({
          timeStamp: res.data.data.pay_info['timestamp'].toString(),
          nonceStr: res.data.data.pay_info['noncestr'], //随机串
          package: "prepay_id=" + res.data.data.pay_info['prepayid'], //数据包
          signType: 'MD5',
          paySign: res.data.data.pay_info['paySign'],
          success: function(res) {
            console.log("支付成功")
            that.setPaySuccess(); //更新订单
            wx.redirectTo({
              url: "../jifendingdan/index"
          });
            return;
          },
          fail: function(res) {
            wx.showToast({
              title: '支付失败',
              icon: 'none',
              duration: 1000,
            })
            return;
          },
           complete: function (res) {
             wx.showToast({
               title: '取消支付',
               icon: 'none',
               duration: 1000,
             })
           }
        })   
      }
    })
    }
    //如果支付状态未3的情况
    if (commercialmoenystatus == 3){
      var commercialjifen = wx.getStorageSync("commercialjifen");//用户的积分
      var jifen = wx.getStorageSync("jifen");//商品的积分
      var user = wx.getStorageSync("user");//用户的id
      var shulaing = wx.getStorageSync("shulaing");//商品的数量
      wx.showModal({
        title: '温馨提示',
        content: '是否确定使用积分支付',
        // confirmColor: 'skyblue',//确定文字的颜色
        // cancelColor: 'black',//取消文字的颜色
        success(res) {
          if (res.confirm) {
            wx.request({
              url: URL + 'Banner/moneyisjifen',
              header: {
                'content-type': 'application/x-www-form-urlencoded'
              },
              method: 'post',
              data: {
                user: user['id'],
                jifen: jifen,
                commercialjifen: commercialjifen,
                shulaing: shulaing
              },
              success: function (res) {
                if (res.data.status){
                  wx.showToast({
                    title: '支付成功',
                    icon: 'none',
                    duration: 1000,
                  })
                  wx.redirectTo({
                    url: "../jifendingdan/index"
                  });
                  return;
                }else{
                  wx.showToast({
                    title: '支付失败',
                    icon: 'none',
                    duration: 1000,
                  })
                  return;
                }
              }
            })
          } else if (res.cancel) {
            wx.showToast({
              title: '您已取消支付',
              icon: 'none',
              duration: 1000,
            })
          }
        }
      })
    }
  },
  setPaySuccess:function(){
    var jifen = wx.getStorageSync("jifen");
    var shulaing = wx.getStorageSync("shulaing");
    var user = wx.getStorageSync("user");
    wx.request({
      url: URL +'Orders/setPaySuccess',
      method: 'POST',
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        jifen: jifen,
        shulaing:shulaing,
        user:user['id']
      },
      success: (res) => {
        //console.log(res.data)
        // if (res.data.code == 0) {
        //   that.setData({
        //     curAddressData: res.data.data
        //   });
        // } else {
        //   that.setData({
        //     curAddressData: null
        //   });
        // }
      }
    })
  },
  initShippingAddress: function() {
    var that = this;
    wx.request({
      url: 'https://api.it120.cc/' + app.globalData.subDomain + '/user/shipping-address/default',
      data: {
        token: wx.getStorageSync('token')
      },
      success: (res) => {
        if (res.data.code == 0) {
          that.setData({
            curAddressData: res.data.data
          });
        } else {
          that.setData({
            curAddressData: null
          });
        }
        that.processYunfei();
      }
    })
  },
  processYunfei: function() {
    var that = this;
    var goodsList = this.data.goodsList;
    var goodsJsonStr = "[";
    var isNeedLogistics = 0;
    var allGoodsPrice = 0;

    for (let i = 0; i < goodsList.length; i++) {
      let carShopBean = goodsList[i];
      if (carShopBean.logistics) {
        isNeedLogistics = 1;
      }
      allGoodsPrice += carShopBean.price * carShopBean.number;

      var goodsJsonStrTmp = '';
      if (i > 0) {
        goodsJsonStrTmp = ",";
      }


      let inviter_id = 0;
      let inviter_id_storge = wx.getStorageSync('inviter_id_' + carShopBean.goodsId);
      if (inviter_id_storge) {
        inviter_id = inviter_id_storge;
      }


      goodsJsonStrTmp += '{"goodsId":' + carShopBean.goodsId + ',"number":' + carShopBean.number + ',"propertyChildIds":"' + carShopBean.propertyChildIds + '","logisticsType":0, "inviter_id":' + inviter_id + '}';
      goodsJsonStr += goodsJsonStrTmp;


    }
    goodsJsonStr += "]";
    //console.log(goodsJsonStr);
    that.setData({
      isNeedLogistics: isNeedLogistics,
      goodsJsonStr: goodsJsonStr
    });
    that.createOrder();
  },
  addAddress: function() {
    wx.navigateTo({
      url: "/pages/address-add/index"
    })
  },
  selectAddress: function() {
    wx.navigateTo({
      url: "/pages/jifendizhi/index"
    })
  },
  getMyCoupons: function() {
    var that = this;
    wx.request({
      url: 'https://api.it120.cc/' + app.globalData.subDomain + '/discounts/my',
      data: {
        status: 0
      },
      success: function(res) {
        if (res.data.code == 0) {
          var coupons = res.data.data.filter(entity => {
            return entity.moneyHreshold <= that.data.allGoodsAndYunPrice;
          });
          if (coupons.length > 0) {
            that.setData({
              hasNoCoupons: false,
              coupons: coupons
            });
          }
        }
      }
    })
  },
  bindChangeCoupon: function(e) {
    const selIndex = e.detail.value[0] - 1;
    if (selIndex == -1) {
      this.setData({
        youhuijine: 0,
        curCoupon: null
      });
      return;
    }
    //console.log("selIndex:" + selIndex);
    this.setData({
      youhuijine: this.data.coupons[selIndex].money,
      curCoupon: this.data.coupons[selIndex]
    });
  }
})