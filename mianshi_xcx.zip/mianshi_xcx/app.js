App(require("./conmon/app.js")({
  onLaunch: function () {
    console.log();
    

  }, onShow: function () {
  },
  globalData: {
    // userInfo: null,
    islogin: false,

    // token: "",
    // uid: ""

  },


}));