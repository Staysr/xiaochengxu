let config = require("./config.js");
let thisapp = require("./this.js");

function wsLogin(callback) {
  wx.login({
    success: function (res) {
      if (res.code) {
        callback(res);

      } else {
        console.log('登录失败！')
      }
    }
  });
}


function api(uri, data, onSuccess, onError, showloding) {

  // console.log("data==>" + JSON.stringify(data.mJson))

  if (showloding) {
    ui.showLoading();
  }


  console.log("api-data-->" + uri, data);
  wx.request({
    url: config.api_base + uri,
    data: data,
    header: {
      'content-type': 'application/x-www-form-urlencoded' // 默认值
    },
    dataType: "json",
    method: "POST",
    success: function (ret) {
      console.log(ret);
      let data = ret.data;
      ui.hideLoading();
      if (data.code - 1 == 0) {
        if (onSuccess) {
          onSuccess(data.data, data);
        }
      } else {
        if (onError) {
          onError(data.msg, data.code, data)
        } else {
          wx.showModal({
            title: '错误信息',
            content: data.msg ? data.msg : "未知错误",
          });
        }
      }
    },
    fail: function (msg) {
      wx.showModal({
        title: '错误信息',
        content: msg,
      });
    }

  })
}


function apiloading(uri, data, onSuccess, onError) {

  api(uri, data, onSuccess, onError, 1);
}

let ui = {
  alert: function (msg, cancelText, confirmText, callback) {
    if (typeof cancelText == "function") {
      callback = cancelText;
      cancelText = null;
    }
    wx.showModal({
      title: '提示',
      showCancel: true,
      cancelText: cancelText ? cancelText : "取消",
      confirmText: confirmText ? confirmText : "确定",
      content: msg,
      success: callback
    });
  },
  showLoading: function (msg) {
    wx.showLoading({
      title: msg ? msg : "请稍等",
      mask: true

    })
  },
  hideLoading: function (msg) {
    wx.hideLoading();
  },
  confirm: function (msg, callback, concel) {
    wx.showModal({
      title: '提醒',
      content: msg,
      success: function (res) {
        if (res.confirm) {
          callback();
        } else {
          if (concel) concel();
        }
      }
    });
  }
};




function init(app) {
  app = thisapp(app);
  app.config = config,
    app.api = api;

  console.log("initinitinit")
  app.apiloading = apiloading;
  //app.wxLogin = wsLogin;
  app.ui = ui;
  app.bodyShow = function (obj) {
    obj.setData({
      body_show: true
    })
  };
  return app;
}
module.exports = init;