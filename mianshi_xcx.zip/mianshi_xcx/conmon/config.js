
// const web_root = "https://sq.wszx.cc/"
const web_root = "https://zhaopin.wszx.cc/";
const config = {

  api_base: `${web_root}api.php?app=`,
   web_root:web_root
};
module.exports =  config;  























