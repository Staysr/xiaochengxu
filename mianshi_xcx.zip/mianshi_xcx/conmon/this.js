function _ongetopenid(openid) {
}

function login(page) {

  var app = this;

  if (app.globalData.islogin) {
    return true;
  } else {

    // var user = wx.getStorageSync("user");
    // if (user) {
    //   this.onLogin(user);
    //   return true;
    // }

    var url = "/" + page.route + "?";
    for (var index in page.options) {
      url = url + index + "=" + page.options[index] + "&"
    }

    

    // app.wxLogin(function(res) {

    //   if (!res.code)
    //   {
    //     app.ui.alert("授权失败");
    //     return;
    //   }
    //   console.log('res.code',res.code)
    //   app.api("user@wx_bind", {
    //     code: res.code
    //   }, function(data) {
    //     console.log("ddd");
    //     wx.setStorageSync("openid", data.openid);
    //     console.log(data);

    //     wx.redirectTo({
    //       url: '/pages/login/login?url=' + encodeURIComponent(url),
    //     })

    //   });
    // });
  }

}


function onLogin(user) {
  // wx.setStorageSync("user", user)
  this.globalData.islogin = true;
  // this.globalData.token = user.token;
  // this.globalData.uid = user.uid;
  // this.globalData.name = user.username;
}

function api(uri, data, onSuccess, onError) {
  data.token = this.globalData.token;
  this.api(uri, data, onSuccess, onError);
}




function init(app) {

  app.login = login;
  app.onLogin = onLogin;
  app.apitoken = api;
  app.getOpenId = function() {

    return wx.getStorageSync("openid");
  };
  app.page = function(page) {
      page.onLoad = function(options) {
        let islogin = app.login(this);
        console.log(islogin);
        if (islogin) {
          this.onLogin(options);
        }
      };
      return page;
    },
    app.goHome = function() {
      wx.redirectTo({
        url: '/pages/ucenter/ucenter',
      });
    }
  return app;
}
module.exports = init;