const xueli = ['请选择','高中','专科','本科','硕士','博士']

module.exports = xueli;  