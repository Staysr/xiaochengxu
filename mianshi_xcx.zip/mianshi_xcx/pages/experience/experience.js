
var app = getApp()
Page({
  data: {
    lists: [{}],
    listswork: [{}],
    array: [0],//默认显示一个,
    array1: [0],//默认显示一个,
    type: true,
    type1:true,
    index1:0,
    xueli:['高中', '专科', '本科', '硕士', '博士'],
    num1:0,
    list: [{
      jiaoyu_time_start: '',
      school_name:'',
      zhuanye:'',
      xueli:'',
      jiaoyu_time_end:''
    }],
    list1: [{
      zm_user: '',
      zm_phone: '',
      result: '',
      money: '',
      zhiwu:'',
      company:'',
      work_time_start:'',
      work_time_end:''
    }],
  },
  addList: function (e) {
    var self = this;
    let list = self.data.list;
    var num = e.currentTarget.dataset.idx
   // let input = 'list[' + num + '].jiaoyu_time_start'
    var old = self.data.array;
    old.push(1);//这里不管push什么，只要数组长度增加1就行
    list.push({
      jiaoyu_time_start: '',//开始时间
      school_name: '',
      zhuanye: '',
      xueli: '',
      jiaoyu_time_end: ''//结束时间
    })
    self.setData({
      lists: list,
      type: false,
      num: num,
  
    })
    // var data_jiaoyu = self.data.list
    // console.log(data_jiaoyu)
    // for (var i = 0; i < data_jiaoyu.length; i++) {
    //   if (data_jiaoyu[i].jiaoyu_time_start == "" || data_jiaoyu[i].zhuanye == "" || data_jiaoyu[i].xuexiao == "" ||data_jiaoyu[i].xueli == "") {
    //     wx.showToast({
    //       title: "填写内容不能为空",
    //       icon: "none",
    //       duration: 1500,
    //       mask: true
    //     })
    //     return false
    //   }else{
        
    //   }
    // }
  },
  addListwork:function(e){
    var self = this;
    var old = self.data.array1;
    var idx = e.currentTarget.dataset.idx
    if (idx == undefined || idx == "" || idx == []){
      wx.showToast({
          title: "填写内容不能为空",
          icon: "none",
          duration: 1500,
          mask: true
        })
        return false
    }
    var numc = ++e.currentTarget.dataset.index1
    self.setData({
      index1: numc,
      idx: idx.length
    })
    old.push(1);//这里不管push什么，只要数组长度增加1就行
    let list1 = self.data.list1;
    list1.push({
      zm_user: '',
      zm_phone: '',
      result: '',
      money: '',
      zhiwu: '',
      company: '',
      work_time_start: '',
      work_time_end: ''
    })
    var num1 = e.currentTarget.dataset.idx
    console.log(list1)
    self.setData({
      listswork: list1,
      type1: false,
      num1: num1
    })
  },
  delList: function (e) {
    var self = this;
    var nowidx = e.currentTarget.dataset.idx;//当前索引
    if (!nowidx == 0) {
      var oldarr = this.data.array;//循环内容
      
      var num = e.currentTarget.dataset.num;
      let list = self.data.list;
      if (num == 0){
        var num1 = num+1
      }
      list.splice(num1, 1);
      
      oldarr.splice(nowidx, 1);    //删除当前索引的内容，这样就能删除view了
      if (oldarr.length < 1) {
        oldarr = [0]  //如果循环内容长度为0即删完了，必须要留一个默认的。这里oldarr只要是数组并且长度为1，里面的值随便是什么
      }
      console.log(nowidx)
      console.log(list)
      this.setData({
        lists: list,
        num: num,
        center: list
      })
    }
  },
  delListwork:function(e){
    var self = this;
    var nowidx = e.currentTarget.dataset.index1;//当前索引
    if (!nowidx == 0) {
      var oldarr = this.data.array1;//循环内容
      var num1 = e.currentTarget.dataset.num;
      let list = self.data.list1;
      if (num1 == 0) {
        var num1 = num1 + 1
      }
      list.splice(num1, 1);
      oldarr.splice(nowidx, 1);    //删除当前索引的内容，这样就能删除view了
      if (oldarr.length < 1) {
        oldarr = [0]  //如果循环内容长度为0即删完了，必须要留一个默认的。这里oldarr只要是数组并且长度为1，里面的值随便是什么
      }
      console.log(nowidx)
      console.log(list)
      self.setData({
        listswork: list,
        num1: num1,
        data_work: list
      })
    }
  },
 
  
  bindKeyInputwork4:function(e){
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input = 'list[' + id + '].company'
    let list = self.data.list1; 
    list[id].company = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      data_work: list
    })
  },
  bindKeyInputwork5: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input = 'list[' + id + '].zhiwu'
    let list = self.data.list1;
    list[id].zhiwu = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      data_work: list
    })
  },
  bindKeyInputwork6: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input = 'list[' + id + '].money'
    let list = self.data.list1;
    list[id].money = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      data_work: list
    })
  },
  bindKeyInputwork7: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input = 'list[' + id + '].zm_user'
    let list = self.data.list1;
    list[id].zm_user = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      data_work: list
    })
  },
  bindKeyInputwork8: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input = 'list[' + id + '].zm_phone'
    let list = self.data.list1;
    list[id].zm_phone = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      data_work: list
    })
  },
  bindKeyInputwork9: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input = 'list[' + id + '].result'
    let list = self.data.list1;
    list[id].result = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      data_work: list
    })
  },
  bindKeyInput1:function(e){
    var self = this;
    var id = e.currentTarget.dataset.id
    let input = 'list[' + id + '].school_name'
    let list = self.data.list;
    list[id].school_name = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      center: list
    })
  },
  bindKeyInput2:function(e){
    var self = this;
    var id = e.currentTarget.dataset.id
    let input = 'list[' + id + '].zhuanye'
    let list = self.data.list;
    list[id].zhuanye = e.detail.value;
    console.log(list)
    self.setData({
      input: e.detail.value,
      center: list
    })
  },
  bindKeyInput3:function(e){
    var self = this;
  
    var id = e.currentTarget.dataset.id
    let input2 = 'lists[' + id + '].xueli'
    let list = self.data.list;
    list[id].xueli = self.data.xueli[e.detail.value];
    console.log(list)
    self.setData({
      [input2]: self.data.xueli[e.detail.value],
      center: list
    })
  },
  bindKeyInputjiaoyu_start: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value);
   //return;  

    var self = this;
    var id = e.currentTarget.dataset.id
    let input2 = 'lists[' + id + '].jiaoyu_time_start'
    let list = self.data.list;
    list[id].jiaoyu_time_start = e.detail.value;
    
    var date = e.detail.value
      console.log(date)
    self.setData({
      [input2]:e.detail.value,
      date: date,
      center: list
    })
  },
  bindKeyInputjiaoyu_end: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    let input2 = 'lists[' + id + '].jiaoyu_time_end'
    let list = self.data.list;
    list[id].jiaoyu_time_end = e.detail.value;
    console.log(e.detail.value)
    var date=e.detail.value
    self.setData({
      [input2]: e.detail.value,
      date1: date,
      center: list
    })
  },
  bindKeyInputjingli_start: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input2 = 'listswork[' + id + '].work_time_start'
    let list = self.data.list1;
    list[id].work_time_start = e.detail.value;
    console.log(list)
    self.setData({
      [input2]: e.detail.value,
      data2: list,
      data_work: list
    })
  },
  bindKeyInputjingli_end: function (e) {
    var self = this;
    var id = e.currentTarget.dataset.id
    console.log(e)
    let input2 = 'listswork[' + id + '].work_time_end'
    let list = self.data.list1;
    list[id].work_time_end = e.detail.value;
    console.log(list)
    self.setData({
      data3: e.detail.value,
      data_work: list,
      [input2]: e.detail.value,
    })
  },

  netWorkData: {},

  dopost:function(e){
    console.log(e);
    var that = this
    this.netWorkData = e.currentTarget.dataset;
    for(var index in this.netWorkData)
    {
      this.netWorkData[index] = typeof this.netWorkData[index] == "object" ? JSON.stringify(this.netWorkData[index]) : this.netWorkData[index];
    }
    return false;
    var id = wx.getStorageSync('id')
    this.netWorkData.id = id;
    app.apiloading("apply@apply_2", this.netWorkData, function (data) {
      console.log("data-->", JSON.parse(data))
      // wx.navigateTo({
      //   url: '/pages/experience/experience',
      // })
    })
  }
  

})
