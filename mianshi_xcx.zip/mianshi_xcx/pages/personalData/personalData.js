var util = require('../../utils/util.js');
var nation1 = require('../../conmon/nation.js');
var xueli = require('../../conmon/xueli.js');
var app = getApp()
Page({
  data: {
    job: {},
    nation1: {},
    xueli: {},
    type: "true",
    status: "true",
    marriage: false,
    showView: false, //通过true 和 false 来控制显示隐藏
    items: [{
      name: '1',
      value: '男',

    },
    {
      name: '2',
      value: '女',
    }
    ],
    mianmao: [{
      name: '1',
      value: '群众',
    },
    {
      name: '2',
      value: '党员',
    }
    ],
    array: ['请选择', '否', '是'],
    objectArray: [{
      id: 0,
      name: ''
    },
    {
      id: 1,
      name: '否'
    },
    {
      id: 2,
      name: '是'
    },
    ],
    array1: ['请选择', '群众', '党员'],
    objectArray: [{
      id: 0,
      name: ''
    },
    {
      id: 1,
      name: '群众'
    },
    {
      id: 2,
      name: '党员'
    },
    ],
    index3: 0,
    index4: 0,
  },
  netWorkData: {},
  onLoad: function (options) {
    var that = this
    var time = util.formatTime(new Date());
    // 再通过setData更改Page()里面的data，动态更新页面的数据 
    this.setData({
      time: time,
      nation1: nation1,
      xueli: xueli
    });

    console.log("000");
    app.apiloading("apply@job_list", null, function (res) {
      console.log("000", res);
      that.setData({
        job: res
      })
      app.bodyShow(that);
    })



  },
  bindPickerChange: function (e) { //婚姻状态方法
    console.log('picker发送选择改变，携带值为', e.detail.value)

    if (this.data.array[e.detail.value] == "是") {
      this.setData({
        marriage: true
      })
    } else {
      this.setData({
        marriage: false
      })
    }
    this.setData({
      index1: e.detail.value,
      type: "false",
    })
  },
  bindPickerChange2: function (e) { //民族方法
    console.log(this.data.nation1[e.detail.value])
    wx.setStorageSync("minzu", this.data.nation1[e.detail.value]);

    this.setData({
      index: e.detail.value,
      status: "false"
    })

  },
  bindPickerChange3: function (e) { //民族方法
    console.log('政治面貌发送选择改变，携带值为', e.detail.value)

    this.setData({
      index3: e.detail.value,

    })

  },
  bindPickerChange4: function (e) { //
    console.log(this.data.xueli[e.detail.value])
    wx.setStorageSync("xueli1", this.data.xueli[e.detail.value]);
    this.setData({
      index4: e.detail.value,
      status: "false"
    })

  },
  dopost: function (e) {
    var data = e.detail.value;
    console.log(data)
    this.netWorkData = e.detail.value;
    var xueli1 = wx.getStorageSync('xueli1');
    var h_xueli = xueli1;
    this.netWorkData.h_xueli = h_xueli;
    var minzu = wx.getStorageSync('minzu');
    var nation = minzu;
    this.netWorkData.nation = nation;

    console.log(this.netWorkData);

    app.apiloading("apply@apply_1", this.netWorkData, function (data) {
      console.log("data-->", JSON.stringify(data))
      wx.setStorageSync('id', data.id);
      console.log(data.id);
      return false;
      wx.navigateTo({
        url: '/pages/experience/experience',
      })
    })
  }
})