function formatTime(date) {  
  var year = date.getFullYear()  
  var month = date.getMonth() + 1  
  var day = date.getDate()  
  
  var hour = date.getHours()  
  var minute = date.getMinutes()  
  var second = date.getSeconds()  
  
  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')  
}  
  
function formatNumber(n) {  
  n = n.toString()  
  return n[1] ? n : '0' + n  
}


function  login(){
  var useIfor = wx.getStorageSync('userInfo')
  if (useIfor == '' || userinfo == underfined) {
    wx.redirectTo({
      url: '/pages/login/login',
    })
  }
}
  
module.exports = {  
  formatTime: formatTime,  
  login:login
}  