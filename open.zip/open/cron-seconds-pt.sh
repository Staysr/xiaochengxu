curl "https://你的域名/LKT/index.php?module=api&action=test"
curl "https://你的域名/LKT/index.php?module=api&action=getcode"