class Base {
    constructor() {
      this.baseRequestUrl = 'http://localhost/v1/public/api/v1/';
    }

    /**
     * 封装网络请求
     */
    request(params) {
      //console.log(params.data.code)
        var url = this.baseRequestUrl + params.url;
        if (!params.type) {
            params.type = 'GET';
        }
        // wx.showLoading({
        //   title: '加载中',
        //   mask:true
        // });
        var that = this;

        wx.request({
            url: url,
            data: params.data,
            method: params.type,
            header: {
                'content-type': 'application/json',
                'token': wx.getStorageSync('token')
            },
            success: function (res) {
              //console.log(res)
              //callBack(res.data);
                // wx.hideLoading();
                if (res.statusCode == 401) {
                    that.getCode(params);
                } else if (res.statusCode == 500) {
                    wx.showToast({
                        icon: 'none',
                        title: res.data.msg,
                    });
                } else {
                    params.success && params.success(res);
                }
            },
            fail: function (err) {
                console.log('err');
            }
        })
    }
    
    getCode(params) {
        var that = this;
        wx.login({
            success: function (res) {
                that.doLogin(params, res.code);
            }
        })
    }
    doLogin(params, data) {
      //return "#123"
        var url = this.baseRequestUrl + '/user';
        var that = this;
        wx.request({
            url: url,
            method: 'POST',
            data: {
                code: data
            },
            success: function (res) {
                if (res.statusCode == 200) {
                    wx.setStorageSync('token', res.data.token);
                    wx.setStorageSync('session_key', res.data.session_key);
                    that.request(params)
                } else {
                    wx.showToast({
                        icon: 'none',
                        title: res.data.msg,
                    });
                    that.request(params);
                }
            }
        })
    }
}
export { Base };