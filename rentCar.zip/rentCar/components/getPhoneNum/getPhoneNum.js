// components/getPhoneNum.js
const app = getApp()
const url = app.globalData.staticUrl;
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    isGetPhone: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 小程序获取微信
    bindgetphonenumber: function(e) {
      console.log(e)
      var that = this;
      var nikname = e.detail.userInfo.nickName
      var headimg = e.detail.userInfo.avatarUrl
      wx.login({
        success(res) {
          wx.request({
            url: url + 'index/getuserinfo',
            data: {
              code: res.code,
              nickname: nikname,
              head: headimg
            },
            success(res) {
              console.log(res)
              that.setData({
                isGetPhone: true
              })
            }
          })
        }
      })
    }
  }
})