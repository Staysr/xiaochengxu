// pages/address/address.js
const app = getApp()
const url = app.globalData.staticUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  edit() {
    wx.removeStorageSync("defa")
    wx.navigateTo({
      url: '../addto/addto?type=edit',
    })
  },
  addto() {
    wx.removeStorageSync("defa")
    wx.navigateTo({
      url: '../addto/addto?type=deposit',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options)
    var that = this;
    var type = options.type;
    that.setData({
      type: type
    })
    switch (type) {
      case "my":
        break;
      case "":
        break
    }
    var uid = wx.getStorageSync("data")
    wx.request({
      url: url + 'user/addslist',
      data: {
        uid: uid.id,
        
      },
      success(res) {
        console.log(res)
        that.setData({
          list: res.data.data,
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var defal = wx.getStorageSync("defa")
    var name = wx.getStorageSync("name")
    var tle = wx.getStorageSync("tle")
    var add = wx.getStorageSync("add")
    var route = wx.getStorageSync("route")
    var address = wx.getStorageSync("address")
    this.setData({
      name: name,
      tle: tle,
      add: add,
      route: route,
      defal: defal
    })
    if (route == "pages/addto/addto") {
      this.setData({
        prov: address[0],
        city: address[1],
        area: address[2]
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})