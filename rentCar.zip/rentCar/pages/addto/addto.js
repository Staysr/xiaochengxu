// pages/addto/addto.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    editTrue: true,
    curIdx: null,
    region: ['请选择省', '请选择市', '请选择区'],
    img: [{
      imgUrl: '../../images/select.png',
      curUrl: '../../images/selected.png'
    }],
  },
  chooseImg: function (e) {
    this.setData({
      curIdx: e.currentTarget.dataset.current
    })
  },
  bindRegionChange: function (e) {
    this.setData({
      region: e.detail.value
    })
    wx.setStorageSync("address", e.detail.value)
  },
  showedit: function (e) {
    var that = this;
    if (that.data.editTrue == true) {
      that.setData({
        editTrue: false,
      })
    } else {
      that.setData({
        editTrue: true,
      })
    }
    console.log(that.data.editTrue)
    wx.setStorageSync("defa", that.data.editTrue)
  },
  name(e) {
    name: e.detail.value
    wx.setStorageSync("name", e.detail.value)
  },
  tle(e) {
    tle: e.detail.value
    wx.setStorageSync("tle", e.detail.value)
  },
  address(e) {
    add: e.detail.value
    wx.setStorageSync("add", e.detail.value)
  },
  deposit(e) {
    var userName = e.detail.value.name;
    var mobile = e.detail.value.tle;
    var phonetel = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    var name = /^[u4E00-u9FA5]+$/;
    if (userName == '') {
      wx.showToast({
        title: '请输入用户名',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false
    } else if (mobile == '') {
      wx.showToast({
        title: '手机号不能为空',
        icon: 'none',
        duration: 1000,
      })
      return false
    } else if (mobile.length < 11) {
      wx.showToast({
        title: '手机号长度有误！',
        icon: 'none',
        duration: 1500
      })
      return false;
    }
    var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
    if (!myreg.test(mobile)) {
      wx.showToast({
        title: '手机号有误！',
        icon: 'none',
        duration: 1500
      })
      return false;
    }
    let pages = getCurrentPages();
    let prevpage = pages[pages.length - 1];
    let route = prevpage.route;
    wx.setStorageSync('route', route)
    wx.navigateBack({})
  },
  dele(e) {
    wx.removeStorageSync('name'),
      wx.removeStorageSync('tle'),
      wx.removeStorageSync('add'),
      wx.removeStorageSync('address'),
      wx.removeStorageSync("route")
    wx.navigateBack({})
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var type = options.type;
    that.setData({
      type: type
    })
    switch (type) {
      case 'edit':
        break;
      case 'deposit':
        break
    }
    if (type == 'edit') {
      var name = wx.getStorageSync("name")
      var tle = wx.getStorageSync("tle")
      var add = wx.getStorageSync("add")
      var address = wx.getStorageSync("address")
      this.setData({
        add: add,
        name: name,
        tle: tle,
        prov: address[0],
        city: address[1],
        area: address[2]
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (e) { },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})