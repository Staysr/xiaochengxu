// pages/choice/choice.js
var seller = require('../../utils/util.js')
var itemtxt = []
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:'',
    chooseload: false,
    choose: false,
    data: [1, 2, 3],
    detaHide: true,
    detaFade: '',
    detaiHide: true,
    detailFade: '',
    car: [{
      carimg: "../../images/car.png",
      carname: "大众",
      cartxt: "三箱|1.6自动|乘坐5人",
      carmoney: "￥69/日均",
      key: '￥2.5/km',
      daykey: "司机200元/天+车300元/天",
    },{
      carimg: "../../images/car.png",
      carname: "比亚迪",
      cartxt: "三箱|1.6自动|乘坐5人",
      carmoney: "￥69/日均",
      key: '￥2.5/km',
      daykey: "司机200元/天+车300元/天",
    }],
    brandList: [{
      isSelected: false,
      title: '宝马',
      id: 'one',
    }, {
      isSelected: false,
      title: '奥迪',
      id: 'two',
    }, {
      isSelected: false,
      title: '劳斯莱斯',
      id: 'three',
    }, {
      isSelected: false,
      title: '凯迪拉克',
      id: 'four',
    }, ],
    // one: [{
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '全部',
    // }, {
    //   isSelected: false,
    //   type: '大众Polo',
    // }, {
    //   isSelected: false,
    //   type: '朗逸',
    // }, {
    //   isSelected: false,
    //   type: '桑塔纳',
    // }],
    // two: [{
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '全部1',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '大众Polo1',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '朗逸1',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '桑塔纳1',
    // }],
    // three: [{
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '全部2',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '大众Polo2',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '朗逸2',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '桑塔纳2',
    // }],
    // four: [{
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '全部3',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '大众Polo3',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '朗逸3',
    // }, {
    //   typetxt: "系列(多选)",
    //   isSelected: false,
    //   type: '桑塔纳3',
    // }],
    selectarr: []
  },
  // itemSelected: function(e) {
  //   var index = e.currentTarget.dataset.index;
  //   var item = this.data.list[index];
  //   var select = item.isSelected
  //   item.isSelected = !item.isSelected;
  //   this.setData({
  //     list: this.data.list,
  //   });
  // },
  chooseType: function(e) {
    //记录上次点击的对象的序号
    var oldidx = this.data.currentidx;
    //记录当前点击的对象的序号
    var currentidx = e.currentTarget.dataset.idx;
    var typetxt = this.data.brandList[currentidx]
    var brandList = this.data.brandList;
    // for(var i = 0;i<brandList.length;i++){
    //   brandList[i].isSelected = false;
    // }
    if (oldidx == currentidx) {
      var choose = this.data.choose;
      // var typetext = itemtxt.indexOf(typetxt.type)
      // itemtxt.splice(typetext, 1)
      this.setData({
        currentidx: currentidx,
        choose: !choose,
        currentidx: 'noindx',
        brandList: brandList,
        list: ''
      })
    } else {
      // if ((oldidx == 0 || oldidx) && oldidx != 'noindx') {
      //   var typetex = itemtxt.indexOf(this.data.brandList[oldidx].type)
      //   itemtxt.splice(typetex, 1)
      // }
      // itemtxt.push(typetxt.type)
      // console.log(itemtxt)
      // var listid = e.currentTarget.dataset.itemid
      // var list = [];
      // if (listid == 'one') {
      //   list = this.data.one
      // } else if (listid == 'two') {
      //   list = this.data.two
      // } else if (listid == 'three') {
      //   list = this.data.three
      // } else if (listid == 'four') {
      //   list = this.data.four
      // }
      this.setData({
        currentidx: currentidx,
        choose: true,
        brandList: brandList,
        // list: list,
      });
    }
  },

  bindload: function(event) {
    var classify = event.currentTarget.dataset.classify;
    var that = this;
    this.setData({
      loaditem: classify,
    })
  },
  tips(e) {
    this.setData({
      detaHide: false
    })
    var index = e.currentTarget.dataset.index;
    var item = this.data.car[index];
    wx.setStorageSync('car', item)
  },
  readDeta() {
    this.setData({
      detaFade: 'transitionFade fade',
      detaHide: true,
    })
  },
  fadeDeta(e) {
    this.setData({
      detaFade: 'transitionFade fade',
      detaHide: true,
    })
    wx.navigateTo({
      url: '../confirm/confirm?type=expert',
    })
  },
  detailShow() {
    this.setData({
      detaiHide: false
    })
  },
  fadeDetai() {
    var item = this.data.brandList
    for (var i = 0; i < item.length; i++) {
      item[i].isSelected = false;
    }
    this.setData({
      detailFade: 'transitionFade fade',
      detaiHide: true,
      chooseload: false,
      choose: false,
      brandList: item,
      currentloadidx: 'noindx',
      currentidx: 'noindx',
      list: '',
    })
    itemtxt = []
  },
  readDetai() {
    this.setData({
      detailFade: 'transitionFade fade',
      detaiHide: true,
      itemtxt: itemtxt
    })
  },
  hideDetail() {
    this.setData({
      detailFade: ''
    })
  },
  changeCar(e) {
    var index = e.currentTarget.dataset.index;
    var item = this.data.car[index];
    wx.setStorageSync('car', item)
    var that = this;
    let pages = getCurrentPages();
    let prevpage = pages[pages.length - 2];
    if (prevpage.route == 'pages/speed/speed') {
      wx.navigateTo({
        url: '../confirm/confirm?type=speed'
      })
    }
    if (prevpage.route == 'pages/rent/rent') {
      wx.navigateTo({
        url: '../confirm/confirm?type=rent'
      })
    }
    if (prevpage.route == 'pages/expert/expert') {
      wx.navigateTo({
        url: '../confirm/confirm?type=expert'
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var itemId = wx.getStorageSync('itemId')
    console.log(itemId)
    var typee = options.typee;
    this.setData({
      typee: typee,
      itemId: itemId
    })

    switch (typee) {
      case 'expert':
        break;
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})