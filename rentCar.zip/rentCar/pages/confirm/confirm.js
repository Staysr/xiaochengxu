1 // pages/confirm/confirm.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    editTrue: false,
    agreement: '租车速派协议',
  },
  showedit: function (e) {
    var that = this;
    if (that.data.editTrue == true) {
      that.setData({
        editTrue: false,
      })
    } else {
      that.setData({
        editTrue: true,
      })
    }
  },
  success: function () {
    wx.reLaunch({
      url: '../success/success',
    })
  },
  discount() {
    wx.navigateTo({
      url: '../discount/discount',
    })
  },
  agree() {
    var that = this
    wx.navigateTo({
      url: '../rule/rule?txt=' + that.data.agreement,
    })
  },
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh(),
      setTimeout(function () {
        wx.hideLoading();
      }, 1000);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var type = options.type;
    that.setData({
      type: type,
    })

    switch (type) {
      case 'expert':
        break;
      case 'speed':
        break
      case 'rent':
        break
        case '':
        break
    }
    var car = wx.getStorageSync("car")
    var itemId = wx.getStorageSync('itemId')
    var on = wx.getStorageSync("start")
    var en = wx.getStorageSync('end')
    var not = wx.getStorageSync('not')
    this.setData({
      on: on,
      en: en,
      img: car.carimg,
      car: car.carname,
      cartxt: car.cartxt,
      itemId: itemId
    })
    if (itemId == "wind") {
      var spemetxt = wx.getStorageSync('spemetxt')
      var speentxt = wx.getStorageSync('speentxt')
      this.setData({
        spemetxt: speentxt,
        speentxt: spemetxt
      })
    } else {
      var spemetxt = wx.getStorageSync('spemetxt')
      var speentxt = wx.getStorageSync('speentxt')
      this.setData({
        spemetxt: spemetxt,
        speentxt: speentxt
      })
    };
    if (itemId == "schedule" || itemId == "rent") {
      var date = wx.getStorageSync('selectdate').selected
      var hour = wx.getStorageSync('hour')
      var time = date.dates + '\t' + date.week;
      var endate = wx.getStorageSync('enselectdate').selected
      var enhour = wx.getStorageSync('enhour')
      var sctime = date.dates
      var scentime = endate.dates
      var schour = date.week + "\t" + hour
      var scenhour = endate.week + '\t' + enhour
      this.setData({
        sctime: sctime,
        scentime: scentime,
        schour: schour,
        scenhour: scenhour
      })
    } else {
      var date = wx.getStorageSync('selectdate').selected
      var hour = wx.getStorageSync('hour')
      var time = date.dates + '\t' + date.week;
      this.setData({
        time: time,
        hour: hour,
      })
    };
    if (itemId == "expert") {
      var cost = wx.getStorageSync('cost')
      var dis = wx.getStorageSync('dis')
      this.setData({
        dis: dis,
        cost: cost,
      })
    } else if (itemId == 'schedule') {
      var rzctxt = wx.getStorageSync('rzctxt')
      var rzcdiver = wx.getStorageSync("rzcdiver")
      this.setData({
        dis: rzctxt,
        cost: rzcdiver
      })
    } else {
      this.setData({
        dis: '保证金',
        cost: '租车费用'
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var discount = wx.getStorageSync("not");
    if (discount) {
      this.setData({
        not: discount
      })
    } else {
      this.setData({
        not: '请选择优惠'
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () { },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})