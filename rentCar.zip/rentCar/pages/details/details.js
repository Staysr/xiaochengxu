// pages/details/details.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var itemId = wx.getStorageSync("itemId")
    var cantxt = wx.getStorageSync('cantxt')
    this.setData({
      itemId: itemId,
      cantxt:cantxt
    })
    if(itemId == 'schedule'||itemId == 'expert'){
      var on = wx.getStorageSync("start")
      var en = wx.getStorageSync('end')
      this.setData({
        spemetxt:on,
        speentxt:en        
      })
    }else{
      var spemetxt = wx.getStorageSync('spemetxt')
      var speentxt = wx.getStorageSync('speentxt')
      this.setData({
        spemetxt: spemetxt,
        speentxt: speentxt,
      })
    }
    if (itemId == "schedule" || itemId == "rent") {
      var date = wx.getStorageSync('selectdate').selected
      var hour = wx.getStorageSync('hour')
      var time = date.dates + '\t' + date.week;
      var endate = wx.getStorageSync('enselectdate').selected
      var enhour = wx.getStorageSync('enhour')
      var sctime = date.dates
      var scentime = endate.dates
      var schour = date.week + "\t" + hour
      var scenhour = endate.week + '\t' + enhour
      this.setData({
        sctime: sctime,
        scentime: scentime,
        schour: schour,
        scenhour: scenhour
      })
    } else {
      var date = wx.getStorageSync('selectdate').selected
      var hour = wx.getStorageSync('hour')
      var time = date.dates + '\t' + date.week;
      this.setData({
        time: time,
        hour: hour,
      })
    };
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var car = wx.getStorageSync("car")
    this.setData({
      img: car.carimg,
      car: car.carname,
      cartxt: car.cartxt,
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})