// pages/drawbill/drawbill.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    curIdx: 0,
    curIndex: 0,
    itemId:"paper",
    idxId:'pers',
    listInfo: [{
      imgUrl: '../../images/select.png',
      curUrl: '../../images/selected.png',
      txt: '纸质发票',
      id: "paper"
    }, {
      imgUrl: '../../images/select.png',
      curUrl: '../../images/selected.png',
      txt: '电子发票',
      id: "electric"
    }],
    listTxt: [{
      imgUrl: '../../images/select.png',
      curUrl: '../../images/selected.png',
      txt: '个人',
      id: "pers"
    }, {
      imgUrl: '../../images/select.png',
      curUrl: '../../images/selected.png',
      txt: '企业',
      id: "enter"
    }],
    listAdd: [{
      addtxt: '收货地址',
      addtext: '添加收货地址',
      addimg: '../../images/arrow.png'
    }],
    listEle:[{
      eletxt:'电子邮箱'
    }]
  },
  address(e){
    wx.navigateTo({
      url: '../address/address?type',
    })
  },
  chooseImg: function(e) {
    this.setData({
      curIndex: e.currentTarget.dataset.current,
      itemId: e.currentTarget.dataset.itemid
    })
  },
  img: function(e) {
    this.setData({
      curIdx: e.currentTarget.dataset.current,
      idxId: e.currentTarget.dataset.idxid
    })
  },
  invoice(e) {
    wx.navigateTo({
      url: '../invoice/invoice',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})