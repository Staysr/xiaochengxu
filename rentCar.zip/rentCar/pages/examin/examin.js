// pages/examin/examin.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tempFilePaths: '',
    noSelect: '../../images/trouble-normal.png',
    hasSelect: '../../images/trouble-selected.png',
    repContent: [{
      sureid: false,
      message: '车辆外观有损'
    }, {
      sureid: false,
      message: '油量/里程异常'
    }, {
      sureid: false,
      message: '空调故障'
    }, {
      sureid: false,
      message: '车灯不亮'
    }, {
      sureid: false,
      message: '证照缺失'
    }, {
      sureid: false,
      message: "车窗/天窗问题"
    }, {
      sureid: false,
      message: "车内脏污"
    }, {
      sureid: false,
      message: '其他原因'
    }],
  },
  prese(e) {
    wx.switchTab({
      url: '../order/order',
    })
  },
  chooseimage: function(e) {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        that.setData({
          ['tempFilePaths[' + e.target.id + ']']: res.tempFilePaths[0]
        })
      }
    })
  },
  selectRep: function(e) {
    let index = e.currentTarget.dataset.selectindex; //当前点击元素的自定义数据，这个很关键
    let selectIndex = this.data.repContent; //取到data里的selectIndex
    selectIndex[index].sureid = !selectIndex[index].sureid; //点击就赋相反的值
    wx.setStorageSync("selectxt",selectIndex[index].message)
    this.setData({
      selectIndex: selectIndex //将已改变属性的json数组更新
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})