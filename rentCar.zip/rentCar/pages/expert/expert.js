// pages/rent/rent.js
var util = require('../../utils/util.js');
const app = getApp()
var scenall = []
var scall = []
Page({
  data: {
    endateList: [],
    enhours: [],
    endate: {},
    dateList: [],
    hours: [],
    date: {},
    todayhour: "",
    showselect: false,
    enshowselect: false,
    ex_txt: '专车接站租车规则',
    itemId: 'expert',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    isHide: false,
    rzctxt: "租车费用",
    rzcdiver: "司机",
    dis: '距离',
    cost: '费用',
  },
  selectRouter(e) {
    this.setData({
      itemId: e.currentTarget.dataset.itemid
    })
  },
  showDate: function() {
    var showselect = true
    this.setData({
      showselect: showselect
    })
  },
  cancel: function() {
    var showselect = false
    this.setData({
      showselect: showselect
    })
  },
  determine: function() {
    var showselect = false
    this.setData({
      showselect: showselect
    })
  },
  enshowDate: function() {
    var enshowselect = true
    this.setData({
      enshowselect: enshowselect
    })
  },
  encancel: function() {
    var enshowselect = false
    this.setData({
      enshowselect: enshowselect
    })
  },
  endetermine: function() {
    var enshowselect = false
    this.setData({
      enshowselect: enshowselect
    })
  },
  choice() {
    wx.setStorageSync('spemetxt', this.data.spemetxt)
    wx.setStorageSync('speentxt', this.data.speentxt)
    var itemId = "expert"
    wx.setStorageSync("itemId", itemId)
    wx.setStorageSync("dis", this.data.dis)
    wx.setStorageSync("cost", this.data.cost)
    if (this.data.start == "请选择起点") {
      wx.showToast({
        title: '请选择起点位置',
        icon: 'none'
      })
      return
    };
    if (this.data.end == "请选择终点") {
      wx.showToast({
        title: '请选择终点位置',
        icon: 'none'
      })
      return
    }
    if (scall.scday == undefined || scall.scmonth == undefined || scall.schour == undefined) {
      wx.showToast({
        title: '请选择租车时间',
        icon: "none"
      })
      return
    }
    wx.navigateTo({
      url: '../choice/choice?typee=expert',
    })
  },
  scchoice() {
    wx.setStorageSync('spemetxt', this.data.spemetxt)
    wx.setStorageSync('speentxt', this.data.speentxt)
    var itemId = "schedule"
    wx.setStorageSync("itemId", itemId)
    wx.setStorageSync('rzctxt', this.data.rzctxt)
    wx.setStorageSync('rzcdiver', this.data.rzcdiver)
    if (this.data.start == "请选择起点") {
      wx.showToast({
        title: '请选择起点位置',
        icon: 'none'
      })
      return
    };
    if (this.data.end == "请选择终点") {
      wx.showToast({
        title: '请选择终点位置',
        icon: 'none'
      })
      return
    }
    if (scall.scday == undefined || scall.scmonth == undefined || scall.schour == undefined) {
      wx.showToast({
        title: '请选择出发时间',
        icon: "none"
      })
      return
    }
    if (scenall.scenday == undefined || scenall.scenmonth == undefined || scenall.scenhour == undefined) {
      wx.showToast({
        title: '请选择结束时间',
        icon: "none"
      })
      return
    }
    if (scall.scmonth > scenall.scenmonth || scall.scmonth < scenall.scenmonth) {
      wx.showToast({
        title: '请选择正确的还车时间',
        icon: 'none'
      })
      return
    }
    if (scall.scmonth = scenall.scenmonth && scall.scday > scenall.scenday) {
      wx.showToast({
        title: '请选择正确的还车时间',
        icon: 'none'
      })
      return
    }
    wx.navigateTo({
      url: '../choice/choice?typee=expert',
    })
  },
  sc_rule() {
    wx.navigateTo({
      url: '../rule/rule?txt=专车日租租车规则',
    })
  },
  ex_rule() {
    wx.navigateTo({
      url: '../rule/rule?txt=专车接站租车规则',
    })
  },
  bindSelect: function(e) {
    console.log(e) //选择结果值
  },
  onChangeAddress: function() {
    var _page = this;
    wx.chooseLocation({
      success: function(res) {
        _page.setData({
          chooseAddress: res.name
        });
        wx.setStorageSync('start', res.name)
      },
      fail: function(err) {
        console.log(err)
      }
    });
  },
  autChangeAddress: function() {
    var _page = this;
    wx.chooseLocation({
      success: function(res) {
        _page.setData({
          autAddress: res.name
        });
        wx.setStorageSync('end', res.name)
      },
      fail: function(err) {
        console.log(err)
      }
    });
  },

  enbindChange: function(e) {
    const val = e.detail.value;
    this.setData({
      endate: this.data.endateList[val[0]],
      enhour: this.data.enhours[val[1]],
    })
    scenall = {
      scenday: this.data.endateList[val[0]].day,
      scenmonth: this.data.endateList[val[0]].month,
      scenhour: this.data.enhours[val[1]],
    }
    var dates = this.data.dateList[val[0]]
    //时间比较
    var selected = dates.newdates + "\t" + this.data.hour //选择时间
    var myEventDetail = {
      selected: this.data.endateList[val[0]]
    }
    wx.setStorageSync('enselectdate', myEventDetail) //存储时间
    wx.setStorageSync("enhour", this.data.hour)
  },
  bindChange: function(e) {
    const val = e.detail.value;
    this.setData({
      date: this.data.dateList[val[0]],
      hour: this.data.hours[val[1]],
    })
    scall = {
      scday: this.data.dateList[val[0]].day,
      scmonth: this.data.dateList[val[0]].month,
      schour: this.data.hours[val[1]],
    }
    var dates = this.data.dateList[val[0]]
    //时间比较
    var selected = dates.newdates + "\t" + this.data.hour //选择时间
    var myEventDetail = {
      selected: this.data.dateList[val[0]]
    }
    wx.setStorageSync('selectdate', myEventDetail) //存储时间
    wx.setStorageSync("hour", this.data.hour)
  },
  /**
   * 获取d当前时间多少天后的日期和对应星期
   * //todate默认参数是当前日期，可以传入对应时间
   */
  getDates: function(days, todate = this.getCurrentMonthFirst()) {
    var dateArry = [];
    for (var i = 0; i < days; i++) {
      var dateObj = util.dateLater(todate, i);
      dateArry.push(dateObj)
    }
    return dateArry;
  },
  //获取当前时间
  getCurrentMonthFirst: function() {
    var date = new Date();
    var todate = date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : date.getMonth() + 1) + "-" + (date.getDate() < 10 ? ("0" + date.getDate()) : date.getDate());
    return todate;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  onReady: function() {
    let endateList = this.getDates(15);
    const endate = new Date()
    const enhours = ['6:00', "6:30", "7:00", "7:30", "8:00", "8:30", "9:00", "9:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30"]
    var todayhour = (todayMinutes > 30 ? (endate.getHours() + 1) : endate.getHours()); //当前时
    var todayMinutes = parseInt(endate.getMinutes());
    var newtodayMinutes = todayMinutes < 30 ? '30' : '00'; //当前分
    this.setData({
      endateList: endateList,
      enhours: enhours,
      todayminutes: newtodayMinutes,
      todayhour: todayhour,
    })
    var selected = endateList[0].year + "-" + endateList[0].newdates + "\t" + ((todayhour >= 10) ? todayhour : ("0" + todayhour)) + ":" + newtodayMinutes;
    var myEventDetail = {
      selected: selected,
    }
    let dateList = this.getDates(15);
    const date = new Date()
    const hours = ['6:00', "6:30", "7:00", "7:30", "8:00", "8:30", "9:00", "9:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30"]
    var todayhour = (todayMinutes > 30 ? (date.getHours() + 1) : date.getHours()); //当前时
    var todayMinutes = parseInt(date.getMinutes());
    var newtodayMinutes = todayMinutes < 30 ? '30' : '00'; //当前分
    this.setData({
      dateList: dateList,
      hours: hours,
      todayminutes: newtodayMinutes,
      todayhour: todayhour,
    })
    var selected = dateList[0].year + "-" + dateList[0].newdates + "\t" + ((todayhour >= 10) ? todayhour : ("0" + todayhour)) + ":" + newtodayMinutes;
    var myEventDetail = {
      selected: selected,
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var start = wx.getStorageSync("start");
    var end = wx.getStorageSync("end");
    if (start) {
      this.setData({
        start: start
      })
    } else {
      this.setData({
        start: '请选择起点'
      })
    }
    if (end) {
      this.setData({
        end: end
      })
    } else {
      this.setData({
        end: '请选择终点'
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})