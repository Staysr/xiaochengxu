// pages/home /home .js
const app = getApp()
const url = app.globalData.staticUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    homeImg: null,
    detaiHide: true,
    detaiFade: '',
    detailHide: true,
    detailFade: '',
    text: "请用户先进行实名认证，后台审核需要一段时间。",
    quick: [{
      img: "../../images/speed.png",
      txt: "高铁站",
      bind: 'speed'
    }, {
      img: "../../images/rent.png",
      txt: "到店租车",
      bind: 'rent'
    }, {
      img: "../../images/meet.png",
      txt: "专车",
      bind: 'expert'
    }],
    curIdx: 0,
    listInfo: [{
        title: '高铁站',
        imgUrl: '../../images/select.png',
        curUrl: '../../images/selected.png',
        bind: 'speed'
      },
      {
        title: '到店租车',
        imgUrl: '../../images/select.png',
        curUrl: '../../images/selected.png',
        bind: 'rent'
      }, {
        title: '专车',
        imgUrl: '../../images/select.png',
        curUrl: '../../images/selected.png',
        bind: 'expert'
      }
    ],
    uid: '',
    imgurl: app.globalData.imgurl,
    isGetPhone:true
  },

  hadeDetail(e) {
    var current = e.currentTarget.dataset.current;
    var list = this.data.listInfo
    var bind = list[current].bind
    var that = this
    if (bind == "expert") {
      wx.navigateTo({
        url: '../rentExpert/expert',
      })
    }
    if (bind == "speed") {
      wx.navigateTo({
        url: '../rentSpeed/speed',
      })
    }
    if (bind == "rent") {
      wx.navigateTo({
        url: '../rentRent/rent',
      })
    }
  },
  bindswiper(e) {},
  chooseImg: function(e) {
    this.setData({
      curIdx: e.currentTarget.dataset.current
    })
  },
  detailShow() {
    this.setData({
      detailHide: false
    })
  },
  fadeDetail() {
    this.setData({
      detailFade: 'transitionFade fade',
      detailHide: true
    })
  },
  hideDetail() {
    this.setData({
      detailFade: ''
    })
  },
  detaiShow() {
    var that = this
    that.setData({
      detaiHide: false,
      showView: (!that.data.showView)
    })
    wx.request({
      url: url + 'index/concession',
      data:{

      },
      success(res){

      }
    })
  },
  fadeDetai() {
    this.setData({
      detaiFade: 'transitionFade fade',
      detaiHide: true
    })
  },
  hideDetai() {
    this.setData({
      detaiFade: ''
    })
  },
  search() {
    wx.navigateTo({
      url: '../search/search',
    })
  },
  driver() {
    wx.navigateTo({
      url: '../driver/driver',
    })
  },
  car() {
    wx.navigateTo({
      url: "../realName/realName",
    })
  },
  changeCar() {
    wx.navigateTo({
      url: '../realName/realName',
    })
  },
  expert() {
    wx.removeStorageSync("car")
    wx.removeStorageSync('itemId')
    wx.removeStorageSync("start")
    wx.removeStorageSync('end')
    wx.removeStorageSync('not')
    wx.removeStorageSync('spemetxt')
    wx.removeStorageSync('speentxt')
    wx.removeStorageSync('selectdate')
    wx.removeStorageSync('hour')
    wx.removeStorageSync('enselectdate')
    wx.removeStorageSync('enhour')
    wx.navigateTo({
      url: '../expert/expert',
    })
  },
  speed() {
    wx.removeStorageSync("car")
    wx.removeStorageSync('itemId')
    wx.removeStorageSync("start")
    wx.removeStorageSync('end')
    wx.removeStorageSync('not')
    wx.removeStorageSync('spemetxt')
    wx.removeStorageSync('speentxt')
    wx.removeStorageSync('selectdate')
    wx.removeStorageSync('hour')
    wx.removeStorageSync('enselectdate')
    wx.removeStorageSync('enhour')
    wx.navigateTo({
      url: '../speed/speed',
    })
  },
  rent() {
    wx.removeStorageSync("car")
    wx.removeStorageSync('itemId')
    wx.removeStorageSync("start")
    wx.removeStorageSync('end')
    wx.removeStorageSync('not')
    wx.removeStorageSync('spemetxt')
    wx.removeStorageSync('speentxt')
    wx.removeStorageSync('selectdate')
    wx.removeStorageSync('hour')
    wx.removeStorageSync('enselectdate')
    wx.removeStorageSync('enhour')
    wx.navigateTo({
      url: '../rent/rent',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var that = this
    wx.removeStorageSync('itemId')
    showView: (options.showView == "true" ? true : false)
    
    wx.request({
      url: url + 'index/indexbanner',
      data: {
        uid: that.data.uid
      },
      success(res) {
        that.setData({
          swiperImgUrl: res.data.data.banner,
          car: res.data.data.is_recommend,
          coupon: res.data.data.discounts,
        })
      }
    })
  },
  //请求login 判断返回信息，有登陆的返回用户信息，没有登录的调用授权登录
  login: function() {
    var that = this
    wx.login({
      success(res) {
        wx.request({
          url: url + 'index/impower',
          data: {
            code: res.code
          },
          success(res) {
            console.log(res)
            var msg = res.data.msg
            if (msg == '用户未授权'){
              that.setData({
                  isGetPhone:false
                })
            } else {
              that.setData({
                isGetPhone: true
              })
              wx.setStorageSync("data", res.data.data)
            }
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.login()
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    setTimeout(function() {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})