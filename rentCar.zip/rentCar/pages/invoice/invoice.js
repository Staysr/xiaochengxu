Page({

  /**
   * 页面的初始数据
   */
  data: {
    isAllSelect: false,
    totalMoney: 0,
    idxId: 'personal',
    itemId: "invoice",
    rule: '开票规则',
    carts: [{
      isSelect: false,
      imgUrl: '../../images/invoice-normal.png',
      curUrl: '../../images/invoice-selected.png',
      txt: '129381310',
      money: 1200,
      carimg: "../../images/car.png",
      carname: "大众桑塔纳",
      cartxt: "三箱|1.6自动|乘坐5人"
    }, ]
  },
  elecinvo(e) {
    wx.navigateTo({
      url: '../invodeta/invodeta?type=elec',
    })
  },
  paperinvo(e) {
    wx.navigateTo({
      url: '../invodeta/invodeta?type=paper',
    })
  },
  drawbill(e) {
    wx.navigateTo({
      url: '../drawbill/drawbill',
    })
  },
  changeOrder(e) {
    this.setData({
      itemId: e.currentTarget.dataset.itemid
    })
  },
  changeMin(e) {
    this.setData({
      idxId: e.currentTarget.dataset.idxid
    })
  },
  rule(e) {
    var that = this
    wx.navigateTo({
      url: '../rule/rule?txt=开票规则',
    })
  },
  perbind(e) {
    this.setData({

    })
  },
  // 选择商品函数
  switchSelect: function(e) {
    const index = e.currentTarget.dataset.index; // 获取data- 传进来的index
    console.log(index)
    let carts = this.data.carts; // 获取列表
    let selectNum = 0; //统计选中
    const isSelect = carts[index].isSelect; // 获取当前的选中状态
    carts[index].isSelect = !isSelect; // 改变状态
    for (let i = 0; i < carts.length; i++) {
      if (carts[i].isSelect) {
        selectNum++
      }
    }
    if (selectNum == carts.length) {
      this.setData({
        isAllSelect: true
      })
    } else {
      this.setData({
        isAllSelect: false
      })
    }
    this.setData({
      carts: carts
    })
    this.getTotalPrice()
  },
  getTotalPrice() {
    let carts = this.data.carts; // 获取列表
    let total = 0;
    for (let i = 0; i < carts.length; i++) { // 循环列表得到每个数据
      if (carts[i].isSelect) { // 判断选中才会计算价格
        total += carts[i].money; // 所有价格加起来
      }
    }
    this.setData({ // 最后赋值到data中渲染到页面
      carts: carts,
      totalMoney: total.toFixed(2)
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getTotalPrice()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    setTimeout(function() {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})