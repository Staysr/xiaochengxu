//index.js
//获取应用实例
const app = getApp()
const url = app.globalData.staticUrl;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    detaiHide: true,
    detaiFade: '',
    name: '', //姓名
    phone: '', //手机号
    code: '', //验证码
    iscode: null, //用于存放验证码接口里获取到的code
    codename: '获取验证码'
  },
  detaiShow() {
    var that = this
    that.setData({
      detaiHide: false,
    })
  },
  fadeDetai() {
    this.setData({
      detaiFade: 'transitionFade fade',
      detaiHide: true,
    })
    wx.navigateBack({})
  },
  hideDetai() {
    this.setData({
      detaiFade: ''
    })
  },
  getPhoneValue: function(e) {
    console.log(e)
    this.setData({
      phone: e.detail.value
    })
  },
  // 提交表单
  formSubmit: function(e) {
    console.log(e)
    var that = this
    var uid = wx.getStorageSync("data")
    var myreg = /^1([38][0-9]|4[579]|5[0-3,5-9]|6[6]|7[0135678]|9[89])\d{8}$/;
    if (e.detail.value.phone == '') {
      wx.showToast({
        title: '手机号不能为空',
        icon: 'none',
        duration: 1000
      })
      return false;
    }
    if (!myreg.test(e.detail.value.phone)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none',
        duration: 1000
      })
      return false;
    }
    if (e.detail.value.smg == '') {
      wx.showToast({
        title: '验证码不能为空',
        icon: 'none',
        duration: 1000
      })
      return false;
    }
    var smg = wx.getStorageSync("smg")
    if (smg != e.detail.value.smg) {
      wx.showToast({
        title: '验证码错误',
        icon: 'none',
        duration: 1500
      })
      return false;
    }
    wx.request({
      url: url + 'user/alter_phone',
      data: {
        uid: uid.id,
        phone: e.detail.value.phone,
        smg: e.detail.value.smg
      },
      success(res) {
        console.log(res)
        if (res.data.code == 200) {
          that.detaiShow();
        }else{
          wx.showToast({
            title:res.data.msg,
            icon: 'none',
            duration: 1500
          })
        }
      }
    })
  },
  getCode: function(e) {
    console.log(e)
    var a = e.currentTarget.dataset.phone;
    var _this = this;
    var myreg = /^1([38][0-9]|4[579]|5[0-3,5-9]|6[6]|7[0135678]|9[89])\d{8}$/;
    if (a == "") {
      wx.showToast({
        title: '手机号不能为空',
        icon: 'none',
        duration: 1000
      })
      return false;
    } else if (!myreg.test(a)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none',
        duration: 1000
      })
      return false;
    } else {
      wx.request({
        data: {
          phone: a
        },
        'url': url + 'index/smg',
        success(res) {
          console.log(res.data.data)
          wx.setStorageSync("smg", res.data.data.mobile_code)
          _this.setData({
            iscode: res.data.data
          })
          var num = 61;
          var timer = setInterval(function() {
            num--;
            if (num <= 0) {
              clearInterval(timer);
              _this.setData({
                codename: '重新发送',
                disabled: false
              })

            } else {
              _this.setData({
                codename: num + "s"
              })
            }
          }, 1000)
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})