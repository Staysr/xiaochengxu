// pages/my/my.js
const app = getApp()
const url = app.globalData.staticUrl;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    detaiHide: true,
    detaiFade: '',
    back: '../../images/bg-personal.png',
    img: "../../images/head.png",
    txt: "速派租车"
  },
  detaiShow() {
    var that = this
    that.setData({
      detaiHide: false,
    })
  },
  fadeDetai() {
    this.setData({
      detaiFade: 'transitionFade fade',
      detaiHide: true,
    }) 
    wx.navigateTo({
      url: '../driver/driver',
    })
  },
  hideDetai() {
    this.setData({
      detaiFade: ''
    })
  },
  perdata(e) {
    wx.setStorageSync('img', this.data.img)
    wx.setStorageSync('txt', this.data.txt)
    wx.navigateTo({
      url: '../perdata/perdata'
    })
  },
  setup(e) {
    wx.navigateTo({
      url: '../setup/setup',
    })
  },
  opinion(e) {
    wx.navigateTo({
      url: '../opinion/opinion',
    })
  },
  rentName(e) {
    wx.navigateTo({
      url: '../reatName/reatName',
    })
  },
  invoice(e) {
    wx.navigateTo({
      url: '../invoice/invoice',
    })
  },
  violat(e) {
    wx.navigateTo({
      url: '../violation/violation',
    })
  },
  address(e) {
    wx.navigateTo({
      url: '../address/address?type=my',
    })
  },
  coupon(e) {
    wx.navigateTo({
      url: '../coupon/coupon',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var data = wx.getStorageSync("data")
    console.log(data)
    this.setData({
      nickname:data.nickname,
      nickimg:data.head
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})