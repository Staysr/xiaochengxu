// pages/opinion/0pinion.js
const app = getApp()
const url = app.globalData.staticUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  opinon(e) {
    wx.switchTab({
      url: '../my/my',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  formSubmit: function(e) {
    var that = this
    var uid = wx.getStorageSync("data")
    if (e.detail.value.opinion == '') {
      wx.showToast({
        icon: 'none',
        title: '意见内容不能为空',
      })
      return false
    }
    wx.request({
      url: url + 'user/opinion',
      data: {
        uid: uid.id,
        opinion: e.detail.value.opinion
      },
      success(res) {
        console.log(res)
        if (res.data.code == 200) {
          wx.showToast({
            icon: 'none',
            title: '反馈成功',
          })
        }
        setTimeout(function() {
          wx.switchTab({
            url: '../my/my',
          })
        }, 2000)
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})