// pages/order/order.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detHide: true,
    detFade: '',
    detailHide: true,
    detailFade: '',
    detaHide: true,
    detaFade: '',
    detaiHide: true,
    detaiFade: '',
    start: "全部订单",
    slist: [{
      id: 1,
      name: "全部订单"
    }, {
      id: 1,
      name: "待付款"
    }, {
      id: 1,
      name: "待验车"
    }, {
      id: 1,
      name: "待上车"
    }, {
      id: 1,
      name: "进行中"
    }, {
      id: 1,
      name: "待确认还车"
    }, {
      id: 1,
      name: "已完成"
    }, {
      id: 1,
      name: "已取消"
    }, ],
    isstart: false,
    itemId: "schedule",
    cancel: "取消订单",
    exam: "续租",
    examination: '待验车',
    state: '待验车',
    returnt: '待还车',
  },
  take(e) {
    this.setData({
      detHide: false
    })
  },
  fadeDet() {
    this.setData({
      detFade: 'transitionFade fade',
      detHide: true
    })
  },
  readDet(e) {
    this.setData({
      detFade: 'transitionFade fade',
      detHide: true,
    })
  },
  returnt() {
    wx.navigateTo({
      url: '../returnt/returnt',
    })
  },
  examin() {
    wx.navigateTo({
      url: '../examin/examin',
    })
  },
  jump() {
    wx.navigateTo({
      url: '../renewal/renewal',
    })
  },
  detailShow(e) {
    var index = e.currentTarget.dataset.index;
    var item = this.data.car
    console.log(item)
    this.setData({
      detailHide: false
    })
  },
  fadeDetail() {
    this.setData({
      detailFade: 'transitionFade fade',
      detailHide: true
    })
  },
  fadeDetai() {
    this.setData({
      detaiFade: 'transitionFade fade',
      detaiHide: true
    })
  },
  readDetai(e) {
    this.setData({
      detaiFade: 'transitionFade fade',
      detaiHide: true,
      detaHide: false
    })
  },
  readDetail(e) {
    this.setData({
      detailFade: 'transitionFade fade',
      detailHide: true,
      detaiHide: false
    })
  },
  readDeta(e) {
    this.setData({
      detaFade: 'transitionFade fade',
      detaHide: true,
      showView: (!this.data.showView)
    })
  },
  hideDetail() {
    this.setData({
      detailHide: true,
      detaiFade: ''
    })
  },
  details(e) {
    var index = e.currentTarget.dataset.index;
    wx.navigateTo({
      url: '../details/details',
    })
  },
  opens: function(e) {
    switch (e.currentTarget.dataset.item) {
      case "1":
        if (this.data.isstart) {
          this.setData({
            isstart: false,
          });
        } else {
          this.setData({
            isstart: true,
          });
        }
        break;
    }
  },
  onclicks1: function(e) {
    var index = e.currentTarget.dataset.index;
    let name = this.data.slist[index].name;
    this.setData({
      index: index,
      isstart: false,
      isfinish: false,
      isdates: false,
      start: this.data.slist[index].name,
    })
  },
  changeOrder(e) {
    this.setData({
      itemId: e.currentTarget.dataset.itemid
    })
    wx.setStorageSync('itemId', e.currentTarget.dataset.itemid)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    showView: (options.showView == "true" ? true : false)
    var itemd = wx.getStorageSync('itemId')
    this.setData({
      itemd: itemd,
    })
    if (itemd == 'speed' || itemd == 'expert' || itemd == 'wind') {
      var car = wx.getStorageSync("car")
      var date = wx.getStorageSync('selectdate').selected
      var hour = wx.getStorageSync('hour')
      var time = date.dates + '\t' + date.week;
      this.setData({
        img: car.carimg,
        car: car.carname,
        cartxt: car.cartxt,
        hour: hour,
        day: date.dates,
        week: date.week,
        time: time,
      })
    } else if (itemd == 'rent' || itemd == 'schedule') {
      var car = wx.getStorageSync("car")
      var date = wx.getStorageSync('selectdate').selected
      var endate = wx.getStorageSync('enselectdate').selected
      var hour = wx.getStorageSync('hour')
      var enhour = wx.getStorageSync('enhour')
      var sctime = date.dates
      var scentime = endate.dates
      var schour = date.week + "\t" + hour
      var scenhour = endate.week + '\t' + enhour
      var time = date.dates + '\t' + date.week;
      this.setData({
        img: car.carimg,
        car: car.carname,
        cartxt: car.cartxt,
        hour: hour,
        enhour: enhour,
        day: date.dates,
        week: date.week,
        enday: endate.dates,
        enweek: endate.week,
        sctime: sctime,
        scentime: scentime,
        schour: schour,
        scenhour: scenhour,
        time: time,
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showNavigationBarLoading() //在标题栏中显示加载
    setTimeout(function () {
      // complete
      wx.hideNavigationBarLoading() //完成停止加载
      wx.stopPullDownRefresh() //停止下拉刷新
    }, 1500);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})