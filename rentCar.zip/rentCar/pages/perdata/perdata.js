// pages/data/data.js
const app = getApp()
const url = app.globalData.staticUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    region: ['请选择省', '请选择市', '请选择区'],
    tle: 18042232321
  },
  email(e) {
    var uid = wx.getStorageSync("data")
    wx.request({
      url: url + 'user/messagechange',
      data: {
        uid: uid.id,
        email: e.detail.value
      },
      success(res) {
        console.log(res)
      }
    })
  },
  name(e) {
    var uid = wx.getStorageSync("data")
    wx.request({
      url: url + 'user/messagechange',
      data: {
        uid: uid.id,
        contact_name: e.detail.value
      },
      success(res) {
        console.log(res)
      }
    })
  },
  tle(e) {
    var uid = wx.getStorageSync("data")
    wx.request({
      url: url + 'user/messagechange',
      data: {
        uid: uid.id,
        contact_phone: e.detail.value
      },
      success(res) {
        console.log(res)
      }
    })
  },
  add(e) {
    var uid = wx.getStorageSync("data")
    wx.request({
      url: url + 'user/messagechange',
      data: {
        uid: uid.id,
        address: e.detail.value
      },
      success(res) {
        console.log(res)
      }
    })
  },

  bindRegionChange: function(e) {
    var that = this
    that.setData({
      region: e.detail.value
    })
    var uid = wx.getStorageSync("data")
    wx.request({
      url: url + 'user/messagechange',
      data: {
        uid: uid.id,
        province: e.detail.value[0],
        city: e.detail.value[1],
        area: e.detail.value[2]
      },
      success(res) {
        that.setData({
          province: e.detail.value[0],
          city: e.detail.value[1],
          area: e.detail.value[2]
        })
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var uid = wx.getStorageSync("data")
    var that = this
    wx.request({
      url: url + 'user/message',
      data: {
        uid: uid.id
      },
      success(res) {
        console.log(res)
        if (res.data.data.province == '') {
          that.setData({
            data: res.data.data,
            province: '请选择省',
            city: '请选择市',
            area: '请选择区'
          })
          return false;
        }
        that.setData({
          data: res.data.data,
          province: res.data.data.province,
          city: res.data.data.city,
          area: res.data.data.area
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})