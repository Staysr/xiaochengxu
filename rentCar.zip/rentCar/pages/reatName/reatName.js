// pages/realName/realName.js
const app = getApp()
const url = app.globalData.staticUrl;
const util = require("../../utils/util.js")
Page({
  /**
   * 页面的初始数据
   */
  data: {
    userName: '',
    mobile: '',
    tempFilePaths: '',
  },
  userNameInput: function(e) {
    this.setData({
      userName: e.detail.value
    })
  },

  mobileInput: function(e) {
    this.setData({
      mobile: e.detail.value
    })
  },
  img_item: function(e) {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        that.setData({
          ['tempFilePaths[' + e.target.id + ']']: res.tempFilePaths[0]
        })
      }
    })
  },
  btnclick: function() {
    var userName = this.data.userName;
    var mobile = this.data.mobile;
    var phonetel = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
    var name = /^[u4E00-u9FA5]+$/;
    if (userName == '') {
      wx.showToast({
        title: '请输入用户名',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false
    } else if (mobile == '') {
      wx.showToast({
        icon: 'none',
        title: '身份证号不能为空',
      })
      return false
    } else if (mobile.length != 18) {
      wx.showToast({
        title: '身份证号不合法！',
        icon: 'none',
        duration: 1500
      })
      return false;
    }
    var myreg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
    if (!myreg.test(mobile)) {
      wx.showToast({
        title: '身份证号不合法！',
        icon: 'none',
        duration: 1500
      })
      return false;
    }
    var id = wx.getStorageSync("data").id
    wx.request({
      url: url + 'index/autonym',
      data: {
        uid: id,
        real_name: userName,
        sfz_num: mobile,
        sfz_front: tempFilePaths[1],
        sfz_back: tempFilePaths[2],
        jz_main: tempFilePaths[3],
        jz_vice: tempFilePaths[4]
      },
      success(res) {
        console.log(res)
      }
    })
    wx.navigateBack({})
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})