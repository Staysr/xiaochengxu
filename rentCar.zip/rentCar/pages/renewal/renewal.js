// pages/renewal/renewal.js
var util = require('../../utils/util.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    dateList: [],
    hours: [],
    date: {},
    todayhour: "",
  },
  jump(e) {
    wx.reLaunch({
      url: '../rentsuc/rentsuc',
    })
  },
  showDate: function() {
    var showselect = true
    this.setData({
      showselect: showselect
    })
  },
  cancel: function() {
    var showselect = false
    this.setData({
      showselect: showselect
    })
  },
  determine: function() {
    var showselect = false
    this.setData({
      showselect: showselect
    })
  },
  //选择值
  bindChange: function(e) {
    const val = e.detail.value;
    this.setData({
      date: this.data.dateList[val[0]],
      hour: this.data.hours[val[1]],
    })
    var dates = this.data.dateList[val[0]]
    //时间比较
    var selected = dates.newdates + "\t" + this.data.hour //选择时间
    var myEventDetail = {
      selected: this.data.dateList[val[0]]
    }
    wx.setStorageSync('selectdate', myEventDetail) //存储时间
    wx.setStorageSync("hour", this.data.hour)
  },
  /**
   * 获取d当前时间多少天后的日期和对应星期
   * //todate默认参数是当前日期，可以传入对应时间
   */
  getDates: function(days, todate = this.getCurrentMonthFirst()) {
    var dateArry = [];
    for (var i = 0; i < days; i++) {
      var dateObj = util.dateLater(todate, i);
      dateArry.push(dateObj)
    }
    return dateArry;
  },
  //获取当前时间
  getCurrentMonthFirst: function() {
    var date = new Date();
    var todate = date.getFullYear() + "-" + ((date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : date.getMonth() + 1) + "-" + (date.getDate() < 10 ? ("0" + date.getDate()) : date.getDate());
    return todate;
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var date = wx.getStorageSync('selectdate').selected
    var time = date.dates + '\t' + date.week;
    var endate = wx.getStorageSync('enselectdate').selected
    var hour = wx.getStorageSync('hour')
    var enhour = wx.getStorageSync('enhour')
    this.setData({
      hour: hour,
      time: time,
      enhour: enhour,
      day: date.dates,
      week: date.week,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    let dateList = this.getDates(15);
    const date = new Date()
    const hours = ['6:00', "6:30", "7:00", "7:30", "8:00", "8:30", "9:00", "9:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "13:00", "13:30", "14:00", "14:30", "15:00", "15:30", "16:00", "16:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30", "20:00", "20:30", "21:00", "21:30", "22:00", "22:30"]
    var todayhour = (todayMinutes > 30 ? (date.getHours() + 1) : date.getHours()); //当前时
    var todayMinutes = parseInt(date.getMinutes());
    var newtodayMinutes = todayMinutes < 30 ? '30' : '00'; //当前分
    this.setData({
      dateList: dateList,
      hours: hours,
      todayminutes: newtodayMinutes,
      todayhour: todayhour,
    })
    var selected = dateList[0].year + "-" + dateList[0].newdates + "\t" + ((todayhour >= 10) ? todayhour : ("0" + todayhour)) + ":" + newtodayMinutes;
    var myEventDetail = {
      selected: selected,
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})