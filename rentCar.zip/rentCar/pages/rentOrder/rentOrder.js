// pages/rentOrder/rentOrder.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    agreement: '租车速派协议',
    car: [{
      carimg: "../../images/car.png",
      carname: "大众",
      cartxt: "三箱|1.6自动|乘坐5人",
      bzjin:'保证金',
      zcar:'租车费用'
    }],
  },
  onChangeAddress: function() {
    var _page = this;
    wx.chooseLocation({
      success: function(res) {
        _page.setData({
          chooseAddress: res.name
        });
      },
      fail: function(err) {
        console.log(err)
      }
    });
  },
  agree() {
    var that = this
    wx.navigateTo({
      url: '../rule/rule?txt=' + that.data.agreement,
    })
  },
  discount() {
    wx.navigateTo({
      url: '../discount/discount',
    })
  },
  contract() {
    wx.setStorageSync('bzjin', this.data.car)
    wx.setStorageSync('zcar', this.data.car)
    wx.navigateTo({
      url: '../contract/contract',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var itemId = wx.getStorageSync('itemId')
    var on = wx.getStorageSync("on")
    var en = wx.getStorageSync('en')
    var date = wx.getStorageSync('selectdate').selected
    var endate = wx.getStorageSync('enselectdate').selected
    var hour = wx.getStorageSync('hour')
    var enhour = wx.getStorageSync('enhour')
    var not = wx.getStorageSync('not')
    var spemetxt = wx.getStorageSync('spemetxt')
    var speentxt = wx.getStorageSync('speentxt')
    var time = date.dates
    var entime = endate.dates
    var hour = date.week + "\t" + hour
    var enhour = endate.week + '\t' + enhour
    this.setData({
      spemetxt: spemetxt,
      speentxt: speentxt,
      time: time,
      entime: entime,
      hour: hour,
      enhour:enhour,
      on: on,
      en: en
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var discount = wx.getStorageSync("not");
    if (discount) {
      this.setData({
        not: discount
      })
    } else {
      this.setData({
        not: '请选择优惠'
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})