// pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    detailHide: true,
    detailFade: '',
    detaiHide: true,
    detaiFade: '',
    heat: [{
      txt: "大众",
      bind: "oneCar"
    }, {
      txt: "劳斯莱斯",
      bind: "twoCar"
    }],
    car: [{
      carimg: "../../images/car.png",
      carname: "大众",
      cartxt: "三箱|1.6自动|乘坐5人",
      carmoney: "￥69/日均"
    }, {
      carimg: "../../images/car.png",
      carname: "大众",
      cartxt: "三箱|1.6自动|乘坐5人",
      carmoney: "￥69/日均"
    }, {
      carimg: "../../images/car.png",
      carname: "大众",
      cartxt: "三箱|1.6自动|乘坐5人",
      carmoney: "￥69/日均"
    }],
    curIdx: 0,
    listInfo: [{
        title: '高铁站',
        imgUrl: '../../images/select.png',
        curUrl: '../../images/selected.png',
        bind: 'speed'
      },
      {
        title: '到店租车',
        imgUrl: '../../images/select.png',
        curUrl: '../../images/selected.png',
        bind: 'rent'
      }, {
        title: '专车',
        imgUrl: '../../images/select.png',
        curUrl: '../../images/selected.png',
        bind: 'expert'
      }
    ],
  },
  detaiShow() {
    this.setData({
      detaiHide: false
    })
  },
  hideDetai() {
    this.setData({
      detaiHide: true,
      detaiFade: ''
    })
  },
  detailShow(e) {
    var index = e.currentTarget.dataset.index;
    var item = this.data.car[index];
    wx.setStorageSync('car', item)
    this.setData({
      detailHide: false
    })
  },
  fadeDetail() {
    this.setData({
      detailFade: 'transitionFade fade',
      detailHide: true
    })
  },
  hideDetail() {
    this.setData({
      detailFade: ''
    })
  },
  hadeDetail(e) {
    var current = e.currentTarget.dataset.current;
    var list = this.data.listInfo
    var bind = list[current].bind
    var that = this
    if (bind == "expert") {
      wx.navigateTo({
        url: '../rentExpert/expert?type=searexp',
      })
    }
    if (bind == "speed") {
      wx.navigateTo({
        url: '../rentSpeed/speed?type=searspe',
      })
    }
    if (bind == "rent") {
      wx.navigateTo({
        url: '../rentRent/rent?type=searren',
      })
    }
  },
  chooseImg: function(e) {
    // var index = e.currentTarget.dataset.current
    // wx.setStorageSync('typeId', this.data.listInfo[index].title)
    // console.log(this.data.listInfo[index].title)
    this.setData({
      curIdx: e.currentTarget.dataset.current
    })
  },
  selectRouter(e) {
    console.log(e.currentTarget.dataset)
    this.setData({
      itemId: e.currentTarget.dataset.itemid
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})