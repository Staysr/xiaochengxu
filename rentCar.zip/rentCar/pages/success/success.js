// pages/success/success.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    uper: [{
      place: '石家庄市桥西区新石南路与中华大街交叉口速派租车',
      time: '5月17日 周五 17:00',
      people: '速派租车',
      tle : '18712812345',
      number: '15494631644548',
      money: "￥1530"
    }]
  },

  dingd:function(e){
    wx.switchTab({
      url: '../order/order',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var item = wx.getStorageSync("itemId")
    this.setData({
      itemd:item
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})