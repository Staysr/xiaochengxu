// pages/violation/Violation.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    itemId:'speed',
    rule:'违章处理规则',
    start: "全部",
    slist: [{
      id: 1,
      name: "全部"
    }, {
      id: 2,
      name: "待处理"
    }, {
      id: 3,
      name: "审核中"
    }, {
      id: 4,
      name: "审核通过"
    }, {
      id: 5,
      name: "审核失败"
    }, {
      id: 6,
      name: "客服处理"
    }],
  },
  rule(e){
    wx.navigateTo({
      url: '../rule/rule?type=违章处理规则',
    })
  },
  upload(e){
    wx.navigateTo({
      url: '../upload/upload',
    })
  },
  opens: function(e) {
    switch (e.currentTarget.dataset.item) {
      case "1":
        if (this.data.isstart) {
          this.setData({
            isstart: false,
          });
        } else {
          this.setData({
            isstart: true,
          });
        }
        break;
    }
  },
  onclicks1: function (e) {
    var index = e.currentTarget.dataset.index;
    console.log(index)
    let name = this.data.slist[index].name;
    this.setData({
      index: index,
      isstart: false,
      isfinish: false,
      isdates: false,
      start: this.data.slist[index].name,
    })
  },
  changebtn(e) {
    this.setData({
      itemId: e.currentTarget.dataset.itemid
    })
    // wx.setStorageSync('itemId', e.currentTarget.dataset.itemid)
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})