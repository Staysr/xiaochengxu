const QQMapWx = require("../common/js/qqmap-wx-jssdk.min.js");

function getUserCity() {
  var qqmapsdk = new QQMapWX({
    key: 'LCVBZ-M6EKX-XHN4D-T7XLY-SYSYT-ZWFLY'
  });
  return new Promise((resolve) => {
    wx.getLocation({
      type: 'gcj02',
      success: function(res) {
        let longitude = res.longitude;
        let latitude = res.latitude;
        qqmapsdk.reverseGeocoder({
          longitude: {
            longitude: longitude,
            latitude: latitude
          },
          success(res) {
            let address = res.result;
            resolve(address)
          },
          fail(error) {
            console.log(error)
          }
        })
      }
    })
  })
}
const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()
  return [year, month, day].map(formatNumber).join('-') + '' + [hour, minute, second.map(formatNumber).join(':')]
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

//判断两个时间比较大小
function compareDate(d1, d2) {
  return ((new Date(d1.replace(/-/g, "\/"))) > (new Date(d2.replace(/-/g, "\/"))));
}

//当前时间获取
function getCurrentToday() {
  const date = new Date()
  var mouths = (date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : (date.getMonth() + 1);
  var day = date.getDate() < 10 ? ("0" + date.getDate()) : date.getDate();
  var currentdate = mouths + "-" + day + "\t";
  return currentdate
}

/**
 * 传入时间后几天
 * param：传入时间：dates:"2018-04-02",later:往后多少天
 */
function dateLater(dates, later) {
  let dateObj = {};
  let show_day = new Array('星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六');
  let date = new Date(dates);
  date.setDate(date.getDate() + later);
  let day = date.getDay();
  dateObj.dates = ((date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : date.getMonth() + 1) + "月" + (date.getDate() < 10 ? ("0" + date.getDate()) : date.getDate()) + "日";
  dateObj.newdates = ((date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : date.getMonth() + 1) + "-" + (date.getDate() < 10 ? ("0" + date.getDate()) : date.getDate());
  dateObj.year = date.getFullYear();
  dateObj.month = ((date.getMonth() + 1) < 10 ? ("0" + (date.getMonth() + 1)) : date.getMonth() + 1);
  dateObj.day = (date.getDate() < 10 ? ("0" + date.getDate()) : date.getDate());
  dateObj.week = show_day[day];
  return dateObj;
}


function count() {}

module.exports = {
  formatTime: formatTime,
  compareDate: compareDate,
  getCurrentToday: getCurrentToday,
  dateLater: dateLater,
  count: count
}