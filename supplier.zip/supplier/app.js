//app.js
App({
  onLaunch: function () {
    // 登录
    wx.removeStorageSync("linksuccess"); //一移除当前状态
    wx.removeStorageSync("wx_isinkblueya"); //移除蓝牙的名字
    wx.removeStorageSync("last_connected_device"); //移除最后一次链接的设备
    wx.removeStorageSync("_deviceId"); //移除设备
    wx.removeStorageSync("_serviceId"); //移除服务id
    wx.removeStorageSync("_characteristicId "); //移除charaid
    wx.login({
      success: function (res) {
        var code = res.code;
        wx.setStorageSync('code', code)
      }
    })
    //1代表未登入状态,2代表登入状态
    //wx.setStorageSync('wx_key_code', 1)
  }, 
  globalData: {
    userInfo: null,
    staticUrlxin: "https://jiwei.cnqianze.com/api.php/Json/", 
    regMoneyTwo: /^([1-9]\d{0,9}|0)([.]?|(\.\d{1,2})?)$/,
    api: 'https://jiwei.cnqianze.com/index.php/Json/',
    statiregist: "https://jiwei.cnqianze.com/api.php/register/",//注册调用的接口
  }
})