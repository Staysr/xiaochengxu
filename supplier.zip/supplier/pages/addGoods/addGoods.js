// pages/addGoods/addGoods.js
var app = getApp();
var api = app.globalData.api;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      let that = this;
      wx.showLoading({
        title: '加载中...',
        mask:true
      })
      wx.request({
        url: api +'saddGoods',
        data:{
          sid:wx.getStorageSync('sid')
        },
        success(res){
          wx.hideLoading();
          let list = res.data.goods
          that.setData({
            list
          })
          console.log(list)
        }
      })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  // 选中商品
  select(e){
    let that = this
    let index = e.currentTarget.dataset.index
    let list = that.data.list
    list[index].selected = !list[index].selected
    that.setData({
      list
    })
    console.log(list)
  },
  // 立即添加
  add(e){
    let that = this
    let list = that.data.list
    let newgoods = []
    for(let i = 0; i<list.length;i++){
      if(list[i].selected){
        newgoods.push({goodsid:list[i].goodsid,name:list[i].name})
      }
    } 
    console.log(newgoods)
    wx.setStorageSync('newgoods', newgoods)
    wx.navigateBack({
      
    })   
  }
})