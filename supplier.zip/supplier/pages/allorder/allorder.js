// pages/allorder/allorder.js
var app = getApp();
var api = app.globalData.api;
var utils = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    showOrHidden: true,
    // json:[{
    //   name:"土豆",
    //   price:"5.8",
    //   num:"126斤",
    // }, {
    //   name: "黄瓜",
    //   price: "8.9",
    //   num: "92斤",
    //   }, {
    //     name: "韭菜",
    //     price: "6.2",
    //     num: "81斤",
    // }, {
    //   name: "菠菜",
    //   price: "6.8",
    //   num: "55斤",
    //   }, {
    //     name: "西红柿",
    //     price: "8.2",
    //     num: "106斤",
    // }, {
    //   name: "辣椒",
    //   price: "9.8",
    //   num: "156斤",
    // },]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    let nowTime = utils.formatData(new Date());
    console.log(options)
    wx.showLoading({
      title: '加载中...',
      mask:true
    })
    if (options.type==2){
      wx.request({
        url: api + 'orderAll',
        data: {
          sid: wx.getStorageSync('sid')
        },
        success(res) {
          wx.hideLoading()
          console.log(res)
          that.setData({
            json: res.data.orderinfo,
            nowTime,
            showOrHidden: true

          })
        }
      })  
      wx.setNavigationBarTitle({
        title: '今日总订货单'
      })
    }else{
      wx.request({
        url: api + 'rorderInfo',
        data: {
          orderid: options.id
        },
        success(res) {
          wx.hideLoading()
          console.log(res)
          that.setData({
            json: res.data.orderinfo,
            showOrHidden: false
          })
          wx.setNavigationBarTitle({
            title: res.data.rname
          })
        }
      })
     
    }
    // console.log(options.type)

  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  /**
   * 盘点库存
   */
  gotopandian:function(){


    if (!utils.isJurisdiction("1-2")) {
      return false;
    }



    wx.navigateTo({
      url: '../pandian/pandian',
    })
  }
})