// pages/applyUpload/applyUpload.js
var app = getApp();
var api = app.globalData.api;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    requirementText: [
      '1.图片尺寸要求750*382px，大小不得超过2M',
      '2.不得上传有关黄赌毒等暴力图片', 
      '3.上传图片中不得包含有官方，集资等违法言论'],
    array: ['请选择周/月', '周', '月'],
    index: 0,
    indexOfTime:0,
    chooseWM:'请选择',
    chooseT: '请选择',
    money:0,
    num:0    
    // timeArr: ['请选择时间', timeArr],
      
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
    let that = this
    let timeArr = ["请选择时间"]
    for( let i =1; i<25;i++){
      timeArr.push(i)
    }
    that.setData({
      timeArr
    })
    wx.request({
      url: api+'system',
      success(res){
        that.setData({
          week: res.data.system.week,
          month: res.data.system.month,
        })
      }
    })
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  bindPickerChange(e) {
    let that = this
    if(e.detail.value==0){
      that.setData({
        index: e.detail.value,
        chooseWM: '请选择',
        typee: e.detail.value-1
      })
    }else{
      that.setData({
        index: e.detail.value,
        chooseWM:'已选择',
        typee: e.detail.value-1
      })
    }
      if (that.data.typee==0){
        that.setData({
          money: that.data.week * that.data.num
        })
      } else if (that.data.typee == 1){
        that.setData({
          money: that.data.month * that.data.num
        })
      }
    
  },

  bindPickerChangeTime(e) {
    let that = this    
    if (e.detail.value == 0) {
      this.setData({
        indexOfTime: e.detail.value,
        chooseT: '请选择' ,
        num: e.detail.value               
      })
    } else {
      this.setData({
        indexOfTime: e.detail.value,
        chooseT: '已选择',
        num: e.detail.value
      })
    }
      if (that.data.typee == 0){
        that.setData({
          money: that.data.week * that.data.num
        })
      } else if (that.data.typee == 1) {
        that.setData({
          money: that.data.month * that.data.num
        })
      }
    
  },
  chooseImg(){
    let that = this    
    wx.chooseImage({
      count:1,
      success(res) {
        const tempFilePaths = res.tempFilePaths
        that.setData({
          tempFilePaths: res.tempFilePaths,
          imgUrl: res.tempFilePaths
        })
      }
    })
    
  },
  tijiao:function(){
    
    let that = this
    wx.showLoading({
      title: '提交中...',
      mask: true
    })
    if ( !that.data.tempFilePaths){
      wx.hideLoading()
      wx.showModal({
        title: '提示！',
        content: '请完善相关信息！',
        showCancel:false,
      })
      
    } else if (that.data.money == 0){
      wx.hideLoading()
      wx.showModal({
        title: '提示！',
        content: '请完善相关信息！',
        showCancel: false,
      })
    }

    else{
      console.log(wx.getStorageSync('userid'), that.data.typee, that.data.num, that.data.money)
      wx.uploadFile({
        url: api+'apply', 
        filePath: that.data.tempFilePaths[0],
        header:{
          'content-type': 'multipart/form-data'
        },
        name: 'pic',
        formData: {
          userid: wx.getStorageSync('userid'),
          typee: that.data.typee,
          num: that.data.num,
          price:that.data.money
        },
        success(res) {
         
          var passde = JSON.parse(res.data)
          //console.log(passde.pay.timeStamp)
          const data = res.data
          wx.requestPayment({
            timeStamp: passde.pay.timeStamp,
            nonceStr: passde.pay.nonceStr,
            package: passde.pay.package,
            signType: 'MD5',
            paySign: passde.pay.paySign,
            'success':function(res){
              wx.showModal({
                title: '提示',
                content: '支付成功',
                showCancel: false,
                confirmText:"返回首页",
                success(res) {
                  if (res.confirm) {
                    wx.navigateBack({
                      delta: 1
                    })
                  }
                }
              })
            },complete:function(){
              wx.hideLoading();
            }
          })
        }
      })
    }
   
    
  }
})