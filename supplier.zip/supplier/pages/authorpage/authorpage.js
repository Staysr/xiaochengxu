// pages/authorpage/authorpage.js
var app = getApp()
var api = app.globalData.api
Page({

  /**
   * 页面的初始数据
   */
  data: {
     isauthor:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '数据加载中...',
    })
    let that = this
    wx.login({
      success: function (res) {
        var code = res.code;
        console.log(code)
        // return false;
        wx.request({
          url: api + 'swxLogin',
          data: {
            code: res.code
          },
          success(res) {
            console.log(res)
            wx.hideLoading();
            if (res.data.code == 2) {
              wx.clearStorageSync();//清楚所有缓存
              wx.setStorageSync('wx_key_code', 1);//1代表未登录状态
            }
            else {
              wx.setStorageSync('wx_key_code', 2);//2代表登录状态
              wx.setStorageSync('sid', res.data.user.sid);//sid
              wx.setStorageSync('userid', res.data.user.id);//uid
            }
            wx.redirectTo({
              url: '../index/index',
            })


          }
        })
      }
    })
   



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // setInterval(function () {
    //   let that = this
    //   wx.request({
    //     url: api + 'suserinfo',
    //     data: {
    //       uid: wx.getStorageSync('userid')
    //     },
    //     success(res) {
    //       if (res.data.code == 0) {
    //         wx.redirectTo({
    //           url: '../signIn/signIn',
    //         })
    //       }
    //     }
    //   })
    // }, 6000)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  , bindgetuserinfo:function(e){
  
  }
})