// pages/cgorder/cgorder.js
var app = getApp()
var api = app.globalData.api;
var regMoneyTwo = app.globalData.regMoneyTwo;
var utils = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    total: 0,
    json: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this
    wx.request({
      url: api + 'getSpurchase',
      data: {
        sid: wx.getStorageSync('sid')
      },
      success(res) {
        console.log(res)
        let json = res.data.purchase
        for (let i = 0; i < json.length; i++) {
          json[i].shicount = 0,
            json[i].price = 0
        }
        that.setData({
          json,
          mid: res.data.mid
        })
        that.getTotal();
      }
    })


  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  /**
   * 输入监听事件
   */
  bindKeyInput(e) {
    // var index = e.currentTarget.dataset.index;
    // //拼接数组中对应的参数
    // var info = "json[" + index + "].price";
    // //根据输入的值 更新数组中的数据
    // this.setData({
    //   [info]: e.detail.value,
    // })
    // this.getTotal();
    // // console.log(this.data.json);
    // // console.log(e.currentTarget.dataset.index)
    // // console.log(e.detail.value)
    let that = this
    let index = e.currentTarget.dataset.index
    let money = e.detail.value
    let json = that.data.json
    if (money == ".") {
      wx.showToast({
        title: '格式错误[整数]',
        duration: 2000,
        icon: "none"
      })
      return;
    }
    if (money == "/") {
      wx.showToast({
        title: '格式错误[整数]',
        duration: 2000,
        icon: "none"
      })
      return;
    }
    if (money == "%") {
      wx.showToast({
        title: '格式错误[整数]',
        duration: 2000,
        icon: "none"
      })
      return;
    }
    json[index].price = money
    that.setData({
      json
    })
    that.getTotal();

  },
  bindCgInput(e) {
    let that = this
    let index = e.currentTarget.dataset.index
    let cgnum = e.detail.value
    let json = that.data.json
    if (cgnum == ".") {
      wx.showToast({
        title: '格式错误[整数]',
        duration: 2000,
        icon: "none"
      })

    }
    if (cgnum == "/") {
      wx.showToast({
        title: '格式错误[整数]',
        duration: 2000,
        icon: "none"
      })
    }
    if (cgnum == "%") {
      wx.showToast({
        title: '格式错误[整数]',
        duration: 2000,
        icon: "none"
      })
    }
    json[index].shicount = cgnum
    that.setData({
      json
    })
    //console.log(json)
  },
  /**
   * 计算合计
   */
  getTotal: function() {
    let that = this
    var arr = that.data.json;
    // console.log(arr)
    var totle = 0;
    for (var i = 0; i < arr.length; i++) {
      //console.log(arr[i].price);//遍历输出
      //arr[i].name = i;//赋结新值

      //totle += parseInt(arr[i].price)
      totle += arr[i].price * 1
      //console.log(arr[i].price);
    }
    that.setData({
      total: totle
    })

  },
  /**
   * 保存记帐信息
   */
  save: function() {
    let that = this
    let json = that.data.json
    let purchase = []
    for (let i = 0; i < json.length; i++) {

      purchase.push({
        goodsid: json[i].goodsid,
        shicount: json[i].shicount,
        price: json[i].price
      })

    }
    console.log(purchase);
    if (purchase.length <=0)
    {
      wx.showToast({
        title: "不需要记账",
        icon: 'none',
        mask:true,
        duration: 2000
      })
      return false;
    }
    wx.request({
      url: api + 'saccount',
      data: {
        mid: that.data.mid,
        purchase: purchase
      },
      success:function(res){
        console.log(res)
        wx.showModal({
          title: '提示',
          content: '记账成功',
          showCancel:false,
          success(res) {
            if (res.confirm) {
              that.onLoad();
              console.log('用户点击确定')
            }
          }
        })
      }

    })
   
  },
  /**
   *去分拣货品
   */
  gotofenjian: function() {

    if (!utils.isJurisdiction("1-4")) {
      return false;
    }
    wx.navigateTo({
      url: '../fjorder/fjorder',
    })
  }
  , bindtextblur:function(e){
    var that =this;
    var value = e.detail.value;
    var sindex =e.currentTarget.dataset.sindex;//索引
    var json = this.data.json;//json数据
    var stype = e.currentTarget.dataset.stype;//类型
    if (!regMoneyTwo.test(value))
    {
     
      value = parseFloat(value).toFixed(2);
      if(!value || value =="NaN")
      {
        value = 0;
      }
    }
    console.log(json[sindex])
    console.log(value)
    console.log(json[sindex][stype])
    json[sindex][stype] = value;
   
    console.log(json)
    this.setData({
      json: json
    },function(){
      that.getTotal();
    })


  }
})