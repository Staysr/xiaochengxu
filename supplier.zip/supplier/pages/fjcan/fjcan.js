var app = getApp()
var api = app.globalData.api
var util = require('../../utils/util.js')


const LAST_CONNECTED_DEVICE = 'last_connected_device'
const PrinterJobs = require('../../printer/printerjobs')
const printerUtil = require('../../printer/printerutil')


function inArray(arr, key, val) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i
    }
  }
  return -1
}

function hexToStr(str) {
  var val = "";
  var arr = str.split(",");
  for (var i = 0; i < arr.length; i++) {
    arr[i] = arr[i].replace("\\u", "")
    val += String.fromCharCode(parseInt(arr[i], 16).toString(10));
  }

  return val.trim();

}
//ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  const hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function(bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join(',')
}

function str2ab(str) {
  // Convert str to ArrayBuff and write to printer
  let buffer = new ArrayBuffer(str.length)
  let dataView = new DataView(buffer)
  for (let i = 0; i < str.length; i++) {
    dataView.setUint8(i, str.charAt(i).charCodeAt(0))
  }
  return buffer;
}
Page({
  data: {
    isstart: false //是否开始称重
  },

  onUnload() {

  },

  preventTouchMove: function() {},

  okmoney: function(e) {
    var self = this;
    self.setData({
      ismodify: false
    })
    // if (wx.getStorageSync('closeBLEConnection') == 1) {
    //this.closeBLEConnection //断开蓝牙链接
    // } else {
    //this.closeBLEConnection //断开蓝牙链接
    //this.createBLEConnection();
    this.writeBLECharacteristicValue();
    // }
  },
  /**
   * 对话框确认按钮点击事件
   */
  //初始化主页加载
  onLoad(options) {
    // if (wx.getStorageSync('closeBLEConnection') == 2) {
    //   return false
    // } else {
    // this.showDialogBtn();//模态框
    // this.openBluetoothAdapter();//吊起蓝牙的
    // let that = this
    // let nowTime = util.formatData(new Date());
    // console.log(options.nowindex)
    // console.log(options.shoplist)
    var that = this
    var shoplist = JSON.parse(options.shoplist); //
    var nowindex = JSON.parse(options.nowindex);
    this.getShopfj(options.name, options.goodsid); //获取当前id
    // }
    var linksuccess = wx.getStorageSync("linksuccess"); //当前是什么机器
 
    this.setData({
      nowindex: nowindex,
      shoplist: shoplist,
      goodsname: options.name,
      goodid:options.goodsid
    })
    if (linksuccess == "wx_printer") {
      console.log('开启了一个定时任务')
      setInterval(function() {
        that.getShopfj(options.name, options.goodsid); //获取当前id
      }, 50000)
    }

    var that = this;
    //==============================================================
    wx.onBLECharacteristicValueChange((characteristic) => {
      console.log('----------------获得的数据---------------');

      console.log(ab2hex(characteristic.value));
      console.log(characteristic);
      // if (!hexToStr(ab2hex(characteristic.value)) || hexToStr(ab2hex(characteristic.value)).length<=0)
      // {
      //   console.log('huoqubudao')
      //   return false
      // }
      console.log('----------------获得的数据---------------')
      var isstart = that.data.isstart;
      console.log(linksuccess + "：当前设备")
      console.log(hexToStr(ab2hex(characteristic.value)));  
      if (isstart && linksuccess == "wx_electronic") {
        that.setData({
          isstart: false
        })
        var nowsindex = that.data.nowsindex; //当前索引
        var json = that.data.json; //所有商品
        var canting = json[nowsindex].name; //餐厅名字
        var userdingNumber = json[nowsindex].count; //订购的斤数
        var realcount = hexToStr(ab2hex(characteristic.value)); //称重
        wx.hideLoading()
        var splitString = 0;

        //   wx.showModal({
        //     title: '调试数据',
        //     content: that.data.name + ":" + realcount ,
        //   })
        // return false;


        //  ：：：：：：：：：：；克数进行转换 ：：：：：：：：：：：：：：：：：
        var haskg = realcount.indexOf("kg");
        if (haskg != -1) {
          console.log('单位为千克');
          splitString = realcount.split('kg');
          splitString = splitString[0] * 2;
          console.log("物品的实际斤数：" + splitString)
        } else {
          console.log('单位为克');
          splitString = realcount.split('g');
          splitString = splitString[0] / 1000 * 2;
          console.log("物品的实际斤数：" + splitString)
        }
        splitString = splitString.toFixed(2)
        // ：：：：：：：：：：：克数进行转换：：：：：：：：：：：：：：：：：：
        if (userdingNumber * 1.2 >= splitString && userdingNumber <= splitString) {
          console.log('条件满足，称重成功')
        } else {
          console.log('条件不满足，是否要重新称重');
          wx.showModal({
            title: '重量不合格',
            content: that.data.name + ":" + splitString + "斤",
            showCancel: true,
            confirmText: "重新称重",
            success: function(res) {
              // that.get_electronic(nowsindex);//开始称重
              if (res.confirm) {
                that.setData({
                  isstart: true
                })
                wx.showLoading({
                  title: '称重中...',
                  mask: true
                })
              } else if (res.cancel) {
                wx.hideLoading();
              }
            }
          })
          return false;
        }
        wx.showModal({
          title: '重量合格',
          content: that.data.name + ":" + splitString + "斤",
          success: function(res) {
            if (res.confirm) {
              json[nowsindex].realcount = splitString;
              
              that.startcount(json, nowsindex)

  
              that.setData({
                json: json
              })
            }
          }
        })
      }
      wx.setStorageSync('meas_val', hexToStr(ab2hex(characteristic.value)))
      console.log(hexToStr(ab2hex(characteristic.value)))

    })
    //==============================================================


  },

  startcount: function(json, nowsindex) {
     var that =this;
     wx.showLoading({
       title: '加载中...',
       mask:true
     })
    var goodname = this.data.goodsname;
    var goodid = this.data.goodid;
    wx.request({
      url: api + 'sortingOK',
      data: {
        id: json[nowsindex].id,
        realcount: json[nowsindex].realcount,
        count: json[nowsindex].count
      },
      success(res) {
     
        console.log(res)
        that.getShopfj(goodname, goodid); //获取当前id
      }
    })
  },
  // 获取当前分拣id的东西
  getShopfj: function(name, goodsid) {
    var that = this;
    wx.showLoading({
      title: '加载中...',
      mask:true
    })
    wx.request({
      url: api + 'gsortingInfo',
      data: {
        sid: wx.getStorageSync('sid'),
        goodsid: goodsid
      },
      success(res) {
        console.log(res)
        wx.hideLoading();
        that.setData({
          json: res.data.sorting,
          name: name,
          goodsid: goodsid
        })
      }
    })
  },
  // 获取本机蓝牙配置状态
  getBluetoothAdapterState() {
    wx.getBluetoothAdapterState({
      success: (res) => {
        console.log('getBluetoothAdapterState', res)
        if (res.discovering) {
          this.onBluetoothDeviceFound()
        } else if (res.available) {
          this.startBluetoothDevicesDiscovery()
        }
      }
    })
  },
  //获取特征值,给后台
  conte: function(e) {
    let that = this;
    var state = e.currentTarget.dataset.state;
    var sindex = e.currentTarget.dataset.sindex; //当前索引
    var name = e.currentTarget.dataset.name; //当前索引
    var json = that.data.json; //当前所有商品
    var isfenjian = e.currentTarget.dataset.isfenjian;
    var goodsid = e.currentTarget.dataset.goodsid; //商品id
    var linksuccess = wx.getStorageSync("linksuccess"); //当前设备



    if (linksuccess == "wx_electronic") {
      if (state != 1) {
        that.get_electronic(sindex); //开始称重
      } else {
        console.log('不需要称重');
        return false;
      }
    } else if (linksuccess == "wx_printer") {

      get_printer()
    }


    // 获取打印机的一些信息提示

    function get_printer() {
      console.log("打印机");
      // print1
      wx.request({
        url: api + 'print1',
        data: {
          id: goodsid
        },
        success(res) {
          console.log(res)
          if (res.data.code == 1) {
            that.writeBLECharacteristicValue(res.data.print); //打印电子票
          } else if ((res.data.code == 2)) {
            wx.showToast({
              title: res.data.msg,
              icon: "none",
              duration: 800
            })
          } else {
            console.log(res);
          }
        }
      })

      // if (isfenjian !=1)
      // {
      //   wx.showToast({
      //     title: '当前商品，无法打印小票',
      //     icon: "none", duration:2000
      //   })
      //   return false;
      // }
      // that.writeBLECharacteristicValue();//打印电子票


    }



    // 获取电子称 的一些信息提示
    // function get_electronic(){
    //   console.log("电子称")
    //   var sindex = e.currentTarget.dataset.sindex;//当前索引
    //   wx.showModal({
    //     title: '提示',
    //     content: that.data.name  + "开始称重",
    //     success: function (res) {
    //       if (res.confirm) {
    //         that.setData({
    //           isstart: true,
    //           nowsindex: sindex
    //         })
    //         wx.showLoading({
    //           title: '称重中...',
    //           mask: true
    //         })
    //       }
    //       else {
    //         that.setData({
    //           isstart: false
    //         })
    //         console.log('取消称重')
    //       }
    //     }
    //   })

    // }





    return false;
  },

  // ：：：：：：：：：开始称重：：：：：：：：：：：：：：：：：
  get_electronic: function(sindex) {

      var that = this;

      console.log("电子称")
      wx.showModal({
        title: '提示',
        confirmText: "开始称重",
        content: that.data.name + "准备称重",
        success: function(res) {
          if (res.confirm) {
            that.setData({
              isstart: true,
              nowsindex: sindex
            })
            wx.showLoading({
              title: '称重中...',
              mask: true
            })
          } else {
            that.setData({
              isstart: false
            })
            console.log('取消称重')
          }
        }
      })

    }
    //  ：：：：：：：：：开始称重：：：：：：：：：：：：：：：：：

    ,

  //不用称重 修改值:::::::::::::::::::::
  bindblurIput: function(e) {
    // id: json[nowsindex].id,
    // realcount: json[nowsindex].realcount,
    // count: json[nowsindex].count
    var json = this.data.json;
    var sindex = e.currentTarget.dataset.sindex; //当前索引
    var realcount = e.detail.value; //当前的值
    console.log("_".repeat(20))
    console.log(sindex)
    console.log(json)
    console.log(parseFloat(realcount).toFixed(2))
    console.log("_".repeat(20))
    json[sindex].realcount = parseFloat(realcount).toFixed(2);

    this.startcount(json, sindex)
  },
  // 分拣下一个货物
  gonext: function() {

      var nowindex = this.data.nowindex;
      var shoplist = this.data.shoplist;
      var nextindex = nowindex * 1 + 1;
      console.log(nextindex)
      console.log(shoplist.length)
      if (nextindex >= shoplist.length) {
        console.log('不存在下一个商品了')
        wx.showModal({
          title: '提示',
          content: '已经是最后一个了',
          confirmText: "返回列表",
          success(res) {
            if (res.confirm) {
              wx.navigateBack({
                delta: 1
              }); //返回上一页
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      } else {
        wx.redirectTo({
          url: '../fjcan/fjcan?goodsid=' + shoplist[nextindex].goodsid + '&name=' + shoplist[nextindex].name + "&nowindex=" + nextindex + "&shoplist=" + JSON.stringify(shoplist)
        })
      }
    }

    ,
  goback: function() {
      wx.navigateBack({
        delta: 1
      })
    }






    // =================================================================
    // ==========================打印小票================================
    // ==================================================================
    ,
  writeBLECharacteristicValue(print) {
    console.log(print)
    let nowTime = util.formatData3(new Date());
    let printerJobs = new PrinterJobs();

    printerJobs
      .print(nowTime)
      .print(printerUtil.fillLine())
      .setAlign('ct')
      .setSize(2, 2)
      .print("#序号" + print.number)
      .setSize(1, 1)
      .print("#名称" + print.sname)
      .setSize(2, 2)
      .print(print.cname)
      .setSize(1, 1)
      .print('订购量' + print.count+"(斤)")
      .setSize(1, 1)
      .print('实际斤数' + print.realcount + "(斤)")
      .print()
      .print()
    let buffer = printerJobs.buffer();
    console.log('ArrayBuffer', 'length: ' + buffer.byteLength, ' hex: ' + ab2hex(buffer));
    // 1.并行调用多次会存在写失败的可能性
    // 2.建议每次写入不超过20字节
    // 分包处理，延时调用
    const maxChunk = 20;
    const delay = 20;
    for (let i = 0, j = 0, length = buffer.byteLength; i < length; i += maxChunk, j++) {
      let subPackage = buffer.slice(i, i + maxChunk <= length ? (i + maxChunk) : length);
      setTimeout(this._writeBLECharacteristicValue, j * delay, subPackage);
    }

  },
  //向低功耗蓝牙写入数据
  _writeBLECharacteristicValue(buffer) {

    var _deviceId = wx.getStorageSync("_deviceId");
    var _serviceId = wx.getStorageSync("_serviceId");
    var _characteristicId = wx.getStorageSync("_characteristicId");

    wx.writeBLECharacteristicValue({
      deviceId: _deviceId,
      serviceId: _serviceId,
      characteristicId: _characteristicId,
      value: buffer,
      success(res) {
        console.log('writeBLECharacteristicValue success', res)
      },
      fail(res) {
        console.log('writeBLECharacteristicValue fail', res)
      }
    })
    // this.closeBluetoothAdapter();
    // this.closeBLEConnection();
  }
  // =================================================================
  // ==========================打印小票结束================================
  // ==================================================================

})