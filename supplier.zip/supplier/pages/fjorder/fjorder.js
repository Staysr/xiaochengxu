// pages/fjorder/fjorder.js
var app = getApp()
var api = app.globalData.api;
var timer;
// var  apihtp =require("../../utils/wx_electronic.js")

// ============================初始化蓝牙======================================
// ============================初始化蓝牙======================================
// ============================初始化蓝牙======================================
var utils = require('../../utils/util.js')
const LAST_CONNECTED_DEVICE = 'last_connected_device'
const PrinterJobs = require('../../printer/printerjobs')
const printerUtil = require('../../printer/printerutil')

function inArray(arr, key, val) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i
    }
  }
  return -1
}

function hexToStr(str) {
  var val = "";
  var arr = str.split(",");
  for (var i = 0; i < arr.length; i++) {
    arr[i] = arr[i].replace("\\u", "")
    val += String.fromCharCode(parseInt(arr[i], 16).toString(10));
  }
  return val.trim();
}
//ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  const hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function(bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join(',')
}

function str2ab(str) {
  // Convert str to ArrayBuff and write to printer
  let buffer = new ArrayBuffer(str.length)
  let dataView = new DataView(buffer)
  for (let i = 0; i < str.length; i++) {
    dataView.setUint8(i, str.charAt(i).charCodeAt(0))
  }
  return buffer;
}
// ============================初始化蓝牙======================================
// ============================初始化蓝牙======================================
// ============================初始化蓝牙======================================
Page({

  /**
   * 页面的初始数据
   */
  data: {

    // 初始化蓝牙=================================================================
    devices: [],
    devices1: [],
    connected: false,
    chs: [],
    showOrHidden: true,
    json: false,
    showModal: false,
    ismodify: false, //点击修改出现的弹窗
    // 初始化蓝牙=============================================================
    // tab 切换
    tabArr: {
      curHdIndex: 1,
      curBdIndex: 0,
    },
    curHdIndex:1,
    slect_box: false


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    //  this.openBluetoothAdapter();//开启蓝牙
    var that = this;

    var linksuccess = wx.getStorageSync('linksuccess');
    // var lanyashebe = linksuccess ? linksuccess == "wx_electronic" ? "当前设备为电子秤" : linksuccess == "wx_printer" ? "当前设备为打印机" : "无添加任何设备" : "无添加任何设备"
    var name = "";

    if (linksuccess == "wx_printer") {
      name = "当前设备为打印机"
    } else if (linksuccess == "wx_electronic") {
      name = "当前设备为电子秤"
    } else {
      name = "无添加任何设备"
    }
    that.setData({
      name: name
    })
    wx.getBluetoothDevices({
      success(res) {
        console.log(res)
        if (res.devices[0]) {
          console.log(ab2hex(res.devices[0].advertisData))
        }
      },
      fail: function(res) {
        console.log(res)
      }
    })
    wx.onBluetoothAdapterStateChange(function(res) {
      //console.log('onBluetoothAdapterStateChange', res)
      console.log('--------------蓝牙已经断开连接-------------------')
      if (!res.available) {
        that.closeBLEConnection();
        that.removeLanyaStro(); //移除蓝牙链接的缓存
        that.stopBluetoothDevicesDiscovery(); //停止搜索
      }
      console.log('--------------蓝牙已经断开连接-------------------')
    })
    that.nowlanyastop(); //验证蓝牙是否被关闭

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {



  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this;
    
    var curHdIndex = this.data.curHdIndex;//当前列表信息
    this.getonshoplist(curHdIndex);//获取当前的信息列表
    return false
    // wx.request({
    //   url: api + 'sortingList',
    //   data: {
    //     sid: wx.getStorageSync('sid')
    //   },
    //   success(res) {
    //     console.log(res)
    //     //0代表未分拣,2分拣中,1代表已分拣

    //     let json = res.data.sorting ? res.data.sorting : [];
    //     console.log(json)
    //     for (let i = 0; i < json.length; i++) {
    //       if (json[i].isfenjian == 0) {
    //         json[i].status = 0
    //       } else if (json[i].isfenjian == 1) {
    //         json[i].status = 1
    //       } else {
    //         // gsortingInfo
    //         json[i].status = 2
    //       }
    //     }
    //     that.setData({
    //       json,
    //       fenjian: res.data.fenjian
    //     })

    //   }
    // })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    this.removeLanyaStro();//清楚所有蓝牙缓存
    this.closeBLEConnection();//断开蓝牙
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  //tab切换
  tab: function(e) {
    let that = this
    //var dataId = e.currentTarget.dataset.id;
    var dataId = e.currentTarget.id;
    var obj = {};
    // obj.curHdIndex = dataId;
    // obj.curBdIndex = dataId;
    // this.setData({
    //   tabArr: obj
    // })
    this.setData({
      curHdIndex: dataId
    })
    this.getonshoplist(dataId);//获取当前的信息列表
    console.log(dataId);
  
  },
// ：：：：：：：：：：：：：：：：：：：：：：：：：：：：：获取商品列表
  getonshoplist: function (dataId){
    let that =this;
    wx.showLoading({
      title: '加载中...',
      mask:true
    })
    if (dataId == 1) {
      wx.request({
        url: api + 'sortingList',
        data: {
          sid: wx.getStorageSync('sid')
        },
        success(res) {
          wx.hideLoading()
          console.log(res)
          let json = res.data.sorting ? res.data.sorting : [];
          for (let i = 0; i < json.length; i++) {
            if (json[i].isfenjian == 0) {
              json[i].status = 0
            } else if (json[i].isfenjian == 1) {
              json[i].status = 1
            } else {
              json[i].status = 2
            }
          }
          that.setData({
            json, fenjian: res.data.fenjian
          })

        }
      })
    } else if (dataId == 2) {
      wx.request({
        url: api + 'sortingList',
        data: {
          sid: wx.getStorageSync('sid'),
          type: 1
        },
        success(res) {
          wx.hideLoading()
          console.log(res)
          let json = res.data.sorting ? res.data.sorting : [];
          for (let i = 0; i < json.length; i++) {
            if (json[i].isfenjian == 0) {
              json[i].status = 0
            } else if (json[i].isfenjian == 1) {
              json[i].status = 1
            } else {
              json[i].status = 2
            }
          }
          that.setData({
            canting: json, fenjian: res.data.fenjian
          })

        }
      })
    }
  }
// ：：：：：：：：：：：：：：：：：：：：：：：：：：：：：获取商品列表
  ,
  gotoinfo: function(e) {
    // ------------------------
    // let that = this;
    // var equipment_key = wx.getStorageSync("equipment_key");
    // var linksuccess = wx.getStorageSync("linksuccess");
    // wx.getBluetoothAdapterState({
    //   success: function(res) {
    //     console.log(res)
    //     // =======================================================================================
    //     // ==========================判断当前是否已经连接蓝牙了---打印机 和称重机=====================
    //     if (res.available) {
    //       if (linksuccess == "wx_printer" || linksuccess == "wx_electronic") {
    //         gotolinkpage(); //跳转到下一个页面
    //       } else {
    //         wx.showModal({
    //           title: '提示',
    //           content: '请点击下方设置可用蓝牙',
    //           showCancel: false
    //         })
    //       }
    //     } else {
    //       that.closeBLEConnection();
    //       that.removeLanyaStro(); //移除蓝牙链接的缓存
    //       wx.showModal({
    //         title: '错误',
    //         content: '未找到蓝牙设备, 请打开蓝牙后重试。',
    //         showCancel: false
    //       })
    //     }

    //     // ==========================判断当前是否已经连接蓝牙了---打印机 和称重机====================
    //     // ======================================================================================
    //   },
    //   fail: function(res) {
    //     that.closeBLEConnection();
    //     that.removeLanyaStro(); //移除蓝牙链接的缓存
    //     console.log(res);
    //     wx.showModal({
    //       title: '提示',
    //       content: 'fail：请点击下方设置蓝牙',
    //       showCancel: false
    //     })
    //     // promptusers(); //提示用户---还未连接蓝牙设备
    //   }
    // })
var that =this;
    this.needlaya(gotolinkpage)
    return false;
    // -------------------
    // 前往下一个页面进行分拣
    function gotolinkpage() {
      let goodsid = e.currentTarget.dataset.id
      let name = e.currentTarget.dataset.name;
      let sindex = e.currentTarget.dataset.sindex; //索引
      let shoplist = that.data.json; //当前所有数据
      shoplist = JSON.stringify(shoplist)
      // console.log(goodsid)
      // console.log(name)
      // console.log(shoplist)
      // console.log(sindex)
      // console.log(shoplist[sindex * 1 + 1])
      // nextgoodis = shoplist[sindex * 1 + 1].goodsid
      // nextname = shoplist[sindex * 1 + 1].name
      wx.navigateTo({
        url: '../fjcan/fjcan?goodsid=' + goodsid + '&name=' + name + "&nowindex=" + sindex + "&shoplist=" + shoplist
      })
    }



  },
  gotoinfo1: function(e) {
    wx.showLoading({
      title: '跳转中...',
      mask:true
    })
    var that = this;
    this.needlaya(gotolinkpage)
    return false;
// 前往餐厅：：：：：：：：：：：：：：：：：：：：
    function gotolinkpage() {
      var sindex = e.currentTarget.dataset.sindex; //索引
      var cantinglist = that.data.canting; //餐厅列表
      cantinglist = JSON.stringify(cantinglist);
      wx.navigateTo({
        url: '../fjproduct/fjproduct?sindex=' + sindex + '&cantinglist=' + cantinglist,
      },function(){
        wx.hideLoading()
      })
    }

  }

  //判断是否需要连接蓝牙：：：：：：：：：：：：：：：：：：：：：
  , needlaya: function (gotolinkpage){
    let that = this;
    var equipment_key = wx.getStorageSync("equipment_key");
    var linksuccess = wx.getStorageSync("linksuccess");
    wx.getBluetoothAdapterState({
      success: function (res) {
        console.log(res)
        // =======================================================================================
        // ==========================判断当前是否已经连接蓝牙了---打印机 和称重机=====================
        if (res.available) {
          if (linksuccess == "wx_printer" || linksuccess == "wx_electronic") {
            gotolinkpage(); //跳转到下一个页面
          } else {
            wx.showModal({
              title: '提示',
              content: '请点击下方设置可用蓝牙',
              showCancel: false
            })
          }
        } else {
          that.closeBLEConnection();
          that.removeLanyaStro(); //移除蓝牙链接的缓存
          wx.showModal({
            title: '错误',
            content: '未找到蓝牙设备, 请打开蓝牙后重试。',
            showCancel: false
          })
        }
        // ==========================判断当前是否已经连接蓝牙了---打印机 和称重机====================
        // ======================================================================================
      },
      fail: function (res) {
        that.closeBLEConnection();
        that.removeLanyaStro(); //移除蓝牙链接的缓存
        console.log(res);
        wx.showModal({
          title: '提示',
          content: '请点击下方设置蓝牙',
          showCancel: false
        })
        // promptusers(); //提示用户---还未连接蓝牙设备
      }
      ,complete:function(){
        wx.hideLoading()
      }
    })
  }

  ,
  gotopeisong: function() {

      // var wx_fen_key = wx.getStorageSync('wx_fen_key');
      var fenjian = this.data.fenjian; //是否可以配送
      if (!utils.isJurisdiction("1-5")) {
        return false;
      }
      if (fenjian == 1) {

        wx.showModal({
          title: '提示',
          content: '确定要配货?',
          cancelText: "取消配货",
          confirmText: "确定配货",
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
              setdeliver(); //用户配货
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })

      } else if (fenjian == 2) {

        wx.showModal({
          title: '提示',
          content: '是否要缺货配货?',
          cancelText: "继续分拣",
          confirmText: "确定配货",
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
              setdeliver(); //用户配货
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })

      } else {
        wx.showModal({
          title: '提示',
          content: '当前无法配送',
          showCancel: false
        })
        return false;
      }



      function setdeliver() {
        wx.showLoading({
          title: '配货中...',
          mask: true
        })
        wx.request({
          url: api + 'deliver',
          data: {
            sid: wx.getStorageSync('sid'),
          },
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          method: 'post',
          success: function(res) {
            console.log(res)
            wx.hideLoading();
            if (res.data.code == 1) {
              wx.navigateTo({
                url: '../psorder/psorder',
              })
            }
          }
        })
      }


    }


    // =================================================================
    // ==========================开始打印电子秤===========================
    // ==================================================================
    // 初始化蓝牙
    ,
  openBluetoothAdapter(fuc) {
    if (!wx.openBluetoothAdapter) {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
      return
    }
    wx.openBluetoothAdapter({
      success: (res) => {
        //console.log('openBluetoothAdapter success', res)
        this.startBluetoothDevicesDiscovery();
      },
      fail: (res) => {
        if (res.errCode === 10001) {
          wx.showModal({
            title: '错误',
            content: '未找到蓝牙设备, 请打开蓝牙后重试。',
            showCancel: false
          })
          that.closeBLEConnection();
          that.removeLanyaStro(); //移除蓝牙链接的缓存


        }
      }
    })
  },
  // 获取本机蓝牙配置状态
  getBluetoothAdapterState() {
    wx.getBluetoothAdapterState({
      success: (res) => {
        console.log('getBluetoothAdapterState', res)
        if (res.discovering) {
          this.onBluetoothDeviceFound()
        } else if (res.available) {
          this.startBluetoothDevicesDiscovery()
        }
      }
    })

  },
  //开始搜索附近蓝牙
  startBluetoothDevicesDiscovery() {
    // console.log(this._discoveryStarted)
    // if (this._discoveryStarted) {
    //   return
    // }
    console.log('搜索中')
    // this._discoveryStarted = true
    wx.startBluetoothDevicesDiscovery({
      allowDuplicatesKey: true,
      success: (res) => {
        console.log('startBluetoothDevicesDiscovery success', res)
        this.onBluetoothDeviceFound()
      },
      //开始搜索附近蓝牙 抛出异常
      fail: (res) => {
        console.log('startBluetoothDevicesDiscovery fail', res)
      }
    })
  },
  //停止搜索蓝牙
  stopBluetoothDevicesDiscovery() {
    wx.stopBluetoothDevicesDiscovery()
    // this._discoveryStarted = false
  },

  //监听新设备链接
  onBluetoothDeviceFound() {
    wx.onBluetoothDeviceFound((res) => {
      res.devices.forEach(device => {
        if (!device.name && !device.localName) {
          return
        }
        const foundDevices = this.data.devices
        const idx = inArray(foundDevices, 'deviceId', device.deviceId)
        const data = {}
        if (idx === -1) {
          data[`devices[${foundDevices.length}]`] = device
        } else {
          data[`devices[${idx}]`] = device
        }
        // console.log(data)
        this.setData(data)
      })
    })
  },
  //链接低功耗蓝牙
  createBLEConnection(e) {

    const ds = e.currentTarget.dataset
    const deviceId = ds.deviceId
    const name = ds.name;

    const equipment_key = wx.getStorageSync("equipment_key");
    // ===============================================================//
    if (name.indexOf("AUTODA") != -1 && equipment_key == "wx_electronic") {
      console.log('链接上电子秤设备');
      this._createBLEConnection(deviceId, name);
    } else if (name.indexOf("Qsprinter") != -1 && equipment_key == "wx_printer") {
      console.log('连接上打印机');
      this._createBLEConnection(deviceId, name);
    } else {
      console.log('当前电子设备不可用')
      wx.showToast({
        title: '当前设备不可连接',
        icon: 'none',
        duration: 500
      })
    }
    // ===============================================================//
    return false;
  },
  _createBLEConnection(deviceId, name) {
    var that = this;
    wx.showLoading()
    wx.createBLEConnection({
      deviceId,
      success: () => {
        console.log('createBLEConnection success');
        wx.setStorageSync("wx_isinkblueya", name);
        const equipment_key = wx.getStorageSync("equipment_key");
        if (name.indexOf("AUTODA") != -1 && equipment_key == "wx_electronic") {
          console.log('链接上电子秤设备');
          this.setData({
            connected: true,
            name: "当前设备为电子秤",
            deviceId,
          })
          this.getBLEDeviceServices(deviceId)
          wx.setStorageSync("linksuccess", "wx_electronic")
        } else if (name.indexOf("Qsprinter") != -1 && equipment_key == "wx_printer") {
          console.log('连接上打印机');
          this.setData({
            connected: true,
            name: "当前设备为打印机",
            deviceId,
          })
          this.getBLEDeviceServices(deviceId)
          wx.setStorageSync("linksuccess", "wx_printer")
        } else {

        }
        that.stopBluetoothDevicesDiscovery();
      },
      complete() {
        wx.hideLoading()
      },
      fail: (res) => {
        console.log('createBLEConnection fail', res);
        wx.showModal({
          title: '提示',
          showCancel: false,
          content: "链接失败",
          success(res) {
            if (res.confirm) {
              console.log('用户点击确定')
            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      }
    })
    // this.stopBluetoothDevicesDiscovery()
  },
  //断开低功耗蓝牙链接：：：：：：：：：：：：：：：：：：：：：：：：：：：：：
  closeBLEConnection() {
    // this.closeBluetoothAdapter();//关闭蓝牙模块
    //关闭蓝牙低功耗模块
    wx.closeBLEConnection({
      deviceId: this.data.deviceId
    })
    this.setData({
      connected: false,
      chs: [],
      canWrite: false,
    })
  },


  //获取蓝牙的service服务：：：：：：：：：：：：：：：：：：：：：：：：：：：
  getBLEDeviceServices(deviceId) {
    wx.getBLEDeviceServices({
      deviceId,
      success: (res) => {
        for (let i = 0; i < res.services.length; i++) {
          if (res.services[i].isPrimary) {
            this.getBLEDeviceCharacteristics(deviceId, res.services[i].uuid)
            return
          }
        }
      }
    })
  },
  //获取蓝牙的特征值[读取]
  getBLEDeviceCharacteristics(deviceId, serviceId) {
    wx.getBLEDeviceCharacteristics({
      deviceId,
      serviceId,
      success: (res) => {
        console.log('getBLEDeviceCharacteristics success', res.characteristics)
        for (let i = 0; i < res.characteristics.length; i++) {
          let item = res.characteristics[i];
          if (item.properties.read) {
            console.log('可读的连接蓝牙设备')
            // wx.readBLECharacteristicValue({
            //   deviceId,
            //   serviceId,
            //   characteristicId: item.uuid,
            // })
          }
          if (item.properties.write) {
            console.log('可写入的蓝牙设备')
            this.setData({
              canWrite: true
            })
            wx.setStorageSync("_deviceId", deviceId); //存下来设备id
            wx.setStorageSync("_serviceId", serviceId); //存下来服务id
            wx.setStorageSync("_characteristicId", item.uuid); //characterid
            this._deviceId = deviceId
            this._serviceId = serviceId
            this._characteristicId = item.uuid

            //this.GetbleDeviceCharacteristics()
          }
          if (item.properties.notify || item.properties.indicate) {
            wx.notifyBLECharacteristicValueChange({
              deviceId,
              serviceId,
              characteristicId: item.uuid,
              state: true,
            })
          }
        }
      },
      fail(res) {
        console.error('getBLEDeviceCharacteristics', res)
      }
    })
  },
  //关闭蓝牙模块,[蓝牙结束]
  closeBluetoothAdapter() {
    wx.closeBluetoothAdapter()
    // this._discoveryStarted = false
  }
  // =================================================================
  // ==========================电子秤结束================================
  // ==================================================================

  // 断开蓝牙::::::::::::::::::::::::::::::::::::
  ,
  closelanya: function() {
      wx.stopBluetoothDevicesDiscovery({
        success(res) {
          console.log(res)
        }
      })
      this.setData({
        slect_box: false
      })
    }
    // 链接蓝牙:::::::::::::::::::::::::::::::::::::
    ,
  lianjielanya: function() {
      var that = this;
      if (!wx.openBluetoothAdapter) {
        wx.showModal({
          title: '提示',
          content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
        })
        return
      }
      wx.openBluetoothAdapter({
        success: (res) => {
          promptusers(); //开始进入下一步
        },
        fail: (res) => {
          if (res.errCode === 10001) {
            that.closeBLEConnection();
            that.removeLanyaStro(); //移除蓝牙链接的缓存
            wx.showModal({
              title: '错误',
              content: '未找到蓝牙设备, 请打开蓝牙后重试。',
              showCancel: false
            })
          }
        }
      })



      // 提示用户连接蓝牙promptusers  ---提示用户
      function promptusers() {
        wx.showModal({
          title: '提示',
          content: '选择想要链接的蓝牙设备',
          confirmText: "打印机",
          cancelText: "电子秤",
          success(res) {
            if (res.confirm) {
              that.setData({
                slect_box: true
              })
              console.log('你选择了打印机')
              wx.setStorageSync("equipment_key", "wx_printer");
              that.openBluetoothAdapter(); //开启蓝牙
            } else if (res.cancel) {
              that.setData({
                slect_box: true
              })
              wx.setStorageSync("equipment_key", "wx_electronic")
              that.openBluetoothAdapter(); //开启蓝牙
            }
          }
        })
      }

    }
    // 监听到蓝牙已经被关闭了:::::::::::::::::::::::::::::::::::::
    ,
  nowlanyastop: function() {
      var that = this;
      wx.onBLEConnectionStateChange((res) => {
        // 该方法回调中可以用于处理连接意外断开等异常情况
        console.log(res)
        console.log('onBLEConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
        // this.setData({
        //   connected: res.connected
        // })
        if (!res.connected) {
          that.removeLanyaStro(); //移除蓝牙链接的缓存
          wx.showModal({
            title: '错误',
            content: '蓝牙连接已断开',
            showCancel: false
          })
        }
      });
    }
    // 移除蓝牙链接的所有缓存：：：：：：：：：：：：：：：：：：：：：：：：：：
    ,
  removeLanyaStro: function() {
    wx.removeStorageSync("linksuccess"); //一移除当前状态
    wx.removeStorageSync("wx_isinkblueya"); //移除蓝牙的名字
    wx.removeStorageSync("last_connected_device"); //移除最后一次链接的设备
    wx.removeStorageSync("_deviceId"); //移除设备
    wx.removeStorageSync("_serviceId"); //移除服务id
    wx.removeStorageSync("_characteristicId "); //移除charaid
    this.setData({
      name: "无添加任何设备"
      , deviceId: "", connected:false
    })
  }
})