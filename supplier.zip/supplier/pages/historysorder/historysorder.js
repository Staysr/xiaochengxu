// pages/historysorder/historysorder.js
var app = getApp();
var api = app.globalData.api;
var util = require('../../utils/util.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {

    page:1
  },
// util.formatData2(new Date())
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    let nowTime = util.formatData2(new Date());
    that.setData({
      nowTime,
      date2: nowTime,
      date1: nowTime
    })
    wx.request({
      url: api +'pastOrder',
      data:{
        sid:wx.getStorageSync('sid'),
        stime:that.data.date1,
        etime: that.data.nowTime,
        page: that.data.page
      },
      success(res){
        that.setData({
          lists: res.data.order
        })
      }

    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    let that = this
    let page = that.data.page
    console.log(page)
    that.setData({
      page: page++
    })
    wx.request({
      url: api + 'pastOrder',
      data: {
        sid: wx.getStorageSync('sid'),
        stime: that.data.date1,
        etime: that.data.date2,
        page: that.data.page
      },
      success(res) {
        let lists = tha.data.lists
        let newlists = res.data.order
        for (i = 0; i < newlists.length; i++) {
          lists.push(newlists[i])
        }

        that.setData({
          lists
        })

      }

    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 跳转到餐厅订单
   */
  gotoinfo: function (e) {
    let id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../allorder/allorder?id='+id,
    })
  },
//  时间的选择
  bindDateChange(e) {
    let that = this
    let index = e.currentTarget.dataset.index
    if(index==1){
      this.setData({
        date1: e.detail.value
      })
    }else if(index==2){
      this.setData({
        date2: e.detail.value
      })
    }
    wx.request({
      url: api + 'pastOrder',
      data: {
        sid: wx.getStorageSync('sid'),
        stime: that.data.date1,
        etime: that.data.date2,
        page: that.data.page
      },
      success(res) {
        console.log(res)
        if(res.data.order.length == 0){
          wx.showToast({
            title: "没有订单",
            duration: 2000,
            icon: "none"
          })
        }
        that.setData({
          lists: res.data.order,
          page:1
        })
     
      }

    })
    
  },
  // 第2个时间的选择
  // bindDateChange2(e) {
  //   this.setData({
  //     date2: e.detail.value
  //   })
  // },
})