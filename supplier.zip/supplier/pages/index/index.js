//index.js
//获取应用实例
const app = getApp()
var api = app.globalData.api;
var util = require('../../utils/util.js');




var timer;
Page({
  data: {
    imgUrls: [],

    kucun: [{
        kunimg: "../images/baojia.png",
        title: "我的报价"
      , power:"1-1",
      url:"../myoffer/myoffer"
      },
      {
        kunimg: "../images/dingdan.png",
        title: "我的订单", power: "1-6",        url:"../myorder/myorder"
      },
      {
        kunimg: "../images/kucun.png",
        title: "盘点库存", power: "1-2"
        ,
        url: "../pandian/pandian"
      },
      {
        kunimg: "../images/jizhangdan.png",
        title: "采购记账单", power: "1-3"
        ,
        url: "../cgorder/cgorder"
      },
      {
        kunimg: "../images/fenjian.png",
        title: "分拣单", power: "1-4"
        ,
        url: "../fjorder/fjorder"
      },
      {
        kunimg: "../images/peisong.png",
        title: "配送单", power: "1-5"
        ,
        url: "../psorder/psorder"
      }
    ]

  },
  onLoad: function() {
      // wx.onBluetoothAdapterStateChange(function(res) {
      //   console.log(res)
      // })
  }
    // 开启一个定时器
    ,
  startimer: function() {
    let that = this
    wx.request({
      url: api + 'suserinfo',
      data: {
        uid: wx.getStorageSync('userid')
      },
      success(res) {
        console.log(res)
        if (res.data.code == 1) {
          wx.setStorageSync("power", res.data.power)
          that.setData({
            power: res.data.power
          })
        } else {
          wx.showModal({
            title: '提示',
            content: "该账户已被删除，请重新登录",
            showCancel: false,
            success(res) {
              wx.reLaunch({
                url: '../signIn/signIn'
              })
            }
          })
        }
      }
    })

  },
  getUserInfo: function(e) {

  },
  change: function(e) {

    var userid = wx.getStorageSync("userid");
    var form_id = e.detail.formId;
    console.log('~'.repeat(20))
    console.log(e)
    console.log(userid)
    console.log(form_id)
    console.log('~'.repeat(20))
    wx.request({
      url: app.globalData.staticUrlxin + "setformid",
      data: {
        userid: userid,
        form_id: form_id
      },
      header: { 'content-type': "application/json" },
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
        console.log("恭喜你设置form_id成功")
      },
      fail: function (res) { },
      complete: function (res) { },
    })



var that  =this;
    var wx_key_code = wx.getStorageSync('wx_key_code');
    var userpower =that.data.power;//用户的权限
    var power = e.currentTarget.dataset.power;//用户的权限
    var index = e.currentTarget.dataset.index;//当前索引
    console.log(wx_key_code);
    if (wx_key_code != 2) {
      wx.navigateTo({
        url: '../signIn/signIn',
      })
      return false;
    }
    console.log(userpower.indexOf(power))
    if (userpower.indexOf(power) < 0 ) {
        wx.showToast({
          title: "暂无权限",
          icon: "none",
          duration: 1500,
          mask: true
        })
        return false;
    }

    wx.navigateTo({
      url: e.currentTarget.dataset.url,
    });

return false;
    switch (index) {
      case 0:
        wx.navigateTo({
          url: '../myoffer/myoffer',
        });
        return false;
      case 1:
        wx.navigateTo({
          url: '../myorder/myorder',
        });
        return false;
      case 2:
        wx.navigateTo({
          url: '../pandian/pandian',
        });
        return false;
      case 3:
        wx.navigateTo({
          url: '../cgorder/cgorder',
        });
        return false;
      case 4:
        wx.navigateTo({
          url: '../fjorder/fjorder',
        });
        return false;
      case 5:
        wx.navigateTo({
          url: '../psorder/psorder',
        });
        return false;
    }
  },
  onShow: function() {
    let that = this
    var wx_key_code = wx.getStorageSync('wx_key_code');
    if (wx_key_code == 2) {
      console.log('定时器执行了')
      that.startimer(); //开启一个定时器
    }
    console.log(api + 'banner')
    wx.request({
      url: api + 'banner',
      data: {},
      success(res) {
        console.log(res)
        that.setData({
          imgUrls: res.data.banner
        })
      }
    })
  },
  applyUpload() {
    var wx_key_code = wx.getStorageSync('sid')
    if (wx_key_code == []) {
      wx.navigateTo({
        url: '../signIn/signIn',
      })
      return false;
    } else {
      wx.navigateTo({
        url: '../applyUpload/applyUpload',
      })
    }
  }


  , onShareAppMessage: function (res) {
    var that = this;
    var userid = wx.getStorageSync("userid");
    // imageUrl: 'https://ceshi.guirenpu.com/images/banner.png',
    return {
      title: '邀请好友',
      path: '/pages/register/register?userid=' + userid, //这里拼接需要携带的参数
      imageUrl: "../images/yq.png",
      success: function (res) {
        console.log("转发成功" + res);
      }
    }
  }
})