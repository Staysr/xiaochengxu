// pages/myoffer/myoffer.js
var app = getApp();
var api = app.globalData.api;
var regMoneyTwo = app.globalData.regMoneyTwo//正则
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ismodify:false,//点击修改出现的弹窗
    isshow:3,
    movableViewInfo: {
      y: 0,
      showClass: 'none',
      data: {}
    },

    pageInfo: {
      rowHeight: 47,
      scrollHeight: 90,
      startIndex: null,
      scrollY: true,
      readyPlaceIndex: null,
      startY: 0,
      selectedIndex: null,
    },
    //决绝安卓滑动卡顿
    scrollPosition: {
      everyOptionCell: 65,
      top: 47,
      scrollTop: 0,
      scrollY: true,
      scrollViewHeight: 1000,
      scrollViewWidth: 375,
      windowViewHeight: 1000,
    },
    //决绝安卓滑动卡顿
    selectItemInfo: {
      sName: "",
      sDtSecCode: "",
      sCode: "",
      selectIndex: -1,
      selectPosition: 0,
    },
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中...',
      mask:true
    })
    let that = this
    wx.request({
      url: api+ 'myOffer',
      data:{
        sid:wx.getStorageSync('sid')
      },
      success(res){
        wx.hideLoading();
        console.log(res)
        if(res.data.goods.length<=0)
        {
          console.log(res.data.goods.length)
          that.setData({
            goods: [],
            isshow:2,
            isSearch: true
          })
        }
        else
        {
          console.log('这是商品')
          
          that.setData({
            goods: res.data.goods,
            isshow: 1,
            isSearch: false
          })
        }
       
      }
    })
    
  },
  ListTouchStart(e) {
    this.setData({
      ListTouchStart: e.touches[0].pageX
    })
  },

  // ListTouch计算方向
  ListTouchMove(e) {
    this.setData({
      ListTouchDirection: e.touches[0].pageX - this.data.ListTouchStart > 0 ? 'right' : 'left'
    })
  },

  // ListTouch计算滚动
  ListTouchEnd(e) {
    if (this.data.ListTouchDirection == 'left') {
      this.setData({
        modalName: e.currentTarget.dataset.target
      })
    } else {
      this.setData({
        modalName: null
      })
    }
    this.setData({
      ListTouchDirection: null
    })
  },

  dragStart: function (event) {
    var startIndex = event.target.dataset.index
    console.log('获取到的元素为', this.data.goods[startIndex])
    // 初始化页面数据
    var pageInfo = this.data.pageInfo;
    pageInfo.startY = event.touches[0].clientY;
    pageInfo.readyPlaceIndex = startIndex;
    pageInfo.selectedIndex = startIndex;
    pageInfo.scrollY = false;
    pageInfo.startIndex = startIndex;
    var everyOptionCell = this.data.scrollPosition.everyOptionCell;
    var optionsListData = this.data.optionsListData;
    //决绝安卓滑动卡顿 
    //释放内存 
    //决绝安卓抖动
    if (Math.abs(pageInfo.startY - pageInfo.readyPlaceIndex) < everyOptionCell / 15) {
      return
    }
    this.setData({
      'movableViewInfo.y': pageInfo.startY //- (pageInfo.rowHeight / 2)
    })
    // 初始化拖动控件数据
    var movableViewInfo = this.data.movableViewInfo
    movableViewInfo.data = this.data.goods[startIndex]
    //smovableViewInfo.showClass = "inline"
    movableViewInfo.showClass = "none"
    this.setData({
      movableViewInfo: movableViewInfo,
      pageInfo: pageInfo
    })
    
  },

  dragMove: function (event) {
    var optionList = this.data.goods
    var pageInfo = this.data.pageInfo
    // 计算拖拽距离
    var movableViewInfo = this.data.movableViewInfo
    var movedDistance = event.touches[0].clientY - pageInfo.startY
    movableViewInfo.y = pageInfo.startY - (pageInfo.rowHeight / 2) + movedDistance
    console.log('移动的距离为', movedDistance)

    // 修改预计放置位置
    var movedIndex = parseInt(movedDistance / pageInfo.rowHeight)
    var readyPlaceIndex = pageInfo.startIndex + movedIndex
    if (readyPlaceIndex < 0) {
      readyPlaceIndex = 0
    }
    else if (readyPlaceIndex >= optionList.length) {
      readyPlaceIndex = optionList.length - 1
    }

    if (readyPlaceIndex != pageInfo.selectedIndex) {
      var selectedData = optionList[pageInfo.selectedIndex]

      optionList.splice(pageInfo.selectedIndex, 1)
      optionList.splice(readyPlaceIndex, 0, selectedData)
      pageInfo.selectedIndex = readyPlaceIndex
    }
    // 移动movableView
    pageInfo.readyPlaceIndex = readyPlaceIndex
    // console.log('移动到了索引', readyPlaceIndex, '选项为', optionList[readyPlaceIndex])
    
    this.setData({
      movableViewInfo: movableViewInfo,
      goods: optionList,
      pageInfo: pageInfo
    })
  },

  dragEnd: function (event) {
    // 重置页面数据
    var pageInfo = this.data.pageInfo
    pageInfo.readyPlaceIndex = null
    pageInfo.startY = null
    pageInfo.selectedIndex = null
    pageInfo.startIndex = null
    pageInfo.scrollY = true
    // 隐藏movableView
    var movableViewInfo = this.data.movableViewInfo
    movableViewInfo.showClass = 'none'
    console.log(pageInfo)
    this.setData({
      pageInfo: pageInfo,
      movableViewInfo: movableViewInfo
    })
  },
  zhiding:function(e){
    
    var index = e.currentTarget.dataset.index;
    var goods = this.data.goods;
    var oldArr = goods[index];
    for(var i = 0; i<goods.length;i++){
      if(i == index){
        goods.splice(i,1);
        break;
      }
    }
    goods.unshift(oldArr);
    this.setData({
      goods:goods
    })
  },
  formSubmit(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    var search = e.detail.value.search;
    if(!search){
      search = ''
      wx.showLoading({
        title: '加载中...',
        mask: true
      })
      let that = this
      wx.request({
        url: api + 'myOffer',
        data: {
          sid: wx.getStorageSync('sid'),
          search: search
        },
        success(res) {
          wx.hideLoading();
          console.log(res)
          if (res.data.goods.length <= 0) {
            console.log(res.data.goods.length)
            that.setData({
              goods: [],
              isshow: 2,
              isSearch: false
            })
          }
          else {
            console.log('这是商品')
            that.setData({
              goods: res.data.goods,
              isshow: 1,
              isSearch: false
            })
          }

        }
      })
    } else {
      wx.showLoading({
        title: '加载中...',
        mask: true
      })
      let that = this
      wx.request({
        url: api + 'myOffer',
        data: {
          sid: wx.getStorageSync('sid'),
          search: search
        },
        success(res) {
          wx.hideLoading();
          console.log(res)
          if (res.data.goods.length <= 0) {
            console.log(res.data.goods.length)
            that.setData({
              goods: [],
              isshow: 2,
              isSearch: true
            })
          }
          else {
            console.log('这是商品')
            that.setData({
              goods: res.data.goods,
              isshow: 1,
              isSearch: true
            })
          }

        }
      })
    }
    
      
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    let that = this
    let goods = that.data.goods
    let isSearch = that.data.isSearch;
    let newGoods = []
    if(isSearch == true){

    } else {
      for (let i = 0; i < goods.length; i++) {
        newGoods.push({ id: goods[i].id, offer: goods[i].offer })
      }
      console.log(newGoods)
      wx.request({
        url: api + 'setOffer',

        data: {
          sid: wx.getStorageSync('sid'),
          goods: JSON.stringify(newGoods)
        },
        header: {
          'content-type': 'application/x-www-form-urlencoded'
        },
        method: 'post',
        success: function (res) {
          console.log(res)

        }
      })
    }
    
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  /**
   * 用户修改报价
   */
  , editmoney:function(e){
    var self =this;
    let index = e.currentTarget.dataset.index
    let goods = self.data.goods
    self.setData({
      ismodify:true,
      goodsName:goods[index].name,
      goodsindex:index
    })
  },
  // 修改报价数字
  myoffer(e){
   this.setData({
    myoffer:e.detail.value
   })

  },
  /**
   * 用户修改取消
   */
   cacelmoney: function (e) {
    var self = this;
  
      self.setData({
        ismodify: false
      })
 
  }/**
   * 用户修改确定
   */
  ,okmoney: function (e) {
    let that = this
    let goodsindex = that.data.goodsindex;
    let goods = that.data.goods;

    if (!regMoneyTwo.test(that.data.myoffer) || that.data.myoffer <=0)
    {
      wx.showToast({
        title: '您输入的价格有误',
        icon: 'none',
        duration: 500
      })
      return false;
    }
    goods[goodsindex].offer = that.data.myoffer;


    that.setData({
        ismodify: false,
        goods:goods,
        myoffer:0.00
      })
   
  },
  // 用户提交报价
  upoffer(){
    let that = this    
    let goods = that.data.goods
    let newGoods = []
    for(let i = 0;i<goods.length;i++){
      newGoods.push({ id: goods[i].id, offer: goods[i].offer })
    }
    console.log(newGoods)
    wx.request({
      url: api +'setOffer',
      
      data:{
        sid:wx.getStorageSync('sid'),
        goods: JSON.stringify(newGoods)
      },
       header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'post',
      success: function (res) {
        console.log(res)
        if(res.data.code == 1)
        {
          wx.showToast({
            title: "修改成功",
            duration: 1500,
            icon: "success"
          })
        }
        else
        {
          wx.showToast({
            title: res.data.msg,
            duration: 2000,
            icon: "none"
          })
        }
       
      }
    })
  }
})