// pages/myorder/myorder.js
var app = getApp();
var api = app.globalData.api;
var regMoneyTwo = app.globalData.regMoneyTwo;
var util =require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ismodify: false,//点击修改出现的弹窗
    ordertotal:"3869",
    chengben:"2826",
    maoli:"1043",
    current:0,
    youhui:"0",
     isshow:3 //有数据 为 1  没有数据 2  正在加载 3 
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '加载中...',
    })
    let nowTime = util.formatData(new Date());
    let that = this
    wx.request({
      url: api +'todayOrder',
      data:{
        sid:wx.getStorageSync('sid'),
        page:1
      },
      success(res){
        wx.hideLoading()
        console.log(res)
        if (res.data.order.length > 0)
        {
          that.setData({
           isshow:1
          })
        }
        else
        {
          that.setData({
            isshow: 2
          })
        }
        if(res.data.code == 1)
        {
          that.setData({
            nowdate: nowTime,
            json: res.data.order,
            moneyall: res.data.moneyall
          })
        }
        else if(res.data.code == 0)
        {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
            showCancel:false,
            success(res) {
              if (res.confirm) {
                console.log('用户点击确定')
              }
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 查看总订货单
   */
  getallorder: function () {

    wx.navigateTo({
      url: '../allorders/allorders?type=2',
    })
  },
  /**
   * 跳转到餐厅订单
   */
  gotoinfo:function (e){
    let id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../allorder/allorder?id='+id,
    })
  },
  editor:function(e){
    var self = this;
    let orderlist = self.data.json
    let index = e.currentTarget.dataset.index
    self.setData({
      ismodify: true,
      current: e.currentTarget.dataset.index,
      shopName: orderlist[index].name,
      orderid: orderlist[index].id,
    })
  },/**
   * 用户修改取消
   */
   cacelmoney: function (e) {
    var self = this;

    self.setData({
      ismodify: false
    })

  },/**
   * 用户修改确定
   */
   okmoney: function (e) {
    var self = this;
   
    var yj = this.data.youhui;
     if (!regMoneyTwo.test(yj) || yj == 0){
      wx.showToast({
        title: "请输入正确的金额",
        duration: 500,
        icon: "none"
      })
      return false;
    }

     self.setData({
       ismodify: false
     })
    wx.request({
      url: api +'discounts',
      data:{
        orderid: self.data.orderid,
        discounts:yj,
      },
      success(res){
        console.log(res)
        if(res.data.code == 1)
        {
          wx.showModal({
            title: '提示',
            content: '通知成功',
            showCancel:false,
            success(res) {
                console.log('用户点击确定')
            }
          })
        }
        else
        {
          wx.showModal({
            title: '提示',
            content: '你已经发送了通知',
            showCancel: false,
            success(res) {
              console.log('用户点击确定')
            }
          })
        }
      }
    })



  },
  /**
   * 往期订单
   */
   history:function(){
    wx.navigateTo({
      url: '../historysorder/historysorder',
    })
  },
  youhuiInput:function(e){
    this.setData({
      youhui: e.detail.value
    })
   
  }
})