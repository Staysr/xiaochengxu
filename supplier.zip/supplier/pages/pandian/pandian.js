// pages/pandian/pandian.js
var app = getApp();
var api = app.globalData.api;
var utils = require("../../utils/util.js")
var regMoneyTwo = app.globalData.regMoneyTwo//正则
Page({

  /**
   * 页面的初始数据
   */
  data: {
    json:false,
    isshow:3
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    let that = this;
    wx.showLoading({
      title: '加载中...',
      mask:true
    })
    wx.request({
      url: api + 'check_stock',
      data: {
        sid: wx.getStorageSync('sid')
      },
      success(res) {
        console.log(res)
        wx.hideLoading();//取消loadding页面
        that.setData({
          json: res.data.goods
        })
        if (res.data.goods.length >0)
        {
          that.setData({
            isshow: 1
          })
        }  
        else
        {
          that.setData({
            isshow: 2
          })
        }   
     
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this
    let json = that.data.json ? that.data.json:[];
    console.log(that.data)
    let newgoods = wx.getStorageSync('newgoods')

    for (let i = 0; i < newgoods.length; i++) {
      var istrue = false;
      for (let y = 0; y < json.length; y++) {

        if (json[y].name == newgoods[i].name) {
          istrue = true
        }
      }
      if (!istrue) {
        json.push({
          goodsid: newgoods[i].goodsid,
          name: newgoods[i].name,
          stock: 0,
          num: 0,
          lack: 0
        })
      }

    }







    that.setData({
      json
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },
  bindKeyInput(e) {
    var index = e.currentTarget.dataset.index;
    var info = "json[" + index + "].stock";
    var qnum = "json[" + index + "].lack";
    var value = e.detail.value;
    if (!regMoneyTwo.test(value))
    {
   
      value = parseFloat(value).toFixed(2);
      console.log(value)
      if (!value || value =="NaN") {
        value = 0;
      }
    }
    var c = utils.subtr(this.data.json[index].num, value);
    c = c <= 0 ? 0 : c;
    this.setData({
      [info]: value,
      [qnum]: c
    })
    // console.log(this.data.json);
    // console.log(e.currentTarget.dataset.index)
    // console.log(e.detail.value)
  },
  // 添加货品
  addGoods(e) {
    wx.navigateTo({
      url: '../addGoods/addGoods',
    })
  },
  // 生成采购单
  caigou() {



    if (!utils.isJurisdiction("1-3"))
    {
return false;
    }
    let that = this;
    let json = that.data.json;





    let stock = []
    for (let i = 0; i < json.length; i++) {
      stock.push({
        goodsid: json[i].goodsid,
        stock: json[i].stock,
        num: json[i].num
      })
    }
    console.log(JSON.stringify(stock))
    console.log(stock)
    wx.request({
      url: api + 'addPurchase',
      data: {
        uid: wx.getStorageSync('userid'),
        sid: wx.getStorageSync('sid'),
        stock: stock
      },
      success(res) {
        console.log(res)
        // return false;
        wx.redirectTo({
          url: '../cgorder/cgorder',
        })
      }
    })
  }
})