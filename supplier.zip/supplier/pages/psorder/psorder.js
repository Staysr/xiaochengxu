var app = getApp()
var api = app.globalData.api
var util = require('../../utils/util.js')
const LAST_CONNECTED_DEVICE = 'last_connected_device'
const PrinterJobs = require('../../printer/printerjobs')
const printerUtil = require('../../printer/printerutil')

function inArray(arr, key, val) {
  for (let i = 0; i < arr.length; i++) {
    if (arr[i][key] === val) {
      return i
    }
  }
  return -1
}

// ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  const hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function (bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join(',')
}

function str2ab(str) {
  // Convert str to ArrayBuff and write to printer
  let buffer = new ArrayBuffer(str.length)
  let dataView = new DataView(buffer)
  for (let i = 0; i < str.length; i++) {
    dataView.setUint8(i, str.charAt(i).charCodeAt(0))
  }
  return buffer;
}

Page({
  data: {
    devices: [],
    connected: false,
    chs: [],
    showOrHidden: true,
    json: [],
    canting: [],
    showModal: false
    
    // ,isshowtime:true

  },

  onUnload() {
    this.closeBluetoothAdapter()
  },

  preventTouchMove: function () { },
  /**
   * 隐藏模态对话框
   */
  hideModal: function () {
    this.setData({
      showModal: false
    });
  },
  onCancel: function () {
    this.hideModal();
    this.closeBLEConnection();
  },
  /**
   * 对话框确认按钮点击事件
   */
  onConfirm: function () {

    this.hideModal();
    this.writeBLECharacteristicValue();
  },


  showDialogBtn: function () {
    this.setData({
      showModal: true
    })
  },
  gotozd: function (e) {
    console.log(e)
    let isreceive = e.currentTarget.dataset.isreceive;
    var time = this.data.nowTime;//当前时间
    if (isreceive == 1) {
      wx.navigateTo({
        url: '../zhangdan/zhangdan?time=' + time,
      })
      return false;
    }
    //链接打印机打印小票
    if (isreceive == 0) {
      wx.request({
        url: api + 'wx_bluetooth_stamp',
        data: {
          sid: wx.getStorageSync('sid')
        },
        success(res) {
          console.log(res)
          wx.setStorageSync('wx_bluetooth_stamp', res.data.bluetooth)
        }
      })
      this.showDialogBtn();
      this.openBluetoothAdapter();

    }

  },
  openBluetoothAdapter() {
    if (!wx.openBluetoothAdapter) {
      wx.showModal({
        title: '提示',
        content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
      })
      return
    }
    wx.openBluetoothAdapter({
      success: (res) => {
        console.log('openBluetoothAdapter success', res)
        this.startBluetoothDevicesDiscovery()
      },
      fail: (res) => {
        console.log('openBluetoothAdapter fail', res)
        if (res.errCode === 10001) {
          wx.showModal({
            title: '错误',
            content: '未找到蓝牙设备, 请打开蓝牙后重试。',
            showCancel: false
          })
          wx.onBluetoothAdapterStateChange((res) => {
            console.log('onBluetoothAdapterStateChange', res)
            if (res.available) {
              // 取消监听，否则stopBluetoothDevicesDiscovery后仍会继续触发onBluetoothAdapterStateChange，
              // 导致再次调用startBluetoothDevicesDiscovery
              wx.onBluetoothAdapterStateChange(() => { });
              this.startBluetoothDevicesDiscovery()
            }
          })
        }
      }
    })
    wx.onBLEConnectionStateChange((res) => {
      // 该方法回调中可以用于处理连接意外断开等异常情况
      console.log('onBLEConnectionStateChange', `device ${res.deviceId} state has changed, connected: ${res.connected}`)
      this.setData({
        connected: res.connected
      })
      if (!res.connected) {
        wx.showModal({
          title: '错误',
          content: '蓝牙连接已断开',
          showCancel: false
        })
      }
    });
  },
  getBluetoothAdapterState() {
    wx.getBluetoothAdapterState({
      success: (res) => {
        console.log('getBluetoothAdapterState', res)
        if (res.discovering) {
          this.onBluetoothDeviceFound()
        } else if (res.available) {
          this.startBluetoothDevicesDiscovery()
        }
      }
    })
  },
  startBluetoothDevicesDiscovery() {
    if (this._discoveryStarted) {
      return
    }
    this._discoveryStarted = true
    wx.startBluetoothDevicesDiscovery({
      success: (res) => {
        console.log('startBluetoothDevicesDiscovery success', res)
        this.onBluetoothDeviceFound()
      },
      fail: (res) => {
        console.log('startBluetoothDevicesDiscovery fail', res)
      }
    })
  },
  stopBluetoothDevicesDiscovery() {
    wx.stopBluetoothDevicesDiscovery({
      complete: () => {
        console.log('stopBluetoothDevicesDiscovery')
        this._discoveryStarted = false
      }
    })
  },
  onBluetoothDeviceFound() {
    wx.onBluetoothDeviceFound((res) => {
      res.devices.forEach(device => {
        if (!device.name && !device.localName) {
          return
        }
        const foundDevices = this.data.devices;
        console.log(foundDevices);
        console.log(device.deviceId)
        const idx = inArray(foundDevices, 'deviceId', device.deviceId)
        const data = {}
        if (idx === -1) {
          data[`devices[${foundDevices.length}]`] = device
        } else {
          data[`devices[${idx}]`] = device
        }
        this.setData(data)
      })
    })
  },
  createBLEConnection(e) {
    const ds = e.currentTarget.dataset
    const deviceId = ds.deviceId
    const name = ds.name
    this._createBLEConnection(deviceId, name)

  },
  _createBLEConnection(deviceId, name) {
    wx.showLoading()
    wx.createBLEConnection({
      deviceId,
      success: () => {
        console.log('createBLEConnection success');
        this.setData({
          connected: true,
          name,
          deviceId,
        })
        this.getBLEDeviceServices(deviceId)
        wx.setStorage({
          key: LAST_CONNECTED_DEVICE,
          data: name + ':' + deviceId
        })
      },
      complete() {
        wx.hideLoading()
      },
      fail: (res) => {
        console.log('createBLEConnection fail', res)
      }
    })
    this.stopBluetoothDevicesDiscovery()
  },
  closeBLEConnection() {

    wx.closeBLEConnection({
      deviceId: this.data.deviceId
    })
    this.setData({
      connected: false,
      chs: [],
      canWrite: false,
    })
  },
  onShow: function () {
    let that = this;
    // console.log(that.data.imgUrls)

  },
  getBLEDeviceServices(deviceId) {
    wx.getBLEDeviceServices({
      deviceId,
      success: (res) => {
        console.log('getBLEDeviceServices', res)
        for (let i = 0; i < res.services.length; i++) {
          if (res.services[i].isPrimary) {
            this.getBLEDeviceCharacteristics(deviceId, res.services[i].uuid)
            return
          }
        }
      }
    })
  },
  getBLEDeviceCharacteristics(deviceId, serviceId) {
    wx.getBLEDeviceCharacteristics({
      deviceId,
      serviceId,
      success: (res) => {
        console.log('getBLEDeviceCharacteristics success', res.characteristics)
        // 这里会存在特征值是支持write，写入成功但是没有任何反应的情况
        // 只能一个个去试
        for (let i = 0; i < res.characteristics.length; i++) {
          const item = res.characteristics[i]
          if (item.properties.write) {
            this.setData({
              canWrite: true
            })
            this._deviceId = deviceId
            this._serviceId = serviceId
            this._characteristicId = item.uuid
            break;
          }
        }
      },
      fail(res) {
        console.error('getBLEDeviceCharacteristics', res)
      }
    })
  },
  writeBLECharacteristicValue() {
    var newDate = util.formatData3(new Date());//今日时间
    var newDate2 = util.formatData(new Date());//今日时间
    var wx_bluetooth_stamp = wx.getStorageSync('wx_bluetooth_stamp')
    console.log(wx_bluetooth_stamp[0].priceall)
    console.log(wx_bluetooth_stamp)
    var printerJobs = new PrinterJobs();
    for (var i = 0; i < wx_bluetooth_stamp.length; i++) {
      var info = wx_bluetooth_stamp[i].info
      printerJobs
        .print(newDate)
        .print(printerUtil.fillLine())
        .setAlign('ct')
        .setSize(2, 2)
        .print(wx_bluetooth_stamp[i].name)
        .setSize(1, 1)
        .print("餐厅id:" + wx_bluetooth_stamp[i].rid)
        .setSize(1, 1)
        .print("配送状态:" + wx_bluetooth_stamp[i].isreceive)
        .setAlign('lt')
        .setSize(1, 1)  
        .print("下单时间:" + newDate2 + wx_bluetooth_stamp[i].time)
        .print('订单id: ' + wx_bluetooth_stamp[i].orderid)
        .print('手机号: ' + wx_bluetooth_stamp[i].phone)
        .print('地址: ' + wx_bluetooth_stamp[i].address)
        .print('货品种类: ' + wx_bluetooth_stamp[i].num)
        .print(printerUtil.fillAround('其他'))
        .print();
      console.log(info)
      for (let e = 0; e < info.length; e++) {
        console.log(info[e])
        printerJobs.print("货品名称: " + info[e].name + "  单价:" + info[e].price + "元")
          .print("配送量: " + info[e].realcount+"(斤)"  + "  总价:" + info[e].priceall + "元")
          .print();
      }
      printerJobs.print(printerUtil.fillLine())
        .setAlign('rt')
        .print('总价:' + wx_bluetooth_stamp[0].money +"元")
        .setAlign('lt')
        .print(printerUtil.fillLine())
        .println()
        .println()
    }
    let buffer = printerJobs.buffer();
    console.log('ArrayBuffer', 'length: ' + buffer.byteLength, ' hex: ' + ab2hex(buffer));
    // 1.并行调用多次会存在写失败的可能性
    // 2.建议每次写入不超过20字节
    // 分包处理，延时调用
    const maxChunk = 20;
    const delay = 20;
    for (let i = 0, j = 0, length = buffer.byteLength; i < length; i += maxChunk, j++) {
      let subPackage = buffer.slice(i, i + maxChunk <= length ? (i + maxChunk) : length);
      setTimeout(this._writeBLECharacteristicValue, j * delay, subPackage);
    }
  },
  _writeBLECharacteristicValue(buffer) {
    wx.writeBLECharacteristicValue({
      deviceId: this._deviceId,
      serviceId: this._serviceId,
      characteristicId: this._characteristicId,
      value: buffer,
      success(res) {
        console.log('writeBLECharacteristicValue success', res)
      },
      fail(res) {
        console.log('writeBLECharacteristicValue fail', res)
      }
    })
  },
  closeBluetoothAdapter() {
    wx.closeBluetoothAdapter()
    this._discoveryStarted = false
  },
  createBLEConnectionWithDeviceId(e) {
    // 小程序在之前已有搜索过某个蓝牙设备，并成功建立连接，可直接传入之前搜索获取的 deviceId 直接尝试连接该设备
    const device = this.data.lastDevice
    if (!device) {
      return
    }
    const index = device.indexOf(':');
    const name = device.substring(0, index);
    const deviceId = device.substring(index + 1, device.length);
    console.log('createBLEConnectionWithDeviceId', name + ':' + deviceId)
    wx.openBluetoothAdapter({
      success: (res) => {
        console.log('openBluetoothAdapter success', res)
        this._createBLEConnection(deviceId, name)
      },
      fail: (res) => {
        console.log('openBluetoothAdapter fail', res)
        if (res.errCode === 10001) {
          wx.showModal({
            title: '错误',
            content: '未找到蓝牙设备, 请打开蓝牙后重试。',
            showCancel: false
          })
          wx.onBluetoothAdapterStateChange((res) => {
            console.log('onBluetoothAdapterStateChange', res)
            if (res.available) {
              // 取消监听
              wx.onBluetoothAdapterStateChange(() => { });
              this._createBLEConnection(deviceId, name)
            }
          })
        }
      }
    })
  },
  gotoshop: function (e) {
    let rid = e.currentTarget.dataset.rid

    wx.navigateTo({
      url: '../storedetails/storedetails?rid=' + rid,
    })
  },
  gotoinfo: function (e) {
    let rid = e.currentTarget.dataset.rid;
    var isreceive = e.currentTarget.dataset.isreceive; //0 是未完成 1是已经完成
    var time = e.currentTarget.dataset.time; //订单时间
    console.log("-".repeat(20))
    console.log(rid)
    console.log(isreceive)
    console.log(time)
    console.log("-".repeat(20))

    wx.navigateTo({
      url: '../psorderinfo/psorderinfo?rid=' + rid + "&isreceive=" + isreceive + "&time=" + time,
    })


  },

  // 选择日期表：：：：：：：：：：：：：：：：：：：
  bindDateChange: function (e) {
    // this.getDeliver(nowTime); //获取当日详情
    let nowTime = util.formatData(new Date());
    console.log(e.detail.value);
    var user_nowtime = e.detail.value;
    user_nowtime = user_nowtime.split('-');
    console.log(user_nowtime);
    user_nowtime = user_nowtime[0] + "年" + user_nowtime[1] + "月" + user_nowtime[2] + "日";
    this.getDeliver(user_nowtime); //获取当日详情
    // var isshowtime = true;
    // if (nowTime != user_nowtime)
    // {
    //   isshowtime=false;
    // }
    this.setData({
      nowTime: user_nowtime,
      wx_nowTime: e.detail.value
      // , isshowtime: isshowtime
    })
    

  
   






  }
  // 选择日期表：：：：：：：：：：：：：：：：：：：
  ,
  onLoad(options) {
    const lastDevice = wx.getStorageSync(LAST_CONNECTED_DEVICE);
    this.setData({
      lastDevice: lastDevice
    })

    let nowTime = util.formatData(new Date());
    this.getDeliver(nowTime); //获取当日详情
    this.setData({
      nowTime: nowTime,
      endtime: util.formatData2(new Date())
    })
  }
  // 获取订单详情：：：：：：：：：：：：：：
  ,
  getDeliver: function (time) {
    let that = this;
    time = time.toString();
    console.log(time)
    wx.request({
      url: api + 'getDeliver',
      data: {
        sid: wx.getStorageSync('sid'),
        time: time
      },
      success(res) {
        console.log(res)


        var data_list = res.data.deliver;
        var wx_list_code = 1;
        for (let i = 0; i < data_list.length; i++) {
          if (data_list[i].isreceive != 1) {
            wx_list_code =0
          }
        }
        that.setData({
          json: res.data.deliver,
          data_isreceive: wx_list_code
        })



      }
    })
  }
})