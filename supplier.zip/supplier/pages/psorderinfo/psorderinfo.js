// pages/psorderinfo/psorderinfo.js
var app = getApp()
var api = app.globalData.api
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show:true,
    json: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    var isreceive = options.isreceive;//是否已经完成
    var rid = options.rid;//是否已经完成
    var time = options.time;//是否已经完成
    console.log("-".repeat(20))
    console.log(rid)
    console.log(isreceive)
    console.log(time)
    console.log("-".repeat(20))
    that.setData({
      isreceive: isreceive,
      rid: rid,
      time: time
    })
    wx.showLoading({
      title: '加载中...',
      mask:true
    })
    wx.request({
      url: api + 'deliverInfo',
      data: {
        sid: wx.getStorageSync('sid'),
        rid: options.rid, time: time
      },
      success(res) {
        wx.hideLoading()
        that.setData({
          json: res.data.deliverinfo,
          money :res.data.money,
          state:res.data.state
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  gotoinfo:function(){
    // this.setData({
    //   show:false
    // })
var that =this;
    var isreceive = that.data.isreceive;//0未完成 1完成
    var rid = that.data.rid;//订单id
    var time = that.data.time;//0未完成 1完成
    if (isreceive == 1)
    {

      wx.navigateTo({
        url: '../shouhuodan/shouhuodan?rid=' + rid +"&time="+time
      })
    }
    else
    {
      wx.showModal({
        title: '提示',
        content: '当前订单还未完成',
        cancelText:"返回列表",
        confirmText:"确定",
        success(res) {
          if (res.confirm) {
            console.log('用户点击确定')
          } else if (res.cancel) {
            console.log('用户点击取消')
          }
        }
      })
    }
  }
})