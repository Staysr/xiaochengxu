// pages/register/register.js
var app = getApp()
var statiregist = app.globalData.statiregist;
function trim(str) {
  console.log(str)
  str?str:""
  return str.replace(/(^\s*)|(\s*$)/g, "");
}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isFrist: true,
    verifyCodeTime: "发送验证码",
    buttonDisable: false,
    userphone: "",
    classid:"",
    routeid:"",
    rangkey: 0,
    gray_show: false,
    shopclass: [],
    city_index:0,
    areaArr:[]


  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log("_".repeat(20))
    console.log(options)
    console.log("_".repeat(20))
    this.get_class();
    this.get_level();


  },
  //获取商品种类
  get_class: function() {
    var that = this;
    wx.request({
      url: statiregist + 'get_class', // 仅为示例，并非真实的接口地址
      data: {},
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        var list_class = res.data.list;
        console.log(res)
        for (let i = 0; i < list_class.length; i++) {
          list_class[i].isselect = false;
        }
        that.setData({
          shopclass: list_class
        })
      }
    })

  },

  //获取接单能力
  get_level: function() {
    var that = this;
    wx.request({
      url: statiregist + 'get_level', // 仅为示例，并非真实的接口地址
      data: {},
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        console.log(res)
        var listArr = res.data.list
        var obj = {
          id: "0",
          name: "接单能力",
          number: "0"
        }
        listArr.unshift(obj)
        that.setData({
          listArr: listArr
        })
      }
    })

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

    }

    ,
  bindphone: function(e) {
      this.setData({
        userphone: e.detail.value
      })
    }

    ,
  sendYzm: function() {
    console.log('发送验证码');
    var that = this;
    var buttonDisable = that.data.buttonDisable; //是否开始重新发
    var userphone = that.data.userphone; //用户输入的手机号
    if (buttonDisable) {
      return false;
    }
    console.log(userphone)
    if (userphone.length < 11 || userphone[0] != 1) {
      wx.showToast({
        title: '手机号码错误',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    console.log('验证吗倒计时');

    wx.request({
      url: statiregist + 'sendcode', // 仅为示例，并非真实的接口地址
      method: "post",
      data: {
        phone: userphone,
        type:2
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success(res) {
        console.log(res)
        if (res.data.Code == 1) {
          // that.setData({
          //   yanzhengma: res.data.registercode
          // })
          wx.showToast({
            title: res.data.msg,
            mask: true,
            icon: "success",
            duration: 1000
          })
          var obj = {
            userphone: userphone,
            registercode: res.data.registercode
          }
          sendcode()
          wx.setStorageSync("registercode", obj)
        } else {
          wx.showToast({
            title: res.data.msg,
            mask: true,
            icon: "none",
            duration: 1500
          })
        }

      }
    })



    function sendcode(){
      var c = 60;
      that.setData({
        verifyCodeTime: '重新发送(' + c + 's)',
        buttonDisable: true
      })
      var intervalId = setInterval(function () {
        c = c - 1;
        that.setData({
          verifyCodeTime: '重新发送(' + c + 's)',
          buttonDisable: true
        })
        if (c == 0) {
          clearInterval(intervalId);
          that.setData({
            verifyCodeTime: '获取验证码',
            buttonDisable: false
          })
        }
      }, 1000)
    }

    



    }
    // 注册信息  
    ,
  registerInfor: function(e) {
    var that =this;
    var name = e.detail.value.name;//供货商名字
    var classid = this.data.classid;

    var contactname = e.detail.value.contactname;
    var phone = e.detail.value.phone;
    var password = e.detail.value.password;
    var repassword = e.detail.value.repassword;
    var listArr = this.data.listArr;
    var level = listArr[that.data.rangkey]["id"] ;//接单能力
    var yzmobj = wx.getStorageSync("registercode");
    var useryzm = e.detail.value.useryzm; //验证码
  
    if (trim(name).length <= 0) {
      wx.showToast({
        title: '请填写供货商名字',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (trim(classid).length <= 0) {
      wx.showToast({
        title: '商品种类至少选择一个',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    var routeid="";
    var areaArr = this.data.areaArr;
    for (let i = 0; i < areaArr.length;i++)
    {
      routeid += areaArr[i]["routeids"] + ',';
    }
    if (routeid != "") {
      routeid = routeid.substring(0, routeid.length - 1)
    }
    else
    {
      wx.showToast({
        title: '请选择配送覆盖区县',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    console.log(name)
    console.log(classid)
    console.log(routeid)
    console.log(contactname)
    console.log(phone)
    console.log(password)
    console.log(repassword)
    console.log(level)
    console.log(yzmobj)
    console.log(useryzm)
   
  
    if (trim(contactname).length <= 0) {
      wx.showToast({
        title: '请填写联系人',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    
    if (phone.length < 11 || phone[0] != 1) {
      wx.showToast({
        title: '手机号码错误',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }

    if (yzmobj.userphone != phone || yzmobj.registercode != useryzm) {
      wx.showToast({
        title: '验证码不正确',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }

    if (password.length < 6) {
      wx.showToast({
        title: '密码长度为6~12位',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (repassword.length < 6) {
      wx.showToast({
        title: '确认密码长度为6~12位',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (password != repassword) {
      wx.showToast({
        title: '两次密码输入不一致',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (level==0) {
      wx.showToast({
        title: '请选择接单能力',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }

wx.showLoading({
  title: '注册中...',
  mask:true
})

console.log()
    wx.login({
      success(res) {
        if (res.code) {
          wx.request({
            url: statiregist + 'supplier_register', // 仅为示例，并非真实的接口地址
            method:"post",
            data: {
              name: name,
              classid: classid,
              routeid: routeid,
              contactname: contactname,
              phone: phone,
              password: password,
              repassword: repassword, 
              captcha: useryzm,
              "level": 1
            },
            header: {
              'content-type': 'application/x-www-form-urlencoded' // 默认值
            },
            success(res) {
                  console.log(res)
                  wx.hideLoading()
                  if (res.data.Code == 1) {
                    wx.removeStorageSync("registercode")
                    wx.showModal({
                      title: '提示',
                      content: '注册成功',
                      confirmText: "去登陆",
                      showCancel: false,
                      success(res) {
                        if (res.confirm) {
                          wx.reLaunch({
                            url: '../authorpage/authorpage'
                          })
                        }
                      }
                    })
                  } else {
                    wx.showModal({
                      title: '注册失败',
                      content: res.data.msg,
                      confirmText:"确定" ,
                      showCancel: false,
                      success(res) {

                      }
                    })
                  }
            }
          })
        }}
    })
    

  },


  bindPickerChange: function(e) {
      console.log('picker发送选择改变，携带值为', e.detail.value)
      this.setData({
        rangkey: e.detail.value
      })
    }

    // 供货商商品种类多选
    ,
  selectShop: function() {
      this.setData({
        gray_show: true
      })
    }

    // 选择商品种类
    ,
  selectShopclose: function() {

      var shopclass = this.data.shopclass; //当前的所有商品类别

      var shopString = "";
      var classid = "";
      for (let i = 0; i < shopclass.length; i++) {
        if (shopclass[i].isselect) {
          shopString += shopclass[i].name + ',';
          classid += shopclass[i].id+',';
        }
      }
      if (shopString != "") {

        shopString = shopString.substring(0, shopString.length - 1)
        classid = classid.substring(0, classid.length - 1)
      }
      console.log(shopString)
    console.log(classid)

      this.setData({
        gray_show: false,
        shopString: shopString,
        classid: classid
      })


    }

    ,
  selectnow: function(e) {
      var that = this;
      var shopclass = this.data.shopclass; //当前的所有商品类别
      var isselect = e.currentTarget.dataset.isselect; //当前选择的状态
      var sindex = e.currentTarget.dataset.sindex; //当前索引
      shopclass[sindex].isselect = !shopclass[sindex].isselect; //取反;
      this.setData({
        shopclass: shopclass
      })
    }



    // 点击注册
    ,
  registerInfor1: function(e) {

    console.log(e);
    var shopname = e.detail.value.shopname; //供货商名称
    var username = e.detail.value.username; //联系人
    var userphone = e.detail.value.userphone; //手机号码
    var useryzm = e.detail.value.useryzm; //验证码

    var shopString = this.data.shopString; //商品种类
    // var useryzm = this.data.shopString;//省市区县
    var rangkey = this.data.rangkey; //接单能力


    if (!shopname || shopname.length <= 0) {
      wx.showToast({
        title: '请填写供货商名称',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }

    if (!shopString || shopname.length <= 0) {
      wx.showToast({
        title: '请填写商品种类',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (!username || username.length <= 0) {
      wx.showToast({
        title: '请填写联系人',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    if (userphone.length < 11 || userphone[0] != 1) {
      wx.showToast({
        title: '手机号码错误',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }

    if (rangkey == 0) {
      wx.showToast({
        title: '请选择接单能力',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
  }





  // 选择省市区
  ,selectCity: function () {
    var city_isShow = this.data.city_isShow;
    var that = this
    this.setData({
      provinceid: ""
    })
    wx.showLoading({
      title: '加载中...',
      mask: true
    })
    wx.request({
      url: statiregist + 'get_province', // 仅为示例，并非真实的接口地址
      data: {},
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading()
        console.log(res)
        that.setData({
          city_isShow: true
        })
        if (res.data.Code == 1) {
          that.setData({
            list_s: res.data.list
          })
        }
      }
    })



  }
  // 选择市
  ,
  select_shi: function (e) {

    var that = this;
    this.setData({
      cityid: ""
    })
    var provinceid = e.currentTarget.dataset.provinceid; //市id
    var provincename = e.currentTarget.dataset.provincename; //市名字
    this.setData({
      provinceid: provinceid,
      provincename: provincename
    })
    wx.showLoading({
      title: '加载中...',
      mask: true
    })
    wx.request({
      url: statiregist + 'province_city', // 仅为示例，并非真实的接口地址
      data: {
        provinceid: provinceid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading()
        console.log(res)
        if (res.data.Code == 1) {
          that.setData({
            list_shi: res.data.list,
            city_index: 1
          })
        }
      }
    })

  }
  // 选择区
  ,
  select_qu: function (e) {

    var that = this;
    this.setData({
      routeids: ""
    })
    var cityid = e.currentTarget.dataset.cityid; //市id
    var cityname = e.currentTarget.dataset.cityname; //市名字
    this.setData({
      cityid: cityid,
      cityname: cityname
    })
    wx.showLoading({
      title: '加载中...',
      mask: true
    })
    wx.request({
      url: statiregist + 'city_route', // 仅为示例，并非真实的接口地址
      data: {
        cityid: cityid
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        wx.hideLoading()
        console.log(res)
        if (res.data.Code == 1) {
          that.setData({
            list_qu: res.data.list,
            city_index: 2
          })
        }
      }
    })

  }
  // 选择美食街
  ,
  select_end: function (e) {
    var that = this;
    var routeids = e.currentTarget.dataset.routeids; //美食街id
    var routename = e.currentTarget.dataset.routename; //美食街id
    this.setData({
      routeids: routeids,
      routename: routename
    })

  }
  // 返回上一页
  ,
  btncityindex: function (e) {
    var that = this;
    var city_index = e.currentTarget.dataset.city_index; //美食街id
    var shopname = e.currentTarget.dataset.shopname; //美食街id
    this.setData({
      city_index: city_index,
      [shopname]: ""
    })
  }

  // 点击确定选择完毕
  , btn_okcity:function(){
    var that =this;
    var areaArr = this.data.areaArr;//所有的列表
    var provinceid = that.data.provinceid;//省去id
    var cityid = that.data.cityid;//城市id
    var routeids = that.data.routeids;//区域id
   
    var routename = that.data.routename;//区域name
    if (routeids == "") {
      wx.showToast({
        title: '请选择区域',
        icon: 'none',
        duration: 1000,
        mask: true
      })
      return false;
    }
    var obj = {
      routeids: routeids,
      routename: routename
    }
      for (let i = 0; i < areaArr.length;i++)
      {
        if (areaArr[i]["routeids"] == routeids)
        {
          this.setData({
            city_isShow: false,
            city_index: 0,
          })
          return false;
        
        }
      }
    areaArr.push(obj)
    console.log(areaArr)
    this.setData({
      areaArr: areaArr, 
      city_isShow: false,
      city_index: 0,
    })
 
  }

  ,
  colseCity: function () {

    console.log('关闭选择省市区')
    this.setData({
      city_isShow: false,
      city_index: 0
    })

  }

  ,delect:function(e){
    var that =this;
    var sindex = e.currentTarget.dataset.sindex;
    var areaArr = this.data.areaArr;//当前所有数组
    areaArr.splice(sindex, 1);
    this.setData({
      areaArr: areaArr
    })
  }
})