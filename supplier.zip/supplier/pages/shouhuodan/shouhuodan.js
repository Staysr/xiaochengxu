// pages/psorderinfo/psorderinfo.js
var app = getApp()
var api = app.globalData.api
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    var sid = wx.getStorageSync("sid");//sid
    console.log(sid)
    var rid = options.rid;//是否已经完成
    var time = options.time;//是否已经完成
    console.log("-".repeat(20))
    console.log(rid)
    console.log(time)
    console.log("-".repeat(20))
  this.setData({
     rid: options.rid,
    time: time
  })
    wx.request({
      url: api + 'goodsInfo',
      data: {
        sid: sid,
        rid: rid,
        time: time
      },
      success(res) {
       console.log(res)
       if(res.data.code == 1)
       {
         that.setData({
           json:res.data.goodsinfo,
           money: res.data.money,
           state: res.data.state,
           type: res.data.type
         })
       }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
  , gotoinfo:function(e){
    var that =this;
    var type = e.currentTarget.dataset.type;
    console.log(type)
    if (type == 1)
    {
      return false;
    }
    var sid = wx.getStorageSync("sid");//sid
    var rid = this.data.rid;//rid
    var time = this.data.time;//时间
    wx.showModal({
      title: '提示',
      content: '您是否要确认收款',
      confirmText:"确认收款",
      success(res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.showLoading({
            title: '收款中...',
            mask:true
          })
          wx.request({
            url: api + 'affirmMoney',
            data: {
              sid: sid,
              rid: rid,
              time: time
            },
            success(res) {
              wx.hideLoading();
              that.setData({
                type:1
              })
              wx.showModal({
                title: '提示',
                content: res.data.msg, showCancel:false,
                success(res) {
                  if (res.confirm) {
                    console.log('用户点击确定')
                  }
                }
              })
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })




  }
})