// pages/signIn/signIn.js
var app = getApp();
var api = app.globalData.api;
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    let that = this
    // wx.clearStorageSync();
    wx.request({
      url: api + 'system',
      data: {},
      success(res) {
        that.setData({
          sphone: res.data.system.sphone
        })
       console.log(res)
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {
  },
  bindgetuserinfo: function(e) {
    var self = this;
    wx.showLoading({
      title: '登录中...',
    })
    wx.login({
      success: function (res1) {
        if (res1.code) {
          var userphone = self.data.userphone;
          var password = self.data.password;
          wx.request({
            url: api + 'sphoneLogin',
            data: {
              phone: userphone,
              pwd: password,
              code: res1.code
            },
            success(res) {
              console.log(res)
              wx.hideLoading()
              wx.clearStorage();
              if (res.data.code == 2) {
                wx.showModal({
                  title: '账号被封闭',
                  content: res.data.msg,
                  showCancel: false
                })
                wx.setStorageSync('wx_key_code',"1")
              }
              if (res.data.code == 0) {
                wx.setStorageSync('wx_key_code',"1")
                wx.showModal({
                  title: '提示！',
                  content: res.data.msg,
                  showCancel: false
                })
              } else if (res.data.code == 1) {
                wx.setStorage({
                  key: 'sid',
                  data: res.data.user.sid,
                })
                wx.setStorage({
                  key: 'userid',
                  data: res.data.user.id,
                })
                wx.setStorage({
                  key: 'wx_key_code',
                  data:"2",
                })
                wx.showToast({
                  title: '登陆成功',
                  duration: 1500
                })
                setTimeout(function () {
                  wx.reLaunch({
                    url: '../index/index'
                  })
                }, 1500)
           
              }
            }
          })
        } else {
          console.log('登录失败！' + res.errMsg)
        }
      }
    });


 
  },

  getphone: function(e) {
    var self = this;
    self.setData({
      userphone: e.detail.value
    })
  },
  getpassword: function(e) {
    var self = this;
    self.setData({
      password: e.detail.value
    })
  },

  marck: function (e) {
    var sphone = e.currentTarget.dataset.sphone;//电话号码
    wx.makePhoneCall({
      phoneNumber: sphone // 仅为示例，并非真实的电话号码
    })
  }
  , zhucenav: function () {
    wx.navigateTo({
      url: '../register/register',
    })
  }
})