// pages/zhangdan/zhangdan.js
var app = getApp()
var api = app.globalData.api
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
      json:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this
    let nowTime = util.formatData(new Date());
    var time =options.time;//当前时间
    var sid = wx.getStorageSync('sid');
    this.setData({
      time: time
    })
    wx.request({
      url: api + 'todayBill',
      data: {
        sid: sid,
        time: time
      },
      success(res) {
        console.log(res)
        that.setData({
          json: res.data.list,
          nowTime,
          heji: res.data.heji,
          xxpay: res.data.xxpay,
          xspay: res.data.xspay,
          weixin: res.data.weixin,
          fuwu: res.data.fuwu,
          money: res.data.money

        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  gotoinfo:function(e){
    let rid = e.currentTarget.dataset.rid
    wx.navigateTo({
      url: '../storedetails/storedetails?rid='+rid,
    })
  }
})