function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}
function formatData(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  if(month <10)
  {
    month = "0" + month;
  }
  var day = date.getDate()
  if (day < 10) {
    day = "0" + day;
  }
  return [year+'年'+ month+'月'+day+'日']
}

function formatData3(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var hour = date.getHours()
  var minter =date.getMinutes()
  var second = date.getSeconds()
  if (month < 10) {
    month = "0" + month;
  }
  var day = date.getDate()
  if (day < 10) {
    day = "0" + day;
  }
  return [year + '年' + month + '月' + day + '日' + hour + ":" + minter + ":" + second ]
}
function formatData2(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()
  return year + '-' + month + '-' + day
}

function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}



function checkStringEmpty(data){
  if(null == data || "" == data){
    return false;
  }
  return true;
}


// ----------------------
function subtr(arg1, arg2) {
  var r1, r2, m, n;
  try {
    r1 = arg1.toString().split(".")[1].length
  } catch (e) {
    r1 = 0
  }
  try {
    r2 = arg2.toString().split(".")[1].length
  } catch (e) {
    r2 = 0
  }
  m = Math.pow(10, Math.max(r1, r2));
  n = (r1 >= r2) ? r1 : r2;
  return ((arg1 * m - arg2 * m) / m).toFixed(n);
}




// 判断 是否拥有权限
function isJurisdiction(power){
  var userpower = wx.getStorageSync("power");
  if (userpower.indexOf(power) < 0) {
    wx.showToast({
      title: "暂无权限",
      icon: "none",
      duration: 1500,
      mask: true
    })
    return false;
  }
  return true;
}

module.exports = {
  formatTime: formatTime,
  formatData: formatData,
  formatData2: formatData2,
  formatData3: formatData3,
  subtr: subtr,//去掉小数
isJurisdiction: isJurisdiction//判断权限
}