// var app = getApp()
// var api = app.globalData.api
// var util = require('../../utils/util.js')
const LAST_CONNECTED_DEVICE = 'last_connected_device'
const PrinterJobs = require('../printer/printerjobs')
const printerUtil = require('../printer/printerutil')

var devices= [];
var devices1=[];
var  connected= false;
var  chs= [];
var  showOrHidden= true;
var  json= [];
var  showModal=false;
var  ismodify= false; //点击修改出现的弹窗
var  _discoveryStarted;


  function inArray(arr, key, val) {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i][key] === val) {
        return i
      }
    }
    return -1
  }

function hexToStr(str) {
  var val = "";
  var arr = str.split(",");
  for (var i = 0; i < arr.length; i++) {
    arr[i] = arr[i].replace("\\u", "")
    val += String.fromCharCode(parseInt(arr[i], 16).toString(10));
  }

  return val.trim();

}
//ArrayBuffer转16进度字符串示例
function ab2hex(buffer) {
  const hexArr = Array.prototype.map.call(
    new Uint8Array(buffer),
    function(bit) {
      return ('00' + bit.toString(16)).slice(-2)
    }
  )
  return hexArr.join(',')
}

function str2ab(str) {
  // Convert str to ArrayBuff and write to printer
  let buffer = new ArrayBuffer(str.length)
  let dataView = new DataView(buffer)
  for (let i = 0; i < str.length; i++) {
    dataView.setUint8(i, str.charAt(i).charCodeAt(0))
  }
  return buffer;
}
// Page({
//   data: {

//   },


//   /**
//    * 隐藏模态对话框
//    */
//   hideModal: function() {
//     this.setData({
//       showModal: false
//     });
//   },
//   //用户点击取消事件
//   onCancel: function() {
//     this.hideModal();
//     this.closeBLEConnection();
//   },
//   /**
//    * 对话框确认按钮点击事件
//    */
//   onConfirm: function() {
//     //bindtap = "createBLEConnection" 

//     this.hideModal();
//     this.createBLEConnection();
//   },
//   //初始化模态框
//   showDialogBtn: function() {
//     this.setData({
//       showModal: true
//     })
//   },

//   //初始化打印模态框
//   cacelmoney: function(e) {
//     var self = this;

//     self.setData({
//       ismodify: false
//     })

//   },

//   okmoney: function(e) {
//     var self = this;
//     self.setData({
//       ismodify: false
//     })
//     // if (wx.getStorageSync('closeBLEConnection') == 1) {
//     //this.closeBLEConnection //断开蓝牙链接
//     // } else {
//     //this.closeBLEConnection //断开蓝牙链接
//     //this.createBLEConnection();
//     this.writeBLECharacteristicValue();
//     // }
//   },
//   editor: function() {
//     var self = this;
//     self.setData({
//       ismodify: true,
//     })
//   },
//   /**
//    * 对话框确认按钮点击事件
//    */
//   //初始化主页加载
//   onLoad(options) {
//     // if (wx.getStorageSync('closeBLEConnection') == 2) {
//     //   return false
//     // } else {
//     // this.showDialogBtn();//模态框
//     // this.openBluetoothAdapter();//吊起蓝牙的
//     // let that = this
//     // let nowTime = util.formatData(new Date());
//     console.log(options.nowindex)
//     console.log(options.shoplist)


//     var shoplist = JSON.parse(options.shoplist); //
//     var nowindex = JSON.parse(options.nowindex);
//     this.getShopfj(options.name, options.goodsid); //获取当前id
//     // }
//     this.setData({
//       nowindex: nowindex,
//       shoplist: shoplist
//     })


//   },
//   // 获取当前分拣id的东西
//   getShopfj: function(name, goodsid) {
//     var that = this;
//     wx.request({
//       url: api + 'gsortingInfo',
//       data: {
//         sid: wx.getStorageSync('sid'),
//         goodsid: goodsid
//       },
//       success(res) {
//         console.log(res)
//         that.setData({
//           json: res.data.sorting,
//           name: name,
//           goodsid: goodsid
//         })
//       }
//     })
//   },
//   // 初始化蓝牙
//   openBluetoothAdapter() {
//     if (!wx.openBluetoothAdapter) {
//       wx.showModal({
//         title: '提示',
//         content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
//       })
//       return
//     }
//     wx.openBluetoothAdapter({
//       success: (res) => {
//         //console.log('openBluetoothAdapter success', res)
//         this.startBluetoothDevicesDiscovery()
//       },
//       fail: (res) => {
//         if (res.errCode === 10001) {
//           wx.showModal({
//             title: '错误',
//             content: '未找到蓝牙设备, 请打开蓝牙后重试。',
//             showCancel: false
//           })
//           wx.onBluetoothAdapterStateChange(function(res) {
//             //console.log('onBluetoothAdapterStateChange', res)
//             if (res.available) {
//               this.startBluetoothDevicesDiscovery()
//             }
//           })
//         }
//       }
//     })
//   },
//   // 获取本机蓝牙配置状态
//   getBluetoothAdapterState() {
//     wx.getBluetoothAdapterState({
//       success: (res) => {
//         console.log('getBluetoothAdapterState', res)
//         if (res.discovering) {
//           this.onBluetoothDeviceFound()
//         } else if (res.available) {
//           this.startBluetoothDevicesDiscovery()
//         }
//       }
//     })
//   },
//   //开始搜索附近蓝牙
//   startBluetoothDevicesDiscovery() {
//     if (this._discoveryStarted) {
//       return
//     }
//     this._discoveryStarted = true
//     wx.startBluetoothDevicesDiscovery({
//       allowDuplicatesKey: true,
//       success: (res) => {
//         console.log('startBluetoothDevicesDiscovery success', res)
//         this.onBluetoothDeviceFound()
//       },
//       //开始搜索附近蓝牙 抛出异常
//       fail: (res) => {
//         console.log('startBluetoothDevicesDiscovery fail', res)
//       }
//     })
//   },
//   //停止搜索蓝牙
//   stopBluetoothDevicesDiscovery() {
//     wx.stopBluetoothDevicesDiscovery()
//   },

//   //监听新设备链接
//   onBluetoothDeviceFound() {
//     wx.onBluetoothDeviceFound((res) => {
//       res.devices.forEach(device => {
//         if (!device.name && !device.localName) {
//           return
//         }
//         const foundDevices = this.data.devices
//         const idx = inArray(foundDevices, 'deviceId', device.deviceId)
//         const data = {}
//         if (idx === -1) {
//           data[`devices[${foundDevices.length}]`] = device
//         } else {
//           data[`devices[${idx}]`] = device
//         }
//         console.log(data)
//         this.setData(data)
//       })
//     })
//   },
//   //链接低功耗蓝牙
//   createBLEConnection(e) {
//     if (wx.getStorageSync('closeBLEConnection') == 1) {
//       this.closeBLEConnection //断开蓝牙链接
//     } else {
//       this.closeBLEConnection //断开蓝牙链接
//       //this.createBLEConnection();
//       this.writeBLECharacteristicValue();
//     }
//     var laya = this.data.lanya; //所有蓝牙
//     const ds = e.currentTarget.dataset
//     const deviceId = ds.deviceId
//     const name = ds.name
//     wx.createBLEConnection({
//       deviceId,
//       success: (res) => {
//         this.getBLEDeviceServices(deviceId)
//       }
//     })
//     wx.setStorageSync('lianjie', 2)
//     this.stopBluetoothDevicesDiscovery()
//   },
//   //断开低功耗蓝牙链接
//   closeBLEConnection() {
//     wx.closeBLEConnection({
//       deviceId: this.data.deviceId
//     })
//     this.setData({
//       connected: false,
//       chs: [],
//       canWrite: false,
//     })
//   },
//   //获取蓝牙的service服务
//   getBLEDeviceServices(deviceId) {
//     wx.getBLEDeviceServices({
//       deviceId,
//       success: (res) => {
//         for (let i = 0; i < res.services.length; i++) {
//           if (res.services[i].isPrimary) {
//             this.getBLEDeviceCharacteristics(deviceId, res.services[i].uuid)
//             return
//           }
//         }
//       }
//     })
//   },
//   //获取蓝牙的特征值[读取]
//   getBLEDeviceCharacteristics(deviceId, serviceId) {
//     wx.getBLEDeviceCharacteristics({
//       deviceId,
//       serviceId,
//       success: (res) => {
//         console.log('getBLEDeviceCharacteristics success', res.characteristics)
//         for (let i = 0; i < res.characteristics.length; i++) {
//           let item = res.characteristics[i]
//           if (item.properties.read) {
//             console.log('可读的连接蓝牙设备')
//             wx.readBLECharacteristicValue({
//               deviceId,
//               serviceId,
//               characteristicId: item.uuid,
//             })
//           }
//           if (item.properties.write) {
//             console.log('可写入的蓝牙设备')

//             this.setData({
//               canWrite: true
//             })
//             this._deviceId = deviceId
//             this._serviceId = serviceId
//             this._characteristicId = item.uuid
//             //this.GetbleDeviceCharacteristics()
//           }
//           if (item.properties.notify || item.properties.indicate) {
//             wx.notifyBLECharacteristicValueChange({
//               deviceId,
//               serviceId,
//               characteristicId: item.uuid,
//               state: true,
//             })
//           }
//         }
//       },
//       fail(res) {
//         console.error('getBLEDeviceCharacteristics', res)
//       }
//     })
//     // 操作之前先监听，保证第一时间获取数据
//     wx.onBLECharacteristicValueChange((characteristic) => {
//       const idx = inArray(this.data.chs, 'uuid', characteristic.characteristicId)
//       const data = {}
//       if (idx === -1) {
//         data[`chs[${this.data.chs.length}]`] = {
//           uuid: characteristic.characteristicId,
//           value: ab2hex(characteristic.value)
//         }
//       } else {
//         data[`chs[${idx}]`] = {
//           uuid: characteristic.characteristicId,
//           value: ab2hex(characteristic.value)
//         }
//       }
//       //console.log(ab2hex(characteristic.value))

//       wx.setStorageSync('realcount', ab2hex(characteristic.value))
//       //this.setData(data)
//     })
//   },
//   //关闭蓝牙模块,[蓝牙结束]
//   closeBluetoothAdapter() {
//     wx.closeBluetoothAdapter()
//     this._discoveryStarted = false
//   },
//   onShow: function() {

//   },
//   //获取特征值,给后台
//   conte: function(e) {
//     let that = this
//     var id = e.currentTarget.dataset.id;
//     var count = e.currentTarget.dataset.count; //购买量
//     // var snum = hexToStr(wx.getStorageSync('realcount')); //实际斤数
//     var snum = Math.random() * 100 + 10
//     var coont = count * 0.2;
//     var sonrt = snum * 0.2;
//     var conyt = coont / sonrt;
//     // if (conyt) {
//     //   wx.showModal({
//     //     title: '错误',
//     //     content: '请重新称重',
//     //     showCancel: false
//     //   })
//     //   return false;
//     // }
//     //清楚本地指定key的内容
//     //wx.removeStorageSync
//     console.log(id)
//     console.log(snum)
//     console.log(count)
//     wx.request({
//       url: api + 'sortingOK',
//       data: {
//         id: id,
//         realcount: snum,
//         count: count
//       },
//       success(res) {
//         //清楚本地指定key的内容

//         that.getShopfj(that.data.name, that.data.goodsid); //获取当前id

//         // wx.removeStorageSync("realcount")
//         // console.log(res)

//         // that.closeBLEConnection(); //断开当前指定链接
//         // wx.setStorageSync('closeBLEConnection', 1) //断开指定链接蓝牙 code key
//         // wx.setStorageSync('wx_sortingOK_array', res.data.info) //缓存当前指定数组
//         // that.editor(); //回调打印模态框
//       }
//     })
//   },
//   //-------------------------------------------------------------------------------------
//   writeBLECharacteristicValue() {
//     var wx_bluetooth_stamp = wx.getStorageSync('wx_sortingOK_array')
//     if (wx_bluetooth_stamp == []) {
//       wx.showModal({
//         title: '错误',
//         content: '打印值不能为空',
//         showCancel: false
//       })
//       return false;
//     }
//     var i = 1;

//     function ch() {
//       i++;
//       return i;
//     }
//     let nowTime = util.formatData(new Date());
//     let printerJobs = new PrinterJobs();
//     printerJobs
//       .print('时间' + nowTime)
//       .print(printerUtil.fillLine())
//       .setAlign('ct')
//       .setSize(2, 2)
//       .print("#序号" + ch())
//       .setSize(1, 1)
//       .print("#名称" + wx_bluetooth_stamp.gname)
//       .setSize(2, 2)
//       .print("#餐厅" + wx_bluetooth_stamp.cname)
//       .setSize(1, 1)
//       .print('订购量' + wx_bluetooth_stamp.count)
//       .setSize(2, 2)
//       .print('实际斤数' + wx_bluetooth_stamp.realcount + "g")

//     let buffer = printerJobs.buffer();

//     console.log('ArrayBuffer', 'length: ' + buffer.byteLength, ' hex: ' + ab2hex(buffer)

//     );

//     // 1.并行调用多次会存在写失败的可能性
//     // 2.建议每次写入不超过20字节
//     // 分包处理，延时调用
//     const maxChunk = 20;
//     const delay = 20;
//     for (let i = 0, j = 0, length = buffer.byteLength; i < length; i += maxChunk, j++) {
//       let subPackage = buffer.slice(i, i + maxChunk <= length ? (i + maxChunk) : length);
//       setTimeout(this._writeBLECharacteristicValue, j * delay, subPackage);
//     }

//   },
//   //向低功耗蓝牙写入数据
//   _writeBLECharacteristicValue(buffer) {
//     wx.writeBLECharacteristicValue({
//       deviceId: this._deviceId,
//       serviceId: this._serviceId,
//       characteristicId: this._characteristicId,
//       value: buffer,
//       success(res) {
//         console.log('writeBLECharacteristicValue success', res)
//       },
//       fail(res) {
//         console.log('writeBLECharacteristicValue fail', res)
//       }
//     })
//     this.closeBluetoothAdapter();
//     this.closeBLEConnection();
//   },

//   // 分拣下一个货物
//   gonext: function() {
//     var nowindex = this.data.nowindex;
//     var shoplist = this.data.shoplist;
//     var nextindex = nowindex * 1 + 1;
//     console.log(nextindex)
//     console.log(shoplist.length)
//     if (nextindex >= shoplist.length) {
//       console.log('不存在下一个商品了')
//       wx.showModal({
//         title: '提示',
//         content: '已经是最后一个了',
//         confirmText: "返回列表",
//         success(res) {
//           if (res.confirm) {
//             wx.navigateBack({
//               delta: 1
//             }); //返回上一页
//           } else if (res.cancel) {
//             console.log('用户点击取消')
//           }
//         }
//       })
//     } else {
//       wx.redirectTo({
//         url: '../fjcan/fjcan?goodsid=' + shoplist[nextindex].goodsid + '&name=' + shoplist[nextindex].name + "&nowindex=" + nextindex + "&shoplist=" + JSON.stringify(shoplist)
//       })
//     }
//   }




// })

//--------------------------------------------------------------------------------


function openBluetoothAdapter() {

  if (!wx.openBluetoothAdapter) {
    wx.showModal({
      title: '提示',
      content: '当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。'
    })
    return
  }
  wx.openBluetoothAdapter({
    success: (res) => {
      //console.log('openBluetoothAdapter success', res)
      startBluetoothDevicesDiscovery()
    },
    fail: (res) => {
      if (res.errCode === 10001) {
        wx.showModal({
          title: '错误',
          content: '未找到蓝牙设备, 请打开蓝牙后重试。',
          showCancel: false
        })
        wx.onBluetoothAdapterStateChange(function(res) {
          //console.log('onBluetoothAdapterStateChange', res)
          if (res.available) {
            startBluetoothDevicesDiscovery()
          }
        })
      }
    }
  })







}

function startBluetoothDevicesDiscovery() {
  if (_discoveryStarted) {
    return
  }
  _discoveryStarted = true
  wx.startBluetoothDevicesDiscovery({
    allowDuplicatesKey: true,
    success: (res) => {
      console.log('startBluetoothDevicesDiscovery success', res)
      onBluetoothDeviceFound()
    },
    //开始搜索附近蓝牙 抛出异常
    fail: (res) => {
      console.log('startBluetoothDevicesDiscovery fail', res)
    }
  })
}

//监听新设备链接
function onBluetoothDeviceFound() {


  wx.onBluetoothDeviceFound((res) => {
    res.devices.forEach(device => {
      if (!device.name && !device.localName) {
        return
      }
      const foundDevices = this.data.devices
      const idx = inArray(foundDevices, 'deviceId', device.deviceId)
      const data = {}
      if (idx === -1) {
        data[`devices[${foundDevices.length}]`] = device
      } else {
        data[`devices[${idx}]`] = device
      }
      console.log(data)
      // this.setData(data)
    })
  })

}




module.exports = {
  openBluetoothAdapter: openBluetoothAdapter
}