module.exports = {
  version: "1.0",
  note: '点餐助手1.0版本，欢迎体验、一同参与开发，QQ群 315181914',
  subDomain: "mall" // 什么是subDomain？ https://www.yuque.com/apifm/doc/qr6l4m
}