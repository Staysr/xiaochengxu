 <p align="center"> <a href="https://www.color-ui.com/" target="_blank"> <img src="https://image.weilanwl.com/colorui/githubHead1223.png" alt="" style="max-width:100%;" width="580"> </a> </p>
                <h2>简介</h2>
                <p>hi!开发者！ColorUI迎来了2.0的升级，相比之前的版本，2.0版本重构了基础代码，增加了更多的配色，这是一个全新的小程序UI解决方案。</p>
                <p>ColorUI是一个Css类的UI组件库！不是一个Js框架。相比于同类小程序组件库，ColorUI更注重于视觉交互！</p>
                <p>项目为个人开源项目，如果项目有帮到你，希望能支持下开发者。</p>
				  <p align="center"><img src="https://image.weilanwl.com/colorui/githubMiniPorgam.jpg" alt="" style="max-width:100%;" width="800"></p>
                <h2>使用</h2>
                <p>下载源码包可得到 <strong>Demo</strong> 和 <strong>Template</strong> 两个项目， <strong>Demo</strong> 包含所有组件源码。 <strong>Template</strong> 是一个已经引用了ColorUI的空白模板。<strong>Demo</strong> 即文档。<a href="https://www.color-ui.com/" target="_blank">在线文档</a> 编写中...</p>
                <h2>交流</h2>
                <p>微信群：加入微信群请先添加开发者微信，备注GitHub。QQ群：240787041 或扫描二维码。</p>
                <p align="center"><img src="https://image.weilanwl.com/colorui/githubQrcode.jpg" alt="" style="max-width:100%;" width="748"></p>				  
                <h2>赞赏</h2>
<p align="center"><img src="https://image.weilanwl.com/githubAppreciate.jpg" alt="" style="max-width:100%;" width="600"></p>
