<script type="text/javascript">
	
const httpUrl = "https://lumingbao.cross.echosite.cn"

export default{
  httpUrl
}

</script>